'use client';

import { useEffect, useState, Suspense } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { motion, AnimatePresence } from 'framer-motion';
import { useRouter } from 'next/navigation';
import dynamic from 'next/dynamic';

import CinematicLighting from '@/components/three/CinematicLighting';
import LobbyRoom         from '@/components/three/LobbyRoom';
import RouletteWheel     from '@/components/three/RouletteWheel';
import RouletteTable     from '@/components/three/RouletteTable';
import VolumetricBeam    from '@/components/effects/VolumetricBeam';
import DustParticles     from '@/components/effects/DustParticles';

import BlackjackTable from '@/games/blackjack/BlackjackTable';

import { useAurumStore } from '@/store/useAurumStore';
import { useT } from '@/lib/i18n';
import { playClick } from '@/lib/audio';

const PostFX = dynamic(() => import('@/components/effects/PostFX'), { ssr: false });

const REEL = [
  {
    id: 'lobby',
    titleKey: 'demo.lobby.t',
    subKey:   'demo.lobby.s',
    camera: { from: [0, 3.0, 6], to: [0.6, 2.4, 5], dur: 12 },
  },
  {
    id: 'roulette',
    titleKey: 'demo.roulette.t',
    subKey:   'demo.roulette.s',
    camera: { from: [0, 4.0, 5.5], to: [-1.5, 2.5, 4.5], dur: 12 },
  },
  {
    id: 'blackjack',
    titleKey: 'demo.blackjack.t',
    subKey:   'demo.blackjack.s',
    camera: { from: [0, 3.6, 4.2], to: [1.2, 2.8, 3.8], dur: 12 },
  },
];

/**
 * Demo / Kiosk mode — fullscreen, auto-rotating scene reel for trade shows.
 * No HUD, no chrome. Esc / click anywhere to return.
 */
export default function DemoPage() {
  const router = useRouter();
  const setKiosk = useAurumStore((s) => s.setKioskMode);
  const t = useT();
  const [idx, setIdx] = useState(0);
  const current = REEL[idx];

  // Set kiosk on mount, off on unmount
  useEffect(() => {
    setKiosk(true);
    return () => setKiosk(false);
  }, [setKiosk]);

  // Auto-advance reel
  useEffect(() => {
    const t = setTimeout(() => setIdx((i) => (i + 1) % REEL.length), current.camera.dur * 1000);
    return () => clearTimeout(t);
  }, [idx, current]);

  // Esc → leave
  useEffect(() => {
    const onKey = (e) => {
      if (e.key === 'Escape') { playClick(); router.push('/'); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [router]);

  return (
    <section className="relative w-full h-screen overflow-hidden grain vignette" onClick={() => router.push('/')}>
      <Canvas
        camera={{ position: current.camera.from, fov: 38 }}
        dpr={[1, 1.6]}
        shadows
        gl={{ antialias: true, toneMapping: 2, toneMappingExposure: 0.95 }}
      >
        <Suspense fallback={null}>
          <fog attach="fog" args={['#08060E', 8, 28]} />
          <CinematicLighting intensity={1.0} />
          <VolumetricBeam position={[0, 6, 0]} height={5.5} radius={2.2} intensity={0.85} />
          <DustParticles count={500} area={14} color="#F4D78A" />
          <ReelScene id={current.id} />
          <CameraOrbit camera={current.camera} key={current.id} />
          <PostFX intensity={1.05} />
        </Suspense>
      </Canvas>

      {/* cinematic bars */}
      <div className="absolute top-0 left-0 right-0 h-[10vh] z-30 pointer-events-none"
        style={{ background: 'linear-gradient(180deg, #000 0%, transparent 100%)' }} />
      <div className="absolute bottom-0 left-0 right-0 h-[14vh] z-30 pointer-events-none"
        style={{ background: 'linear-gradient(0deg, #000 0%, transparent 100%)' }} />

      {/* title overlay */}
      <AnimatePresence mode="wait">
        <motion.div
          key={current.id}
          initial={{ opacity: 0, y: 30, filter: 'blur(20px)' }}
          animate={{ opacity: 1, y: 0,  filter: 'blur(0px)'  }}
          exit   ={{ opacity: 0, y:-30, filter: 'blur(20px)' }}
          transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1] }}
          className="absolute bottom-20 left-1/2 -translate-x-1/2 text-center z-40"
        >
          <div className="flex items-center justify-center gap-3 mb-3">
            <span className="hairline-gold w-12" />
            <span className="engraved text-[9px] text-aurum-gold/80">{t('demo.subtitle')}</span>
            <span className="hairline-gold w-12" />
          </div>
          <h2 className="font-display text-5xl md:text-7xl gold-leaf tracking-[0.06em] leading-none mb-3">
            {t(current.titleKey)}
          </h2>
          <p className="font-display italic text-aurum-ivory/65 text-lg md:text-xl">
            {t(current.subKey)}
          </p>
        </motion.div>
      </AnimatePresence>

      {/* progress dots */}
      <div className="absolute top-12 left-1/2 -translate-x-1/2 z-40 flex items-center gap-3">
        {REEL.map((_, i) => (
          <motion.span
            key={i}
            animate={{
              scaleX: i === idx ? 2.4 : 1,
              opacity: i === idx ? 1 : 0.35,
              backgroundColor: i === idx ? '#F4D78A' : '#7A5C18',
            }}
            transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
            className="w-6 h-px origin-left"
          />
        ))}
      </div>

      {/* hint */}
      <div className="absolute top-12 right-12 z-40 engraved text-[8px] text-aurum-smoke">
        {t('demo.exit')}
      </div>
    </section>
  );
}

function ReelScene({ id }) {
  if (id === 'lobby')     return <LobbyRoom />;
  if (id === 'roulette')  return (<>
    <RouletteTable position={[0, 0, 0]} />
    <RouletteWheel position={[0, 0.18, -0.4]} scale={0.95} />
  </>);
  if (id === 'blackjack') return <BlackjackTable position={[0, 0, 0]} />;
  return null;
}

function CameraOrbit({ camera }) {
  const { camera: cam } = useThree();
  useEffect(() => {
    cam.position.set(...camera.from);
  }, [cam, camera]);

  useFrame(({ clock }) => {
    const t = (clock.elapsedTime % camera.dur) / camera.dur;
    const e = t * t * (3 - 2 * t); // smoothstep
    cam.position.x = camera.from[0] + (camera.to[0] - camera.from[0]) * e;
    cam.position.y = camera.from[1] + (camera.to[1] - camera.from[1]) * e;
    cam.position.z = camera.from[2] + (camera.to[2] - camera.from[2]) * e;
    cam.lookAt(0, 0.5, 0);
  });
  return null;
}
