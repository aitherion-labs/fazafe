'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import AuthShell from '@/components/ui/AuthShell';
import { GlassPanel } from '@/ds/components';
import { getStatus } from '@/services/compliance';
import { playClick } from '@/lib/audio';

export default function ComplianceHubPage() {
  const [s, setS] = useState(null);
  useEffect(() => { setS(getStatus()); }, []);

  return (
    <AuthShell title="Conformité" subtitle="Vérification, limites, jeu responsable.">
      <div className="space-y-3">
        <Tile
          href="/compliance/kyc"
          title="Vérification d'identité"
          subtitle={s ? `Niveau actuel : ${s.kycLevel} / 3` : '—'}
          tone={s?.kycLevel >= 2 ? 'good' : 'pending'}
        />
        <Tile
          href="/compliance/responsible"
          title="Jeu Responsable"
          subtitle={s?.selfExcluded ? 'Auto-exclusion ACTIVE' : 'Limites & contrôles'}
          tone={s?.selfExcluded ? 'warning' : 'neutral'}
        />
      </div>

      <div className="mt-8 hairline-gold opacity-60" />
      <p className="mt-5 text-center text-[10px] text-aurum-ivory/55 leading-relaxed italic">
        Le jeu peut créer une dépendance. Jouez avec modération.
        <br />Service d'aide : 09&nbsp;74&nbsp;75&nbsp;13&nbsp;13 (FR · gratuit)
      </p>
    </AuthShell>
  );
}

function Tile({ href, title, subtitle, tone }) {
  const tones = {
    good:    { color: '#F4D78A', mark: '✓' },
    pending: { color: '#EDE3CE', mark: '◇' },
    warning: { color: '#E0573B', mark: '⚠' },
    neutral: { color: '#EDE3CE', mark: '·' },
  }[tone];
  return (
    <Link href={href} onClick={playClick} className="block">
      <GlassPanel tint="noir" animate={false} className="px-5 py-4 rounded-sm flex items-center gap-4 hover:scale-[1.01] transition-transform">
        <span className="text-2xl" style={{ color: tones.color, filter: 'drop-shadow(0 0 8px currentColor)' }}>
          {tones.mark}
        </span>
        <div className="flex-1">
          <div className="text-aurum-ivory/85 text-sm tracking-[0.04em]">{title}</div>
          <div className="engraved text-[8px] text-aurum-smoke mt-0.5">{subtitle}</div>
        </div>
        <span className="text-aurum-gold/40">→</span>
      </GlassPanel>
    </Link>
  );
}
