'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';

import AuthShell from '@/components/ui/AuthShell';
import FormField from '@/components/ui/FormField';
import { CinematicButton } from '@/ds/components';
import { getStatus, setStatus } from '@/services/compliance';
import { playClick } from '@/lib/audio';

const STEPS = [
  { id: 'email',    label: 'Email vérifié',  hint: 'Niveau 1' },
  { id: 'identity', label: 'Pièce d’identité', hint: 'Niveau 2' },
  { id: 'address',  label: 'Justificatif d’adresse', hint: 'Niveau 2 confirmé' },
  { id: 'funds',    label: 'Origine des fonds', hint: 'Niveau 3 — gros gains' },
];

export default function KycPage() {
  const router = useRouter();
  const [step, setStep]   = useState(0);
  const [doc, setDoc]     = useState('');
  const [addr, setAddr]   = useState('');
  const [funds, setFunds] = useState('');
  const [s, setS]         = useState(null);

  useEffect(() => { setS(getStatus()); }, []);

  const advance = () => {
    playClick();
    if (step === 1) setStatus({ kycLevel: 2, identityVerified: true });
    if (step === 2) setStatus({ kycLevel: 2 }); // address ok
    if (step === 3) setStatus({ kycLevel: 3 });
    setS(getStatus());
    if (step < STEPS.length - 1) setStep(step + 1);
    else router.push('/compliance');
  };

  return (
    <AuthShell title="Vérification" subtitle="Quatre étapes — quelques minutes.">
      {/* Stepper */}
      <div className="flex items-center justify-between mb-8">
        {STEPS.map((s, i) => (
          <div key={s.id} className="flex-1 flex items-center">
            <motion.div
              animate={{
                scale: i === step ? 1.15 : 1,
                backgroundColor: i <= step ? '#F4D78A' : '#3A2A12',
              }}
              transition={{ duration: 0.5 }}
              className="w-3 h-3 rounded-full"
            />
            {i < STEPS.length - 1 && (
              <motion.div
                animate={{ backgroundColor: i < step ? '#C8A24A' : '#3A2A12' }}
                className="flex-1 h-px mx-2"
              />
            )}
          </div>
        ))}
      </div>

      <div className="text-center mb-8">
        <div className="engraved text-[8px] text-aurum-gold/70 mb-2">{STEPS[step].hint}</div>
        <h3 className="font-display text-2xl gold-leaf">{STEPS[step].label}</h3>
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={step}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.4 }}
        >
          {step === 0 && (
            <p className="text-aurum-ivory/65 text-sm leading-relaxed mb-6 italic">
              Email <span className="text-aurum-goldHi">{s?.email}</span> vérifié à l'inscription.
              Cliquez pour continuer.
            </p>
          )}
          {step === 1 && (
            <FormField label="Numéro de pièce d'identité" value={doc} onChange={setDoc}
              placeholder="FR-AB-1234567" />
          )}
          {step === 2 && (
            <FormField label="Adresse postale complète" value={addr} onChange={setAddr}
              placeholder="12 rue du Hasard, 75001 Paris" />
          )}
          {step === 3 && (
            <FormField label="Origine des fonds" value={funds} onChange={setFunds}
              placeholder="Salaire, héritage, vente immobilière, etc." />
          )}
        </motion.div>
      </AnimatePresence>

      <div className="mt-2">
        <CinematicButton onClick={advance} size="md" className="w-full">
          {step < STEPS.length - 1 ? 'Continuer' : 'Terminer'}
        </CinematicButton>
      </div>

      <p className="mt-5 text-center engraved text-[7px] text-aurum-smoke leading-relaxed">
        V0.1 · KYC simulé · Aucun document n'est transmis
      </p>
    </AuthShell>
  );
}
