'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import AuthShell from '@/components/ui/AuthShell';
import FormField from '@/components/ui/FormField';
import { GlassPanel, CinematicButton } from '@/ds/components';
import { getStatus, setStatus, applyTimeout, RG_PRESETS } from '@/services/compliance';
import { playClick } from '@/lib/audio';

export default function ResponsiblePage() {
  const router = useRouter();
  const [s, setS]               = useState(null);
  const [daily, setDaily]       = useState('');
  const [weekly, setWeekly]     = useState('');
  const [session, setSession]   = useState('');
  const [confirm, setConfirm]   = useState(null);

  useEffect(() => {
    const st = getStatus();
    setS(st);
    setDaily(st.dailyLimit  ?? '');
    setWeekly(st.weeklyLimit ?? '');
    setSession(st.sessionLimitMin ?? '');
  }, []);

  const saveLimits = () => {
    playClick();
    setStatus({
      dailyLimit:      daily   || null,
      weeklyLimit:     weekly  || null,
      sessionLimitMin: session ? parseInt(session, 10) : null,
    });
    setS(getStatus());
  };

  const exclude = (ms, label) => {
    if (confirm !== label) { setConfirm(label); return; }
    playClick();
    applyTimeout(ms);
    setS(getStatus());
    setTimeout(() => router.push('/'), 1500);
  };

  return (
    <AuthShell title="Jeu Responsable" subtitle="Vous gardez le contrôle.">
      <div className="engraved text-[8px] text-aurum-gold/70 mb-3">Limites de mise</div>
      <FormField label="Limite quotidienne ($)"  value={daily}   onChange={setDaily}   placeholder="500" />
      <FormField label="Limite hebdomadaire ($)" value={weekly}  onChange={setWeekly}  placeholder="2000" />
      <FormField label="Durée max. par session (min)" value={session} onChange={setSession} placeholder="60" />

      <div className="mb-6">
        <CinematicButton onClick={saveLimits} size="md" className="w-full">
          Enregistrer mes limites
        </CinematicButton>
      </div>

      <div className="hairline-gold opacity-60 mb-6" />

      <div className="engraved text-[8px] text-red-400/80 mb-3">Auto-exclusion</div>
      <p className="text-aurum-ivory/55 text-[11px] leading-relaxed mb-4 italic">
        Suspendre votre accès. Cette action est immédiate et irréversible
        pendant la période choisie.
      </p>

      <div className="grid grid-cols-3 gap-2">
        {[
          { label: '24 H',     ms: RG_PRESETS.COOLDOWN_24H },
          { label: '7 JOURS',  ms: RG_PRESETS.COOLDOWN_7D  },
          { label: '30 JOURS', ms: RG_PRESETS.COOLDOWN_30D },
        ].map((opt) => (
          <button
            key={opt.label}
            onClick={() => exclude(opt.ms, opt.label)}
            className={`
              px-3 py-3 rounded-sm text-[10px] tracking-[0.18em] uppercase
              transition-colors border
              ${confirm === opt.label
                ? 'bg-red-900/30 border-red-400/50 text-red-300'
                : 'border-aurum-gold/15 text-aurum-ivory/55 hover:text-red-400/80 hover:border-red-400/30'}
            `}
          >
            {confirm === opt.label ? 'Confirmer ?' : opt.label}
          </button>
        ))}
      </div>

      <p className="mt-6 text-center text-[10px] text-aurum-ivory/45 leading-relaxed italic">
        Service d'aide : <span className="text-aurum-goldHi">09 74 75 13 13</span>
        <br />Anonymous, gratuit, 8h–2h
      </p>

      {s?.selfExcluded && (
        <GlassPanel tint="noir" animate={false} className="mt-6 px-4 py-3 rounded-sm text-center">
          <div className="engraved text-[8px] text-red-400/80">
            Auto-exclusion ACTIVE jusqu'au<br />
            <span className="text-aurum-ivory/85 font-mono">
              {s.selfExclusionUntil && new Date(s.selfExclusionUntil).toLocaleString('fr-FR')}
            </span>
          </div>
        </GlassPanel>
      )}
    </AuthShell>
  );
}
