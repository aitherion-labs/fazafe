'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { motion } from 'framer-motion';

import AuthShell from '@/components/ui/AuthShell';
import FormField from '@/components/ui/FormField';
import { CinematicButton, GlassPanel } from '@/ds/components';
import { useAccountStore } from '@/store/useAccountStore';
import { useWalletStore }  from '@/store/useWalletStore';
import { canWithdraw, getStatus } from '@/services/compliance';
import { get as getAdapter } from '@/services/payments';
import { playClick } from '@/lib/audio';
import { useT } from '@/lib/i18n';

export default function WithdrawPage() {
  const router    = useRouter();
  const accountId = useAccountStore((s) => s.accountId);
  const wallet    = useWalletStore();
  const formatted = useWalletStore((s) => s.formatted());
  const t         = useT();
  const [amount, setAmount] = useState('100');
  const [busy, setBusy]     = useState(false);
  const [err, setErr]       = useState(null);
  const [done, setDone]     = useState(false);

  if (!accountId) {
    if (typeof window !== 'undefined') router.replace('/account/login');
    return null;
  }

  const gate = canWithdraw();

  const submit = async () => {
    setErr(null);
    if (!gate.ok) { setErr(gate.reason); return; }
    const adapter = getAdapter('simulated');
    setBusy(true);
    try {
      await adapter.withdraw({
        accountId, amount, currency: 'EUR',
        balances: {
          available: wallet.available,
          locked:    wallet.locked,
          lifetime:  wallet.lifetime,
        },
      });
      setDone(true);
      setTimeout(() => router.push('/wallet'), 1400);
    } catch (e) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <AuthShell title={t("wallet.withdraw.title")} subtitle={`${t("wallet.withdraw.subtitle")} ${formatted.available}`}>
      {done ? (
        <motion.div
          initial={{ opacity: 0, scale: 0.85 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center py-8"
        >
          <div className="font-display text-6xl gold-leaf mb-3">✓</div>
          <div className="engraved text-[10px] text-aurum-goldHi">{t("wallet.withdraw.done")}</div>
        </motion.div>
      ) : !gate.ok ? (
        <GlassPanel tint="noir" className="p-6 rounded-sm text-center" animate={false}>
          <div className="engraved text-[8px] text-red-400/80 mb-3">{t('wallet.withdraw.kyc')}</div>
          <p className="text-aurum-ivory/65 text-sm mb-4">
            {t('wallet.withdraw.kycText')}
          </p>
          <Link href="/compliance/kyc">
            <CinematicButton size="sm">{t("wallet.withdraw.kycBtn")}</CinematicButton>
          </Link>
        </GlassPanel>
      ) : (
        <>
          <FormField
            label={`${t('wallet.withdraw.amount')} ($)`}
            type="number"
            value={amount}
            onChange={setAmount}
            placeholder="0,00"
          />

          <div className="engraved text-[8px] text-aurum-smoke mb-2">Méthode</div>
          <GlassPanel tint="noir" animate={false} className="px-4 py-3 rounded-sm flex items-center justify-between mb-6">
            <span className="text-aurum-ivory/85 text-sm">Démonstration</span>
            <span className="engraved text-[8px] text-aurum-goldHi">DISPONIBLE</span>
          </GlassPanel>

          {err && (
            <div className="text-[10px] tracking-[0.18em] text-red-400/80 text-center mb-4">
              {err.replace(/_/g, ' ')}
            </div>
          )}

          <CinematicButton
            onClick={submit}
            size="md"
            className={busy ? 'opacity-60 pointer-events-none w-full' : 'w-full'}
          >
            {busy ? t('wallet.withdraw.process') : `Withdraw $${amount}`}
          </CinematicButton>

          <p className="mt-5 text-center engraved text-[7px] text-aurum-smoke leading-relaxed">
            V0.1 · Opération simulée · Aucun mouvement de fonds réel
          </p>

          <Link href="/wallet"
            className="block text-center mt-3 text-[9px] tracking-[0.32em]
                       text-aurum-smoke hover:text-aurum-gold uppercase">
            {t("wallet.back")}
          </Link>
        </>
      )}
    </AuthShell>
  );
}
