'use client';

import { useState, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import Link from 'next/link';

import AuthShell from '@/components/ui/AuthShell';
import FormField from '@/components/ui/FormField';
import { CinematicButton, GlassPanel } from '@/ds/components';
import { useAccountStore } from '@/store/useAccountStore';
import { useWalletStore }  from '@/store/useWalletStore';
import { canDeposit }      from '@/services/compliance';
import { list as listAdapters, get as getAdapter } from '@/services/payments';
import { playClick, playReveal } from '@/lib/audio';
import { useT } from '@/lib/i18n';
import { formatCurrency } from '@/services/money';

const PRESETS = [50, 100, 250, 500, 1000];

/* Format card number with spaces every 4 digits */
function formatCardNumber(value) {
  const digits = value.replace(/\D/g, '').slice(0, 16);
  return digits.replace(/(\d{4})(?=\d)/g, '$1 ');
}
function formatExpiry(value) {
  const digits = value.replace(/\D/g, '').slice(0, 4);
  if (digits.length < 3) return digits;
  return `${digits.slice(0, 2)} / ${digits.slice(2)}`;
}

export default function DepositPage() {
  const router    = useRouter();
  const accountId = useAccountStore((s) => s.accountId);
  const wallet    = useWalletStore();
  const t         = useT();

  const [amount, setAmount]   = useState('100');
  const [method, setMethod]   = useState('card');
  const [card,   setCard]     = useState({ number: '', expiry: '', cvv: '', name: '' });
  const [busy,   setBusy]     = useState(false);
  const [err,    setErr]      = useState(null);
  const [done,   setDone]     = useState(false);

  const cardLast4 = useMemo(() => {
    const digits = card.number.replace(/\D/g, '');
    return digits.length >= 4 ? digits.slice(-4) : '••••';
  }, [card.number]);

  const cardBrand = useMemo(() => {
    const d = card.number.replace(/\D/g, '');
    if (d.startsWith('4')) return 'Visa';
    if (d.startsWith('5')) return 'Mastercard';
    if (d.startsWith('3')) return 'Amex';
    if (d.startsWith('6')) return 'Discover';
    return 'Card';
  }, [card.number]);

  const cardFilled = card.number.replace(/\D/g, '').length >= 12
                  && card.expiry.replace(/\D/g, '').length >= 4
                  && card.cvv.length >= 3
                  && card.name.trim().length > 1;

  const submit = async () => {
    if (busy || !accountId) return;
    setErr(null);
    const numAmount = parseFloat(amount);
    if (!numAmount || numAmount < 1) { setErr('AMOUNT_INVALID'); return; }
    if (method === 'card' && !cardFilled) { setErr('CARD_INCOMPLETE'); return; }

    setBusy(true);
    playClick();

    // Simulate authorization delay for realism (1.6s — a real card auth takes 1-3s)
    await new Promise((r) => setTimeout(r, 1600));

    const res = await wallet.deposit(accountId, amount);
    if (!res.ok) {
      setErr(res.reason || 'TRANSACTION_FAILED');
      setBusy(false);
      return;
    }
    setDone(true);
    playReveal();
    setBusy(false);

    // auto-return after a beat
    setTimeout(() => router.push('/wallet'), 2200);
  };

  return (
    <AuthShell title={t('wallet.deposit.title')} subtitle={t('wallet.deposit.subtitle')}>
      {done ? (
        <motion.div
          initial={{ opacity: 0, scale: 0.7 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
          className="text-center py-10"
        >
          <div
            className="font-display text-7xl gold-leaf mb-3"
            style={{ filter: 'drop-shadow(0 0 24px rgba(244,215,138,0.6))' }}
          >
            ✓
          </div>
          <div className="font-display text-2xl gold-leaf mb-1">
            +{formatCurrency(amount)}
          </div>
          <div className="engraved text-[10px] text-aurum-goldHi tracking-[0.32em]">
            {t('wallet.deposit.done')}
          </div>
        </motion.div>
      ) : (
        <>
          {/* AMOUNT */}
          <div className="engraved text-[8px] text-aurum-gold/70 mb-3">{t('wallet.deposit.amount')}</div>
          <div className="grid grid-cols-5 gap-2 mb-4">
            {PRESETS.map((p) => (
              <motion.button
                key={p}
                whileTap={{ scale: 0.94 }}
                whileHover={{ y: -1 }}
                onClick={() => { playClick(); setAmount(String(p)); }}
                className={`
                  px-2 py-3 rounded-sm text-[11px] tracking-[0.18em]
                  font-medium uppercase transition-colors
                  ${String(p) === amount
                    ? 'gold-leaf border-aurum-goldHi'
                    : 'text-aurum-ivory/60 hover:text-aurum-goldHi border-aurum-gold/15'}
                `}
                style={{
                  background: 'rgba(15,11,22,0.5)',
                  border: '1px solid rgba(244,215,138,0.18)',
                }}
              >
                ${p}
              </motion.button>
            ))}
          </div>

          <FormField
            label={`${t('wallet.deposit.custom')} ($)`}
            type="number"
            value={amount}
            onChange={setAmount}
            placeholder="0.00"
          />

          {/* METHOD */}
          <div className="engraved text-[8px] text-aurum-gold/70 mb-3 mt-3">
            {t('wallet.deposit.method')}
          </div>
          <div className="space-y-2 mb-4">
            {listAdapters().map((a) => (
              <button
                key={a.id}
                onClick={() => { playClick(); setMethod(a.id); }}
                disabled={!a.isActive}
                className={`
                  w-full px-4 py-2.5 rounded-sm text-left flex items-center justify-between
                  transition-colors disabled:opacity-40
                  ${method === a.id
                    ? 'border-aurum-goldHi'
                    : 'border-aurum-gold/15 hover:border-aurum-gold/35'}
                `}
                style={{
                  background: method === a.id ? 'rgba(244,215,138,0.06)' : 'rgba(15,11,22,0.5)',
                  border: '1px solid rgba(244,215,138,0.18)',
                }}
              >
                <span className="text-[12px] text-aurum-ivory/85">{a.label}</span>
                <span className="engraved text-[8px]">
                  {a.isActive ? t('wallet.deposit.available') : t('wallet.deposit.soon')}
                </span>
              </button>
            ))}
          </div>

          {/* CARD FORM (when method=card) */}
          <AnimatePresence>
            {method === 'card' && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit   ={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.4 }}
                className="overflow-hidden"
              >
                <CardPreview brand={cardBrand} last4={cardLast4} name={card.name} expiry={card.expiry} />

                <div className="grid grid-cols-1 gap-2 mt-4">
                  <FormField
                    label={t('card.number')}
                    value={formatCardNumber(card.number)}
                    onChange={(v) => setCard({ ...card, number: v.replace(/\s/g, '') })}
                    placeholder="4242 4242 4242 4242"
                    maxLength={19}
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <FormField
                      label={t('card.expiry')}
                      value={formatExpiry(card.expiry)}
                      onChange={(v) => setCard({ ...card, expiry: v })}
                      placeholder="12 / 28"
                      maxLength={7}
                    />
                    <FormField
                      label={t('card.cvv')}
                      value={card.cvv}
                      onChange={(v) => setCard({ ...card, cvv: v.replace(/\D/g, '').slice(0, 4) })}
                      placeholder="123"
                      maxLength={4}
                    />
                  </div>
                  <FormField
                    label={t('card.name')}
                    value={card.name}
                    onChange={(v) => setCard({ ...card, name: v.toUpperCase() })}
                    placeholder={t('card.namePh')}
                  />
                </div>

                <div className="mt-2 flex items-center gap-2 text-[8px] text-aurum-smoke">
                  <span className="px-1.5 py-0.5 rounded-sm border border-aurum-goldHi/40 text-aurum-goldHi tracking-[0.18em]">
                    {t('card.demoBadge')}
                  </span>
                  <span className="italic">{t('card.demoHint')}</span>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {err && (
            <div className="text-[10px] tracking-[0.18em] text-red-400/80 text-center mt-3 mb-1">
              {err.replace(/_/g, ' ')}
            </div>
          )}

          {/* SUBMIT */}
          <div className="mt-5">
            <CinematicButton
              onClick={submit}
              size="md"
              className={busy ? 'opacity-60 pointer-events-none w-full' : 'w-full'}
            >
              {busy ? (
                <span className="flex items-center justify-center gap-3">
                  <motion.span
                    animate={{ rotate: 360 }}
                    transition={{ duration: 1.0, repeat: Infinity, ease: 'linear' }}
                    className="inline-block w-3.5 h-3.5 rounded-full border-2 border-aurum-black/30"
                    style={{ borderTopColor: 'currentColor' }}
                  />
                  {t('card.processing')}
                </span>
              ) : (
                <>
                  {t('card.payButton')} <span className="tabular-nums">{formatCurrency(amount)}</span>
                </>
              )}
            </CinematicButton>
          </div>

          <p className="mt-4 text-center engraved text-[7px] text-aurum-smoke leading-relaxed">
            🔒 {t('card.secure')} · {t('wallet.deposit.simNote')}
          </p>

          <Link href="/wallet"
            className="block text-center mt-3 text-[9px] tracking-[0.32em]
                       text-aurum-smoke hover:text-aurum-gold uppercase">
            {t('wallet.back')}
          </Link>
        </>
      )}
    </AuthShell>
  );
}

/* ---------- Card preview ---------- */

function CardPreview({ brand, last4, name, expiry }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y:  0 }}
      transition={{ duration: 0.5, delay: 0.1 }}
      className="relative w-full rounded-lg p-5 overflow-hidden"
      style={{
        background: 'linear-gradient(135deg, #2A0E08 0%, #0A0608 50%, #2A0E08 100%)',
        boxShadow: '0 12px 30px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.06)',
        border: '1px solid rgba(244,215,138,0.35)',
        aspectRatio: '1.586 / 1',
        maxWidth: '320px',
        margin: '0 auto',
      }}
    >
      {/* gold foil sigil top-right */}
      <div className="absolute top-3 right-4 flex items-center gap-2">
        <span className="font-display text-base gold-leaf tracking-[0.18em]">AURUM</span>
        <span
          className="block w-4 h-4 rounded-full"
          style={{
            background: 'radial-gradient(circle at 30% 30%, #FFF1C7, #C8A24A 60%, #7A5C18)',
            boxShadow: '0 0 8px rgba(244,215,138,0.6)',
          }}
        />
      </div>

      {/* chip */}
      <div
        className="absolute top-12 left-5 w-9 h-7 rounded-sm"
        style={{
          background: 'linear-gradient(135deg, #C8A24A, #7A5C18)',
          boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.3), 0 1px 4px rgba(0,0,0,0.4)',
        }}
      >
        <div
          className="absolute inset-1 grid grid-cols-2 grid-rows-3 gap-px"
          style={{ opacity: 0.4 }}
        >
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} style={{ background: '#0A0608' }} />
          ))}
        </div>
      </div>

      {/* number */}
      <div className="absolute bottom-12 left-5 right-5 font-mono text-[14px] tracking-[0.18em] text-aurum-goldHi"
           style={{ textShadow: '0 1px 2px rgba(0,0,0,0.8)' }}>
        •••• •••• •••• {last4}
      </div>

      {/* name + expiry */}
      <div className="absolute bottom-3 left-5 right-5 flex items-end justify-between
                      text-[9px] tracking-[0.18em] text-aurum-ivory/75 font-mono">
        <span className="uppercase truncate max-w-[180px]">
          {name || 'CARDHOLDER NAME'}
        </span>
        <span>{expiry || 'MM / YY'}</span>
      </div>

      {/* brand badge */}
      <div className="absolute top-5 left-5 px-2 py-0.5 rounded-sm text-[8px] tracking-[0.18em]
                      text-aurum-goldHi border border-aurum-goldHi/40">
        {brand}
      </div>
    </motion.div>
  );
}
