'use client';

import { useEffect, useState, Suspense, useMemo } from 'react';
import { Canvas } from '@react-three/fiber';
import { motion, AnimatePresence } from 'framer-motion';
import { useRouter } from 'next/navigation';
import dynamic from 'next/dynamic';
import * as THREE from 'three';

import { GlassPanel, CinematicButton } from '@/ds/components';
import CinematicLighting from '@/components/three/CinematicLighting';
import VolumetricBeam    from '@/components/effects/VolumetricBeam';
import DustParticles     from '@/components/effects/DustParticles';

import { useAccountStore } from '@/store/useAccountStore';
import { useWalletStore }  from '@/store/useWalletStore';
import { listEntries, verify } from '@/services/ledger';
import { formatCurrency } from '@/services/money';
import { playClick } from '@/lib/audio';
import { useT } from '@/lib/i18n';
import Link from 'next/link';

const PostFX = dynamic(() => import('@/components/effects/PostFX'), { ssr: false });

const TYPE_LABELS = {
  DEPOSIT:    { label: 'Dépôt',         tone: 'positive' },
  WITHDRAW:   { label: 'Retrait',       tone: 'negative' },
  BET_LOCK:   { label: 'Mise verrouillée', tone: 'neutral' },
  BET_SETTLE: { label: 'Règlement',     tone: 'context' },
  BONUS:      { label: 'Bonus',         tone: 'positive' },
  ADJUSTMENT: { label: 'Ajustement',    tone: 'neutral' },
};

export default function WalletPage() {
  const router    = useRouter();
  const accountId = useAccountStore((s) => s.accountId);
  const wallet    = useWalletStore();
  const formatted = useWalletStore((s) => s.formatted());
  const t         = useT();
  const [entries, setEntries] = useState([]);
  const [chain, setChain] = useState(null);

  useEffect(() => {
    if (!accountId) { router.replace('/account/login'); return; }
    setEntries(listEntries(accountId).reverse());
    verify().then(setChain);
  }, [accountId, router, wallet.available, wallet.locked]);

  return (
    <section className="relative min-h-screen overflow-hidden grain vignette pt-28 pb-24 px-6">
      {/* atmospheric backdrop */}
      <div className="absolute inset-0 -z-10">
        <Canvas dpr={[1, 1.6]} camera={{ position: [0, 1.6, 5], fov: 50 }}
                gl={{ antialias: true, toneMapping: 2, toneMappingExposure: 0.85 }}>
          <Suspense fallback={null}>
            <fog attach="fog" args={['#05040A', 4, 12]} />
            <CinematicLighting intensity={0.6} />
            <VolumetricBeam position={[0, 5, -3]} height={5} radius={2.0} intensity={0.7} />
            <DustParticles count={300} area={10} />
            <Vault />
            <PostFX intensity={0.95} />
          </Suspense>
        </Canvas>
      </div>

      <div className="relative max-w-5xl mx-auto z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -16 }}
          animate={{ opacity: 1, y:   0 }}
          transition={{ duration: 1.0, ease: [0.22, 1, 0.36, 1] }}
          className="text-center mb-10"
        >
          <div className="flex items-center justify-center gap-3 mb-3">
            <span className="hairline-gold w-12" />
            <span className="engraved text-[9px] text-aurum-gold/80">La Voûte</span>
            <span className="hairline-gold w-12" />
          </div>
          <h1 className="font-display text-5xl md:text-6xl gold-leaf tracking-[0.04em]">
            {t('wallet.title')}
          </h1>
          <p className="mt-3 italic font-display text-aurum-ivory/55">
            {t('wallet.tagline')}
          </p>
        </motion.div>

        {/* Balance cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-10">
          <BalanceCard label={t('wallet.available')} value={formatted.available} primary />
          <BalanceCard label={t('wallet.locked')}    value={formatted.locked} />
          <BalanceCard label={t('wallet.lifetime')}  value={formatted.lifetime} />
        </div>

        {/* Actions */}
        <div className="flex justify-center gap-3 mb-10">
          <Link href="/wallet/deposit" onClick={playClick}>
            <CinematicButton size="md">{t('wallet.deposit')}</CinematicButton>
          </Link>
          <Link href="/wallet/withdraw" onClick={playClick}>
            <button className="px-9 py-3.5 text-[11px] tracking-[0.32em] uppercase font-medium
                              text-aurum-goldHi hover:text-aurum-gold-pale
                              border border-aurum-gold/30 hover:border-aurum-gold/60 rounded-sm
                              transition-colors">
              {t('wallet.withdraw')}
            </button>
          </Link>
        </div>

        {/* Chain integrity */}
        {chain && (
          <GlassPanel tint="noir" className="px-6 py-3 rounded-sm flex items-center justify-between mb-4 text-[10px] tracking-[0.18em]"
            animate={false}>
            <span className="engraved text-aurum-smoke">{t('wallet.chain.label')}</span>
            <span className={chain.ok ? 'text-aurum-goldHi' : 'text-red-400'}>
              {chain.ok
                ? `✓ ${t('wallet.chain.ok')} · ${chain.total} ${t('wallet.entries')}`
                : `✗ ${t('wallet.chain.break')} #${chain.breakAt}`}
            </span>
          </GlassPanel>
        )}

        {/* Ledger */}
        <GlassPanel tint="noir" frame className="rounded-md overflow-hidden" animate={false}>
          <div className="px-6 py-4 flex items-center justify-between border-b border-aurum-gold/15">
            <span className="engraved text-aurum-gold/80">{t('wallet.ledger')}</span>
            <span className="text-[9px] font-mono text-aurum-smoke">
              {entries.length} {t('wallet.entries')}
            </span>
          </div>

          <div className="max-h-[360px] overflow-y-auto">
            {entries.length === 0 ? (
              <div className="p-8 text-center text-aurum-ivory/45 italic font-display">
                {t('wallet.empty')}
              </div>
            ) : (
              <ul>
                {entries.map((e, i) => (
                  <LedgerRow key={e.id} entry={e} odd={i % 2 === 1} />
                ))}
              </ul>
            )}
          </div>
        </GlassPanel>
      </div>
    </section>
  );
}

/* ---------- subcomponents ---------- */

function BalanceCard({ label, value, primary = false }) {
  return (
    <GlassPanel tint="noir" frame={primary} corners className="p-6 rounded-md">
      <div className="engraved text-[8px] text-aurum-gold/70 mb-3">{label}</div>
      <div className={`font-display ${primary ? 'text-5xl' : 'text-3xl'} ${primary ? 'gold-leaf' : 'text-aurum-ivory/85'} tracking-[0.02em]`}>
        {value}
      </div>
    </GlassPanel>
  );
}

function LedgerRow({ entry, odd }) {
  const meta = TYPE_LABELS[entry.type] || { label: entry.type, tone: 'neutral' };
  const date = new Date(entry.timestamp);
  const sign =
    entry.type === 'DEPOSIT' || entry.type === 'BONUS'
      ? '+'
      : entry.type === 'WITHDRAW' || entry.type === 'BET_LOCK'
      ? '−'
      : entry.type === 'BET_SETTLE'
      ? (entry.meta?.outcome === 'WIN' ? '+' : entry.meta?.outcome === 'PUSH' ? '=' : '−')
      : '';
  const amountColor =
    sign === '+' ? '#F4D78A' :
    sign === '−' ? '#E0573B' :
    '#EDE3CE';

  return (
    <li
      className="px-6 py-4 grid grid-cols-[1fr_auto_auto] gap-4 items-center text-sm
                 border-b border-aurum-gold/8 last:border-0"
      style={{ background: odd ? 'rgba(244,215,138,0.02)' : 'transparent' }}
    >
      <div>
        <div className="text-aurum-ivory/85 text-[12px] tracking-[0.06em]">
          {meta.label}
          {entry.meta?.simulated && (
            <span className="ml-2 text-[8px] tracking-[0.32em] text-aurum-smoke">SIM</span>
          )}
          {entry.meta?.outcome && (
            <span className="ml-2 text-[9px] tracking-[0.18em] text-aurum-gold/60">
              · {entry.meta.outcome}
            </span>
          )}
        </div>
        <div className="text-[10px] text-aurum-smoke font-mono mt-0.5">
          {date.toLocaleString('fr-FR')}
        </div>
      </div>
      <div
        className="font-display text-xl tabular-nums"
        style={{ color: amountColor }}
      >
        {sign} {formatCurrency(entry.amount)}
      </div>
      <div className="text-[8px] font-mono text-aurum-smoke truncate max-w-[80px]">
        {entry.hash.slice(0, 8)}…
      </div>
    </li>
  );
}

function Vault() {
  return (
    <group position={[0, 0, -2]}>
      {/* vault door circular */}
      <mesh>
        <torusGeometry args={[1.4, 0.1, 16, 96]} />
        <meshStandardMaterial color="#C8A24A" metalness={1} roughness={0.2} />
      </mesh>
      <mesh>
        <torusGeometry args={[1.55, 0.04, 16, 96]} />
        <meshStandardMaterial color="#7A5C18" metalness={1} roughness={0.35} />
      </mesh>
      {/* hub */}
      <mesh>
        <cylinderGeometry args={[0.35, 0.35, 0.1, 32]} />
        <meshStandardMaterial color="#F4D78A" metalness={1} roughness={0.18} />
      </mesh>
    </group>
  );
}
