/**
 * Lounge layout — currently a passthrough.
 * In V0.2 we'll host shared ambient audio + lighting cross-fades here
 * so navigating between rooms feels like walking through the same
 * continuous space.
 */
export default function LoungeLayout({ children }) {
  return <>{children}</>;
}
