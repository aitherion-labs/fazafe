'use client';

import { useState, useMemo, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useRouter } from 'next/navigation';

import { GameRoom } from '@/ds/scenes';
import { GlassPanel, CinematicButton } from '@/ds/components';
import LowBalanceBanner from '@/components/ui/LowBalanceBanner';

import { playClick, playChip, playReveal } from '@/lib/audio';
import {
  synthChipClink, synthChipStack, synthCardSlide, synthCardFlip,
  synthShuffle, synthFold, synthWinFanfare, synthLoss, synthPhaseDeal,
  synthClick,
} from '@/lib/audioSynth';
import WinParticles from '@/components/poker/WinParticles';
import { useAccountStore } from '@/store/useAccountStore';
import { useWalletStore }  from '@/store/useWalletStore';
import { useT } from '@/lib/i18n';
import { formatCurrency, D, gte } from '@/services/money';
import { auditRound } from '@/services/audit';

import {
  freshDeck, shuffle, evalBest, compareEval, nameOf,
  aiDecisionV2, computeSidePots, awardSidePots,
} from '@/games/poker/engine';

/* ===================================================================== */
/*  Constants                                                            */
/* ===================================================================== */

const BUY_IN_OPTIONS = [50, 100, 200, 500];
const SEAT_OPTIONS   = [3, 4, 6];
const SMALL_BLIND    = 5;
const BIG_BLIND      = 10;

// Phase machine
const PHASE = {
  IDLE: 'IDLE', PREFLOP: 'PREFLOP', FLOP: 'FLOP',
  TURN: 'TURN', RIVER: 'RIVER', SHOWDOWN: 'SHOWDOWN', SETTLE: 'SETTLE',
};
const NEXT_PHASE = {
  [PHASE.PREFLOP]: PHASE.FLOP,
  [PHASE.FLOP]:    PHASE.TURN,
  [PHASE.TURN]:    PHASE.RIVER,
  [PHASE.RIVER]:   PHASE.SHOWDOWN,
};

// Seat positions on screen (% from viewport edges). Seat 0 is always the
// human, anchored bottom-center. Others go counter-clockwise around the
// table so dealing order (button → SB → BB → ... ) progresses visually
// to the LEFT of the human, then up, then right.
const SEATS_BY_N = {
  3: [
    { x: '50%', y: '78%' },                          // 0 bottom (you)
    { x: '20%', y: '34%' },                          // 1 top-left
    { x: '80%', y: '34%' },                          // 2 top-right
  ],
  4: [
    { x: '50%', y: '78%' },                          // 0 bottom
    { x: '18%', y: '50%' },                          // 1 left
    { x: '50%', y: '22%' },                          // 2 top
    { x: '82%', y: '50%' },                          // 3 right
  ],
  6: [
    { x: '50%', y: '80%' },                          // 0 bottom
    { x: '22%', y: '66%' },                          // 1 bottom-left
    { x: '20%', y: '36%' },                          // 2 top-left
    { x: '50%', y: '22%' },                          // 3 top
    { x: '80%', y: '36%' },                          // 4 top-right
    { x: '78%', y: '66%' },                          // 5 bottom-right
  ],
};
const POT_POS = { x: '50%', y: '52%' };

const AI_NAMES = ['Maxime', 'Sasha', 'Hugo', 'Yuki', 'Léa'];

/* ===================================================================== */
/*  Page                                                                 */
/* ===================================================================== */

export default function PokerPage() {
  const router       = useRouter();
  const accountId    = useAccountStore((s) => s.accountId);
  const wallet       = useWalletStore();
  const liveBalance  = useWalletStore((s) => s.available);
  const t            = useT();

  if (!accountId && typeof window !== 'undefined') router.replace('/account/login');

  const [buyIn,        setBuyIn]      = useState(100);
  const [numSeats,     setNumSeats]   = useState(3);
  const [phase,        setPhase]      = useState(PHASE.IDLE);
  const [players,      setPlayers]    = useState([]);
  const [buttonIdx,    setButtonIdx]  = useState(0);
  const [deck,         setDeck]       = useState([]);
  const [community,    setCommunity]  = useState([]);
  const [pot,          setPot]        = useState(0);
  const [currentBet,   setCurrentBet] = useState(0);
  const [minRaise,     setMinRaise]   = useState(BIG_BLIND);
  const [activeIdx,    setActiveIdx]  = useState(0);
  const [lastAction,   setLastAction] = useState(null);
  const [showdown,     setShowdown]   = useState(null);
  const [revealedSeats,setRevealedSeats] = useState(new Set()); // sequential reveal
  const [winnerSeats,  setWinnerSeats]= useState([]);            // who gets particles
  const [flyingChips,  setFlyingChips]= useState([]);
  const [history,      setHistory]    = useState([]);
  const [error,        setError]      = useState(null);
  const [roundId,      setRoundId]    = useState(null);
  const [balanceBefore,setBalanceBefore] = useState(null);
  const [aiThinking,   setAiThinking] = useState(false);
  const [raiseAmount,  setRaiseAmount] = useState(BIG_BLIND * 2);

  const startLockRef = useRef(false);
  const flyingIdRef  = useRef(0);
  const seatPositions = SEATS_BY_N[numSeats] || SEATS_BY_N[3];

  if (!accountId) return null;

  /* ---- Derived ---- */
  const isHandActive = phase !== PHASE.IDLE && phase !== PHASE.SETTLE;
  const isBettingPhase = isHandActive && phase !== PHASE.SHOWDOWN;
  const me = players[0];
  const meTurn = activeIdx === 0 && isBettingPhase && me && !me.folded && !me.isAllIn;
  const toCall = me ? Math.max(0, currentBet - me.currentBet) : 0;
  const canCheck = toCall === 0;
  const canCall  = toCall > 0 && me && me.stack >= 1;  // can always call (all-in if not enough)
  const canRaise = me && me.stack > toCall;
  const computedMinRaise = currentBet + minRaise;
  const maxRaise = me ? me.currentBet + me.stack : 0;

  /* ---- Chip flight animation ---- */
  const launchChips = useCallback((fromSeat, toSeat, amount) => {
    if (amount <= 0) return;
    const id = ++flyingIdRef.current;
    setFlyingChips((cs) => [...cs, {
      id, amount,
      from: fromSeat, to: toSeat,
    }]);
    setTimeout(() => {
      setFlyingChips((cs) => cs.filter((c) => c.id !== id));
    }, 720);
  }, []);

  /* ---- Start a new hand ---- */
  const startHand = async () => {
    if (startLockRef.current || phase !== PHASE.IDLE) return;
    if (!gte(liveBalance, buyIn)) { setError('INSUFFICIENT_FUNDS'); return; }
    startLockRef.current = true;
    try {
      setError(null);
      const balBefore = liveBalance;
      const lock = await wallet.lock(accountId, buyIn, 'poker');
      if (!lock.ok) { setError(lock.reason); return; }

      setRoundId(lock.roundId);
      setBalanceBefore(balBefore);

      // Build fresh deck
      const d = shuffle(freshDeck());

      // Initialize 3 players. Hole cards dealt one-at-a-time around the table (poker tradition).
      const seats = [];
      for (let i = 0; i < numSeats; i++) {
        seats.push({
          id: i === 0 ? 'you' : `ai${i}`,
          name: i === 0 ? 'You' : AI_NAMES[i - 1],
          isAI: i !== 0,
          hole: [],
          stack: buyIn,
          committed: 0,
          currentBet: 0,
          folded: false,
          isAllIn: false,
          seatIdx: i,
        });
      }
      // Deal one card to each player, twice
      for (let pass = 0; pass < 2; pass++) {
        for (let i = 0; i < numSeats; i++) {
          const seatNum = (buttonIdx + 1 + i) % numSeats;
          seats[seatNum].hole.push(d.shift());
        }
      }

      // Post blinds. In 3-max:
      //   button = buttonIdx
      //   SB     = (buttonIdx + 1) % 3
      //   BB     = (buttonIdx + 2) % 3
      const sbIdx = (buttonIdx + 1) % numSeats;
      const bbIdx = (buttonIdx + 2) % numSeats;
      seats[sbIdx].stack      -= SMALL_BLIND;
      seats[sbIdx].committed   = SMALL_BLIND;
      seats[sbIdx].currentBet  = SMALL_BLIND;
      seats[bbIdx].stack      -= BIG_BLIND;
      seats[bbIdx].committed   = BIG_BLIND;
      seats[bbIdx].currentBet  = BIG_BLIND;

      // Pre-flop, action starts left of BB (= button in 3-max)
      const firstToAct = buttonIdx;

      setPlayers(seats);
      setDeck(d);
      setCommunity([]);
      setPot(SMALL_BLIND + BIG_BLIND);
      setCurrentBet(BIG_BLIND);
      setMinRaise(BIG_BLIND);
      setActiveIdx(firstToAct);
      setLastAction(null);
      setShowdown(null);
      setRevealedSeats(new Set());
      setWinnerSeats([]);
      setRaiseAmount(BIG_BLIND * 2);
      setPhase(PHASE.PREFLOP);

      // Animate blinds to pot
      launchChips(sbIdx, -1, SMALL_BLIND);
      launchChips(bbIdx, -1, BIG_BLIND);
      playChip(); synthShuffle(); synthChipStack();
    } finally {
      setTimeout(() => { startLockRef.current = false; }, 800);
    }
  };

  /* ---- AI turn ---- */
  useEffect(() => {
    if (!isBettingPhase) return;
    if (players.length === 0) return;
    const actor = players[activeIdx];
    if (!actor || !actor.isAI || actor.folded || actor.isAllIn) return;
    if (aiThinking) return;

    setAiThinking(true);
    const phaseKey = ({
      [PHASE.PREFLOP]: 'preflop',
      [PHASE.FLOP]:    'flop',
      [PHASE.TURN]:    'turn',
      [PHASE.RIVER]:   'river',
    })[phase];

    const activeOpponents = players.filter((p, i) => i !== activeIdx && !p.folded).length;
    const position = activeIdx === buttonIdx ? 'late'
                   : activeIdx === (buttonIdx + 1) % numSeats ? 'middle'
                   : 'early';

    const decision = aiDecisionV2({
      holeCards: actor.hole,
      community,
      currentBet,
      myBet: actor.currentBet,
      myStack: actor.stack,
      potSize: pot,
      phase: phaseKey,
      nOpponents: activeOpponents,
      position,
      deadCards: [],
      minRaise,
    });

    const delay = 900 + Math.random() * 900;
    const timer = setTimeout(() => {
      applyAction(activeIdx, decision);
      setAiThinking(false);
    }, delay);
    return () => { clearTimeout(timer); setAiThinking(false); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeIdx, phase, players.length]);

  /* ---- Apply an action ---- */
  const applyAction = (actorIdx, decision) => {
    const actor = players[actorIdx];
    if (!actor) return;

    let nextPlayers = [...players];
    let nextPot     = pot;
    let nextCurBet  = currentBet;
    let nextMinRaise = minRaise;
    let logEntry    = { who: actor.id, name: actor.name, action: decision.action };

    if (decision.action === 'fold') {
      nextPlayers[actorIdx] = { ...actor, folded: true };
      playClick(); synthFold();
    } else if (decision.action === 'check') {
      // No state change to amounts
    } else if (decision.action === 'call') {
      const callAmt = Math.max(0, currentBet - actor.currentBet);
      const actual  = Math.min(callAmt, actor.stack);
      nextPlayers[actorIdx] = {
        ...actor,
        stack:      actor.stack - actual,
        currentBet: actor.currentBet + actual,
        committed:  actor.committed + actual,
        isAllIn:    actor.stack - actual === 0,
      };
      nextPot += actual;
      logEntry.amount = actual;
      launchChips(actorIdx, -1, actual);
      playChip(); synthChipClink();
    } else if (decision.action === 'raise') {
      const target = Math.min(decision.amount, actor.currentBet + actor.stack);
      const delta  = target - actor.currentBet;
      nextPlayers[actorIdx] = {
        ...actor,
        stack:      actor.stack - delta,
        currentBet: target,
        committed:  actor.committed + delta,
        isAllIn:    actor.stack - delta === 0,
      };
      nextPot += delta;
      nextMinRaise = Math.max(minRaise, target - currentBet);
      nextCurBet   = target;
      logEntry.amount = target;
      launchChips(actorIdx, -1, delta);
      playChip(); synthChipClink(); synthChipClink();
    }

    setPlayers(nextPlayers);
    setPot(nextPot);
    setCurrentBet(nextCurBet);
    setMinRaise(nextMinRaise);
    setLastAction(logEntry);

    // Determine next state
    setTimeout(() => {
      processAfterAction(nextPlayers, nextCurBet, decision.action === 'raise');
    }, 250);
  };

  /* ---- After an action, decide whether to: next actor / next phase / resolve ---- */
  const processAfterAction = (nextPlayers, nextCurBet, wasRaise) => {
    const active = nextPlayers.filter((p) => !p.folded);
    // Hand over (only 1 player left)
    if (active.length === 1) {
      resolveHand(nextPlayers, { reason: 'fold' });
      return;
    }

    // Round complete?
    const canStillAct = nextPlayers.filter((p) => !p.folded && !p.isAllIn);
    const allMatched = canStillAct.every((p) => p.currentBet === nextCurBet);

    if (allMatched && canStillAct.length <= 1) {
      // Everyone else is all-in or folded — proceed to showdown via fast-forward
      advanceWithRunout(nextPlayers);
      return;
    }
    if (allMatched && !wasRaise) {
      // Round complete — but only if we've heard from everyone after the last raise
      // In our simplified model we treat "all matched and no fresh raise" as complete.
      advancePhase(nextPlayers);
      return;
    }
    // Move to next actor
    const next = findNextActor(activeIdx, nextPlayers);
    if (next === -1) {
      advancePhase(nextPlayers);
    } else {
      setActiveIdx(next);
    }
  };

  /* ---- Find next player who can act ---- */
  const findNextActor = (fromIdx, ps) => {
    for (let step = 1; step <= numSeats; step++) {
      const idx = (fromIdx + step) % numSeats;
      const p = ps[idx];
      if (p && !p.folded && !p.isAllIn) return idx;
    }
    return -1;
  };

  /* ---- Advance to next phase ---- */
  const advancePhase = (ps) => {
    // Reset round bets
    const reset = ps.map((p) => ({ ...p, currentBet: 0 }));
    setPlayers(reset);
    setCurrentBet(0);
    setMinRaise(BIG_BLIND);

    const next = NEXT_PHASE[phase];
    if (!next) return;
    if (next === PHASE.SHOWDOWN) {
      runShowdown(reset);
      return;
    }

    // Deal next community
    const nDealt = next === PHASE.FLOP ? 3 : 1;
    const d = [...deck];
    const dealt = [];
    for (let i = 0; i < nDealt; i++) dealt.push(d.shift());
    setDeck(d);
    setCommunity((c) => [...c, ...dealt]);
    playReveal(); synthPhaseDeal();

    setPhase(next);
    // Post-flop: action starts at first active player left of button
    const sbIdx = (buttonIdx + 1) % numSeats;
    const firstAct = reset[sbIdx] && !reset[sbIdx].folded && !reset[sbIdx].isAllIn
      ? sbIdx
      : findNextActor(sbIdx, reset);
    setActiveIdx(firstAct === -1 ? 0 : firstAct);
  };

  /* ---- Fast-forward runout when everyone else is all-in ---- */
  const advanceWithRunout = (ps) => {
    // Deal remaining community cards immediately, then showdown
    const reset = ps.map((p) => ({ ...p, currentBet: 0 }));
    setPlayers(reset);
    setCurrentBet(0);

    const remaining = 5 - community.length;
    if (remaining > 0) {
      const d = [...deck];
      const newCards = [];
      for (let i = 0; i < remaining; i++) newCards.push(d.shift());
      setDeck(d);
      setCommunity((c) => [...c, ...newCards]);
      playReveal(); synthPhaseDeal();
      // Brief pause for animation
      setTimeout(() => runShowdown(reset), 1200);
    } else {
      runShowdown(reset);
    }
  };

  /* ---- Run showdown ---- */
  const runShowdown = (ps) => {
    setPhase(PHASE.SHOWDOWN);
    playReveal(); synthCardFlip();
    setTimeout(() => resolveHand(ps, { reason: 'showdown' }), 600);
  };

  /* ---- Resolve & settle ---- */
  const resolveHand = async (ps, { reason }) => {
    const sidePots = computeSidePots(ps);
    const { awards, hands } = awardSidePots(sidePots, ps, community);

    // For fold case where no eval happened, award the single pot to the survivor
    let finalAwards = awards;
    if (reason === 'fold') {
      const survivors = ps.filter((p) => !p.folded);
      if (survivors.length === 1) {
        finalAwards = { [survivors[0].id]: pot };
      }
    }

    // Animate awards: chips fly from pot back to winners
    for (const [pid, amt] of Object.entries(finalAwards)) {
      const player = ps.find((p) => p.id === pid);
      if (player && amt > 0) launchChips(-1, player.seatIdx, amt);
    }

    const myAward = finalAwards['you'] || 0;
    const myCommitted = ps[0].committed;
    const myStackLeft = ps[0].stack;
    // Wallet payout = remaining stack at table + winnings from pots
    const payout = String(myStackLeft + myAward);
    // Player's net for the hand
    const playerNet = myAward - myCommitted;
    const outcome = playerNet > 0 ? 'WIN' : playerNet < 0 ? 'LOSS' : 'PUSH';

    setShowdown({
      reason,
      hands,
      awards: finalAwards,
      sidePots,
      playerNet,
      payout,
      outcome,
      revealAll: reason === 'showdown',
    });

    setPhase(PHASE.SETTLE);

    // Sequential card reveal (drama):
    // If this is a fold, only the survivor is "revealed" (their cards stay hidden actually).
    // If this is a showdown, reveal each non-folded player's cards one at a time.
    setRevealedSeats(new Set([0])); // player always revealed
    if (reason === 'showdown') {
      const nonFoldedSeats = ps
        .map((p, idx) => ({ p, idx }))
        .filter(({ p }) => !p.folded && p.id !== 'you')
        .map(({ idx }) => idx);
      nonFoldedSeats.forEach((idx, i) => {
        setTimeout(() => {
          synthCardFlip();
          setRevealedSeats((prev) => new Set([...prev, idx]));
        }, 500 + i * 700);
      });
    }

    // After all reveals: identify winners, play fanfare + spawn particles
    const winnerIdxs = ps
      .map((p, idx) => ({ p, idx }))
      .filter(({ p }) => (finalAwards[p.id] || 0) > 0)
      .map(({ idx }) => idx);

    const revealDelay = reason === 'showdown'
      ? 500 + ps.filter((p) => !p.folded && p.id !== 'you').length * 700
      : 200;

    setTimeout(() => {
      setWinnerSeats(winnerIdxs);
      if (outcome === 'WIN')      synthWinFanfare();
      else if (outcome === 'LOSS') synthLoss();
    }, revealDelay);

    await wallet.settle(accountId, {
      roundId,
      stake: String(buyIn),
      payout,
      outcome,
      meta: {
        game: 'poker',
        reason,
        players: ps.map((p) => ({
          id: p.id, hole: p.hole, committed: p.committed, folded: p.folded, isAllIn: p.isAllIn,
        })),
        community,
        sidePots,
        awards: finalAwards,
      },
    });

    const balAfter = useWalletStore.getState().available;

    auditRound({
      gameId: 'poker',
      roundId,
      accountId,
      bets: [{ type: 'BUYIN', amount: String(buyIn), label: 'Hold\'em hand' }],
      stake: String(buyIn),
      result: {
        reason,
        awards: finalAwards,
        myHand: hands['you']?.name || null,
      },
      payout, outcome,
      balanceBefore: balanceBefore || liveBalance,
      balanceAfter: balAfter,
      extra: {
        myHole: ps[0].hole.map((c) => `${c.r}${c.s}`),
        community: community.map((c) => `${c.r}${c.s}`),
      },
    });

    setHistory((h) => [{
      ts: Date.now(), outcome, net: playerNet,
      myHand: hands['you']?.name || null,
    }, ...h].slice(0, 8));
  };

  /* ---- Player actions ---- */
  const doFold  = () => meTurn && applyAction(0, { action: 'fold' });
  const doCheck = () => meTurn && canCheck && applyAction(0, { action: 'check' });
  const doCall  = () => meTurn && canCall && applyAction(0, { action: 'call' });
  const doRaise = () => {
    if (!meTurn || !canRaise) return;
    const amt = Math.max(computedMinRaise, Math.min(maxRaise, raiseAmount));
    applyAction(0, { action: 'raise', amount: amt });
  };

  const newHand = () => {
    if (phase !== PHASE.SETTLE) return;
    playClick();
    // Rotate the button for next hand
    setButtonIdx((b) => (b + 1) % numSeats);
    setPhase(PHASE.IDLE);
  };

  /* ---- 3D world ---- */
  const world = useMemo(() => <PokerTable />, []);

  /* ---- Overlay ---- */
  const overlay = (
    <>
      <BackToHall router={router} t={t} />
      <LowBalanceBanner visible={phase === PHASE.IDLE && !gte(liveBalance, BUY_IN_OPTIONS[0])} />

      <motion.div
        initial={{ opacity: 0, y: -16 }} animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4, duration: 0.9 }}
        className="absolute top-24 left-1/2 -translate-x-1/2 text-center z-30"
      >
        <div className="flex items-center justify-center gap-3 mb-1">
          <span className="hairline-gold w-8" />
          <span className="engraved text-[8px] text-aurum-gold/80">{t('poker.subtitle')}</span>
          <span className="hairline-gold w-8" />
        </div>
        <h2 className="font-display text-3xl md:text-4xl gold-leaf tracking-[0.06em]">
          {t('poker.title')}
        </h2>
      </motion.div>

      {/* Player seats */}
      {players.map((p, i) => (
        <Seat
          key={p.id}
          player={p}
          seatIdx={i}
          seatPositions={seatPositions}
          isButton={i === buttonIdx}
          isActive={activeIdx === i && isBettingPhase}
          thinking={p.isAI && activeIdx === i && aiThinking}
          showCards={
            i === 0
              ? isHandActive || phase === PHASE.SETTLE
              : (revealedSeats.has(i) || false)
          }
          showWinHand={revealedSeats.has(i) ? showdown?.hands?.[p.id] : null}
          isWinner={winnerSeats.includes(i)}
          t={t}
        />
      ))}

      {/* Community + pot */}
      <CommunityCards community={community} bestCardsByPlayer={showdown?.hands} />
      {pot > 0 && <PotDisplay pot={pot} phase={phase} t={t} />}

      {/* Win particles per winner seat */}
      {winnerSeats.map((idx) => (
        <WinParticles key={`win-${idx}`} active origin={seatPositions[idx]} count={36} />
      ))}

      {/* Phase indicator */}
      <PhaseIndicator phase={phase} t={t} />

      {/* Flying chips */}
      <FlyingChipsLayer chips={flyingChips} seatPositions={seatPositions} />

      {/* Showdown overlay */}
      {showdown && (phase === PHASE.SHOWDOWN || phase === PHASE.SETTLE) && (
        <ShowdownOverlay showdown={showdown} onNewHand={newHand} t={t} players={players} />
      )}

      {/* Action HUD */}
      {phase === PHASE.IDLE ? (
        <IdleHUD
          buyIn={buyIn} setBuyIn={setBuyIn}
          numSeats={numSeats} setNumSeats={setNumSeats}
          onStart={startHand} error={error} t={t}
        />
      ) : meTurn ? (
        <ActionHUD
          toCall={toCall}
          canCheck={canCheck} canCall={canCall} canRaise={canRaise}
          raiseAmount={raiseAmount} setRaiseAmount={setRaiseAmount}
          minRaise={computedMinRaise} maxRaise={maxRaise}
          doFold={doFold} doCheck={doCheck} doCall={doCall} doRaise={doRaise}
          t={t}
        />
      ) : null}
    </>
  );

  return (
    <GameRoom
      world={world}
      overlay={overlay}
      cameraProps={{ position: [0, 3.8, 4.8], fov: 42 }}
      beamProps={{ position: [0, 6, 0], height: 5, radius: 2.8, intensity: 0.9 }}
      fogColor="#06040C"
    />
  );
}

/* ===================================================================== */
/*  UI sub-components                                                    */
/* ===================================================================== */

function BackToHall({ router, t }) {
  return (
    <motion.button
      initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}
      transition={{ delay: 0.6, duration: 0.7 }}
      onClick={() => { playClick(); router.push('/lounge'); }}
      className="absolute top-24 left-8 engraved text-aurum-ivory/60 hover:text-aurum-goldHi
                 flex items-center gap-3 group z-30"
    >
      <span className="w-8 h-px bg-aurum-gold/40 group-hover:bg-aurum-goldHi transition-colors" />
      {t('game.back')}
    </motion.button>
  );
}

function Seat({ player, seatIdx, seatPositions, isButton, isActive, thinking, showCards, showWinHand, isWinner, t }) {
  const pos = seatPositions[seatIdx];
  return (
    <div
      className="absolute z-30 text-center pointer-events-none"
      style={{
        left: pos.x, top: pos.y,
        transform: 'translate(-50%, -50%)',
      }}
    >
      {/* Hole cards */}
      <div className="flex items-end justify-center gap-2 mb-2">
        {(player.hole.length ? player.hole : [null, null]).map((c, i) => {
          const isInWinning = showWinHand?.usedCards?.some(
            (uc) => uc && c && uc.r === c.r && uc.s === c.s
          );
          return (
            <PokerCard
              key={i}
              card={c}
              hidden={!showCards || !c}
              folded={player.folded}
              highlight={isInWinning}
            />
          );
        })}
      </div>

      {/* Nameplate */}
      <motion.div
        animate={
          isWinner
            ? { scale: [1, 1.08, 1.04], opacity: 1 }
            : isActive
            ? { scale: [1, 1.03, 1], opacity: [0.85, 1, 0.85] }
            : { scale: 1, opacity: 1 }
        }
        transition={
          isWinner
            ? { duration: 1.2, repeat: Infinity, ease: 'easeInOut' }
            : isActive
            ? { duration: 1.3, repeat: Infinity }
            : { duration: 0.3 }
        }
        className="inline-block px-3 py-1.5 rounded-full pointer-events-auto"
        style={{
          background: isWinner ? 'rgba(40,28,8,0.92)' : 'rgba(8,4,2,0.85)',
          border: isWinner
            ? '1.5px solid #F4D78A'
            : isActive ? '1px solid #F4D78A' : '1px solid rgba(244,215,138,0.25)',
          boxShadow: isWinner
            ? '0 0 24px rgba(244,215,138,0.85), inset 0 1px 0 rgba(255,241,199,0.3)'
            : isActive ? '0 0 12px rgba(244,215,138,0.5)' : 'none',
          backdropFilter: 'blur(4px)',
        }}
      >
        <div className="flex items-center gap-2 text-[10px] tracking-[0.18em]">
          {isButton && (
            <span
              className="w-4 h-4 rounded-full flex items-center justify-center text-[8px] text-aurum-black font-bold"
              style={{ background: '#F4D78A', boxShadow: '0 0 6px rgba(244,215,138,0.7)' }}
            >D</span>
          )}
          <span className="text-aurum-ivory/80 uppercase">{player.name}</span>
          <span className="text-aurum-gold/40">·</span>
          <span className="font-display text-aurum-goldHi tabular-nums">${player.stack}</span>
          {player.currentBet > 0 && (
            <>
              <span className="text-aurum-gold/40">·</span>
              <span className="font-display text-aurum-gold-pale tabular-nums text-[10px]">
                ${player.currentBet}
              </span>
            </>
          )}
        </div>
        {(thinking || player.folded || player.isAllIn || showWinHand) && (
          <div className="mt-0.5 engraved text-[7px] tracking-[0.32em]"
               style={{
                 color: player.folded ? '#9C9C9C'
                       : player.isAllIn ? '#E0573B'
                       : showWinHand ? '#F4D78A' : '#C8A24A',
               }}>
            {player.folded ? t('poker.folded')
              : player.isAllIn ? t('poker.allIn')
              : showWinHand ? showWinHand.name
              : `${t('poker.thinking')}…`}
          </div>
        )}
      </motion.div>
    </div>
  );
}

function PokerCard({ card, hidden, folded, highlight }) {
  const isRed = card && (card.s === '♥' || card.s === '♦');
  return (
    <motion.div
      initial={{ rotateY: 180, opacity: 0, y: -10 }}
      animate={{
        rotateY: hidden ? 180 : 0,
        opacity: folded ? 0.35 : 1,
        y: highlight ? -6 : 0,
        scale: highlight ? 1.05 : 1,
      }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      style={{
        transformStyle: 'preserve-3d',
        perspective: 800,
        filter: highlight ? 'drop-shadow(0 0 12px #F4D78A)' : 'none',
      }}
      className="relative w-[58px] h-[82px]"
    >
      <div
        className="absolute inset-0 rounded-md flex flex-col items-center justify-between p-1.5"
        style={{
          background: 'linear-gradient(180deg, #FAF3E0, #E8DCB8)',
          color: isRed ? '#7A0E14' : '#0A0608',
          border: '1px solid rgba(244,215,138,0.6)',
          backfaceVisibility: 'hidden',
          boxShadow: '0 4px 10px rgba(0,0,0,0.5)',
          fontFamily: 'Cormorant Garamond, serif',
        }}
      >
        {card ? (
          <>
            <div className="self-start text-[13px] leading-none font-semibold">{card.r}</div>
            <div className="text-[26px] leading-none">{card.s}</div>
            <div className="self-end text-[13px] leading-none font-semibold rotate-180">{card.r}</div>
          </>
        ) : null}
      </div>
      <div
        className="absolute inset-0 rounded-md flex items-center justify-center"
        style={{
          background: 'linear-gradient(135deg, #2A0E08, #0A0608)',
          border: '1px solid rgba(244,215,138,0.4)',
          backfaceVisibility: 'hidden',
          transform: 'rotateY(180deg)',
          boxShadow: '0 4px 10px rgba(0,0,0,0.5)',
        }}
      >
        <span className="font-display text-[18px] gold-leaf">★</span>
      </div>
    </motion.div>
  );
}

function CommunityCards({ community, bestCardsByPlayer }) {
  // Highlight cards that are in any revealed best-hand usedCards
  const winningCardKeys = useMemo(() => {
    if (!bestCardsByPlayer) return new Set();
    const keys = new Set();
    for (const h of Object.values(bestCardsByPlayer)) {
      if (h.usedCards) {
        for (const c of h.usedCards) keys.add(`${c.r}${c.s}`);
      }
    }
    return keys;
  }, [bestCardsByPlayer]);

  return (
    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-20">
      <div className="flex items-center justify-center gap-2">
        {[0, 1, 2, 3, 4].map((i) => {
          const c = community[i];
          const isWin = c && winningCardKeys.has(`${c.r}${c.s}`);
          return (
            <motion.div
              key={i}
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: c ? 1 : 0.85, opacity: c ? 1 : 0.25 }}
              transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1], delay: c ? i * 0.06 : 0 }}
            >
              <PokerCard card={c || null} hidden={!c} highlight={isWin} />
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}

function PotDisplay({ pot, phase, t }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="absolute z-20 text-center pointer-events-none"
      style={{
        left: POT_POS.x,
        top: '40%',
        transform: 'translate(-50%, -50%)',
      }}
    >
      <div className="engraved text-[8px] text-aurum-gold/70 tracking-[0.32em] mb-1">
        {t('poker.pot')}
      </div>
      <motion.div
        key={pot}
        initial={{ scale: 1.15 }}
        animate={{ scale: 1 }}
        className="font-display text-2xl gold-leaf tabular-nums"
        style={{ filter: 'drop-shadow(0 0 10px rgba(244,215,138,0.45))' }}
      >
        ${pot}
      </motion.div>
    </motion.div>
  );
}

function PhaseIndicator({ phase, t }) {
  return (
    <div className="absolute top-44 right-8 z-30 flex items-center gap-2">
      <motion.span
        animate={{ opacity: [0.5, 1, 0.5] }}
        transition={{ duration: 1.4, repeat: Infinity }}
        className="w-1.5 h-1.5 rounded-full"
        style={{ background: '#F4D78A', boxShadow: '0 0 8px #F4D78A' }}
      />
      <span className="engraved text-[8px] text-aurum-gold/70 tracking-[0.32em]">{phase}</span>
    </div>
  );
}

/* ---- Flying chips animation layer ---- */
function FlyingChipsLayer({ chips, seatPositions }) {
  return (
    <div className="absolute inset-0 pointer-events-none z-40">
      {chips.map((c) => {
        const from = c.from === -1 ? POT_POS : seatPositions[c.from];
        const to   = c.to === -1   ? POT_POS : seatPositions[c.to];
        return (
          <motion.div
            key={c.id}
            initial={{
              left: from.x, top: from.y,
              opacity: 0, scale: 0.6,
            }}
            animate={{
              left: to.x, top: to.y,
              opacity: [0, 1, 1, 0],
              scale: [0.6, 1, 1, 0.8],
            }}
            transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
            className="absolute"
            style={{ transform: 'translate(-50%, -50%)' }}
          >
            <FlyingChipStack amount={c.amount} />
          </motion.div>
        );
      })}
    </div>
  );
}

function FlyingChipStack({ amount }) {
  // Show a small chip + amount label
  return (
    <div className="flex items-center gap-1.5">
      <svg viewBox="0 0 100 100" width={24} height={24}>
        <circle cx="50" cy="50" r="46" fill="#C8A24A" />
        <circle cx="50" cy="50" r="36" fill="#3A2E22" stroke="#F4D78A" strokeWidth="2" />
        <text x="50" y="58" textAnchor="middle" fontFamily="Cormorant Garamond, serif"
              fontSize="22" fontWeight="600" fill="#F4D78A">
          $
        </text>
      </svg>
      <span className="font-display text-[12px] gold-leaf tabular-nums"
            style={{ filter: 'drop-shadow(0 0 4px rgba(244,215,138,0.6))' }}>
        ${amount}
      </span>
    </div>
  );
}

/* ---- Idle (between hands) ---- */
function IdleHUD({ buyIn, setBuyIn, numSeats, setNumSeats, onStart, error, t }) {
  return (
    <div className="absolute z-40"
         style={{ bottom: '3rem', left: '50%', transform: 'translateX(-50%)' }}>
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.7 }}>
        <GlassPanel tint="noir" frame corners animate={false} className="px-8 py-5 rounded-md">
          <div className="flex flex-wrap items-center justify-center gap-x-8 gap-y-3">
            <div className="text-center">
              <div className="engraved text-[8px] text-aurum-gold/70 mb-2 tracking-[0.22em]">
                {t('poker.buyIn')}
              </div>
              <div className="flex items-center gap-2">
                {BUY_IN_OPTIONS.map((v) => (
                  <motion.button
                    key={v}
                    whileTap={{ scale: 0.94 }}
                    whileHover={{ y: -1 }}
                    onClick={() => { playClick(); synthClick(); setBuyIn(v); }}
                    className={`px-3 py-2 rounded-sm text-[12px] tracking-[0.18em] font-display transition-colors
                      ${buyIn === v ? 'gold-leaf' : 'text-aurum-ivory/55 hover:text-aurum-goldHi'}`}
                    style={{
                      background: buyIn === v
                        ? 'linear-gradient(180deg, rgba(244,215,138,0.18), rgba(0,0,0,0.4))'
                        : 'rgba(15,11,22,0.5)',
                      border: '1px solid rgba(244,215,138,0.18)',
                    }}
                  >${v}</motion.button>
                ))}
              </div>
            </div>

            <div className="w-px h-12 bg-aurum-gold/20" />

            <div className="text-center">
              <div className="engraved text-[8px] text-aurum-gold/70 mb-2 tracking-[0.22em]">
                {t('poker.seats') || 'Seats'}
              </div>
              <div className="flex items-center gap-2">
                {SEAT_OPTIONS.map((n) => (
                  <motion.button
                    key={n}
                    whileTap={{ scale: 0.94 }}
                    whileHover={{ y: -1 }}
                    onClick={() => { playClick(); synthClick(); setNumSeats(n); }}
                    className={`w-10 h-10 rounded-full text-[12px] font-display transition-colors
                      ${numSeats === n ? 'gold-leaf' : 'text-aurum-ivory/55 hover:text-aurum-goldHi'}`}
                    style={{
                      background: numSeats === n
                        ? 'linear-gradient(180deg, rgba(244,215,138,0.18), rgba(0,0,0,0.4))'
                        : 'rgba(15,11,22,0.5)',
                      border: '1px solid rgba(244,215,138,0.18)',
                    }}
                  >{n}</motion.button>
                ))}
              </div>
            </div>

            <div className="w-px h-12 bg-aurum-gold/20" />

            <CinematicButton onClick={onStart} size="md">
              {t('poker.deal')} · ${buyIn}
            </CinematicButton>
          </div>
          {error && (
            <div className="text-center mt-3 text-[10px] tracking-[0.18em] text-red-400/80">
              {error.replace(/_/g, ' ')}
            </div>
          )}
        </GlassPanel>
      </motion.div>
    </div>
  );
}

/* ---- Action HUD (during player's turn) ---- */
function ActionHUD({
  toCall, canCheck, canCall, canRaise,
  raiseAmount, setRaiseAmount, minRaise, maxRaise,
  doFold, doCheck, doCall, doRaise, t,
}) {
  return (
    <div className="absolute z-40"
         style={{ bottom: '3rem', left: '50%', transform: 'translateX(-50%)' }}>
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.4 }}>
        <GlassPanel tint="noir" frame corners animate={false} className="px-6 py-4 rounded-md">
          <div className="flex flex-wrap items-center justify-center gap-x-4 gap-y-3">
            <ActionButton onClick={doFold} variant="danger" label={t('poker.fold')} />

            {canCheck ? (
              <ActionButton onClick={doCheck} variant="neutral" label={t('poker.check')} />
            ) : (
              <ActionButton onClick={doCall} variant="primary" disabled={!canCall}
                label={`${t('poker.call')} $${toCall}`} />
            )}

            <div className="w-px h-10 bg-aurum-gold/20" />

            <div className="flex flex-col items-center gap-1">
              <div className="engraved text-[7px] text-aurum-gold/70 tracking-[0.22em]">
                {t('poker.raiseTo')}
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setRaiseAmount(Math.max(minRaise, raiseAmount - BIG_BLIND))}
                  className="w-6 h-6 rounded-sm text-[10px] text-aurum-ivory/70 hover:text-aurum-goldHi
                             border border-aurum-gold/25 hover:border-aurum-goldHi"
                >−</button>
                <span className="font-display text-aurum-goldHi tabular-nums text-base min-w-[50px] text-center">
                  ${Math.max(minRaise, Math.min(maxRaise, raiseAmount))}
                </span>
                <button
                  onClick={() => setRaiseAmount(Math.min(maxRaise, raiseAmount + BIG_BLIND))}
                  className="w-6 h-6 rounded-sm text-[10px] text-aurum-ivory/70 hover:text-aurum-goldHi
                             border border-aurum-gold/25 hover:border-aurum-goldHi"
                >+</button>
              </div>
              <button
                onClick={() => setRaiseAmount(maxRaise)}
                className="text-[7px] tracking-[0.22em] text-aurum-gold/55 hover:text-aurum-goldHi mt-0.5"
              >ALL-IN ${maxRaise}</button>
            </div>

            <ActionButton onClick={doRaise} variant="gold" disabled={!canRaise} label={t('poker.raise')} />
          </div>
        </GlassPanel>
      </motion.div>
    </div>
  );
}

function ActionButton({ onClick, variant, label, disabled }) {
  const styles = {
    danger:  { color: '#FFB48A', border: 'rgba(224,87,59,0.5)',  bg: 'rgba(40,12,10,0.6)' },
    neutral: { color: '#EDE3CE', border: 'rgba(244,215,138,0.25)', bg: 'rgba(15,11,22,0.6)' },
    primary: { color: '#F4D78A', border: 'rgba(244,215,138,0.5)',  bg: 'rgba(15,11,22,0.7)' },
    gold: { color: '#0A0608', border: 'rgba(244,215,138,0.7)',
      bg: 'linear-gradient(180deg, #FFF1C7 0%, #C8A24A 60%, #7A5C18 100%)' },
  }[variant] || {};
  return (
    <motion.button
      whileTap={{ scale: 0.94 }}
      whileHover={!disabled ? { y: -1 } : {}}
      onClick={onClick}
      disabled={disabled}
      className="px-5 py-2.5 rounded-sm text-[11px] tracking-[0.22em] uppercase font-medium
                 transition-all disabled:opacity-30"
      style={{ background: styles.bg, color: styles.color, border: `1px solid ${styles.border}` }}
    >{label}</motion.button>
  );
}

/* ---- Showdown overlay ---- */
function ShowdownOverlay({ showdown, onNewHand, t, players }) {
  const won = (showdown.awards['you'] || 0) > 0;
  const isPush = showdown.outcome === 'PUSH';

  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
      className="absolute top-32 right-8 z-50 w-[320px] max-w-[32vw]"
    >
      <GlassPanel tint="noir" frame corners animate={false} className="p-5 rounded-md">
        <div className="text-center mb-3">
          <div className="engraved text-[8px] text-aurum-gold/70 tracking-[0.32em] mb-2">
            {showdown.reason === 'fold' ? t('poker.foldedWinner') : t('poker.showdown')}
          </div>
          <div
            className="font-display text-3xl gold-leaf tabular-nums"
            style={{
              color: showdown.outcome === 'WIN' ? '#F4D78A'
                   : showdown.outcome === 'PUSH' ? '#EDE3CE' : '#9C9C9C',
              filter: showdown.outcome === 'WIN' ? 'drop-shadow(0 0 12px #F4D78A)' : 'none',
            }}
          >
            {showdown.playerNet > 0 ? '+' : ''}${showdown.playerNet}
          </div>
          <div className="engraved text-[9px] text-aurum-goldHi tracking-[0.32em] mt-1">
            {showdown.outcome === 'WIN' ? t('poker.youWin')
              : isPush ? t('poker.tie') : t('poker.youLose')}
          </div>
        </div>

        <div className="hairline-gold opacity-50 mb-3" />

        {/* Side pots */}
        {showdown.sidePots && showdown.sidePots.length > 0 && (
          <>
            <div className="engraved text-[7px] text-aurum-gold/55 tracking-[0.22em] mb-1.5">
              {t('poker.sidePots') || 'POTS'}
            </div>
            <div className="space-y-1 mb-3 text-[10px]">
              {showdown.sidePots.map((p, i) => (
                <div key={i} className="flex items-center justify-between">
                  <span className="text-aurum-ivory/70">
                    {i === 0 ? t('poker.mainPot') || 'Main' : `Side ${i}`}
                  </span>
                  <span className="font-display text-aurum-goldHi tabular-nums">${p.amount}</span>
                </div>
              ))}
            </div>
            <div className="hairline-gold opacity-30 mb-3" />
          </>
        )}

        {/* Hands shown (for showdowns) */}
        {showdown.reason === 'showdown' && (
          <div className="space-y-1 text-[10px] mb-3">
            {players.map((p) => {
              const h = showdown.hands[p.id];
              const award = showdown.awards[p.id] || 0;
              if (p.folded) return null;
              return (
                <div key={p.id} className="flex items-center justify-between">
                  <span className="text-aurum-ivory/75">{p.name}</span>
                  <span className="font-display text-aurum-ivory/85 text-[10px]">
                    {h ? h.name : '—'}
                  </span>
                  {award > 0 && (
                    <span className="font-display text-aurum-goldHi tabular-nums text-[10px]">
                      +${award}
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        )}

        <button
          onClick={onNewHand}
          className="w-full mt-2 px-3 py-2 rounded-sm text-[10px] tracking-[0.22em] uppercase
                     text-aurum-goldHi hover:text-aurum-gold-pale
                     border border-aurum-goldHi/40 hover:border-aurum-goldHi/70
                     transition-colors"
        >
          {t('poker.newHand')}
        </button>
      </GlassPanel>
    </motion.div>
  );
}

/* ---- 3D Table — wood rail + felt + ornament ---- */
function PokerTable() {
  return (
    <group position={[0, 0, 0]}>
      {/* Wooden rail (outer ring) */}
      <mesh position={[0, 0.18, 0]} castShadow receiveShadow>
        <torusGeometry args={[3.25, 0.18, 16, 64]} />
        <meshStandardMaterial color="#3A1E0E" roughness={0.4} metalness={0.1} />
      </mesh>
      {/* Inner gold trim */}
      <mesh position={[0, 0.10, 0]} receiveShadow>
        <cylinderGeometry args={[3.05, 3.05, 0.05, 64]} />
        <meshStandardMaterial color="#7A5C18" metalness={0.7} roughness={0.3} />
      </mesh>
      {/* Felt surface */}
      <mesh position={[0, 0.07, 0]} receiveShadow>
        <cylinderGeometry args={[3.00, 3.00, 0.04, 64]} />
        <meshStandardMaterial color="#0E2A1E" roughness={0.95} />
      </mesh>
      {/* Inner felt ring (darker, for "betting area") */}
      <mesh position={[0, 0.075, 0]} receiveShadow>
        <ringGeometry args={[1.4, 1.55, 64]} />
        <meshStandardMaterial color="#1A4030" roughness={0.95} side={2 /* DoubleSide */} />
      </mesh>
      {/* Center dot */}
      <mesh position={[0, 0.08, 0]} receiveShadow>
        <cylinderGeometry args={[0.18, 0.18, 0.02, 32]} />
        <meshStandardMaterial color="#C8A24A" metalness={0.85} roughness={0.25} />
      </mesh>
      {/* Subtle base */}
      <mesh position={[0, -0.05, 0]} receiveShadow>
        <cylinderGeometry args={[3.4, 3.4, 0.2, 64]} />
        <meshStandardMaterial color="#1A0E08" roughness={0.7} />
      </mesh>
    </group>
  );
}
