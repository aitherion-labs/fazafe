'use client';

import { useState, useMemo, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useRouter } from 'next/navigation';
import * as THREE from 'three';

import { GameRoom } from '@/ds/scenes';
import { GlassPanel, CinematicButton } from '@/ds/components';
import LowBalanceBanner from '@/components/ui/LowBalanceBanner';
import ChipSelector from '@/components/ui/ChipSelector';

import { playClick, playChip, playReveal } from '@/lib/audio';
import { synthChipClink, synthClick, synthWinFanfare, synthLoss } from '@/lib/audioSynth';

import { useAccountStore } from '@/store/useAccountStore';
import { useWalletStore }  from '@/store/useWalletStore';
import { useT } from '@/lib/i18n';
import { formatCurrency, D, gte } from '@/services/money';
import { auditRound } from '@/services/audit';

import {
  ROWS, SLOTS, RISK, MULTIPLIERS, RTP,
  generatePath, getMultiplier, buildBoardLayout, pathToKeyframes,
} from '@/games/plinko/engine';

/* ---------- Constants ---------- */

const STAKE_OPTIONS = [1, 5, 10, 25, 50, 100];
const PHASE = {
  IDLE:    'IDLE',
  DROP:    'DROP',
  LANDED:  'LANDED',
};

// Board geometry (SVG coordinate system)
const BOARD = {
  width:  480,
  height: 470,
  centerX: 240,
  topY: 38,
  rowSpacing: 26,
  pegSpacing: 28,
};

/* ===================================================================== */

export default function PlinkoPage() {
  const router       = useRouter();
  const accountId    = useAccountStore((s) => s.accountId);
  const wallet       = useWalletStore();
  const liveBalance  = useWalletStore((s) => s.available);
  const t            = useT();

  if (!accountId && typeof window !== 'undefined') router.replace('/account/login');

  const [stake,     setStake]   = useState(10);
  const [risk,      setRisk]    = useState(RISK.SAFE);
  const [phase,     setPhase]   = useState(PHASE.IDLE);
  const [activeBall,setActiveBall] = useState(null); // { id, keyframes, slotIdx, multiplier, payout }
  const [history,   setHistory] = useState([]);
  const [error,     setError]   = useState(null);
  const [lastResult,setLastResult] = useState(null);

  const dropLockRef = useRef(false);
  const ballIdRef   = useRef(0);

  if (!accountId) return null;

  /* ---- Board layout (memoized) ---- */
  const layout = useMemo(
    () => buildBoardLayout({
      rows: ROWS,
      centerX: BOARD.centerX, topY: BOARD.topY,
      rowSpacing: BOARD.rowSpacing, pegSpacing: BOARD.pegSpacing,
    }),
    []
  );

  /* ---- Drop ball ---- */
  const dropBall = async () => {
    if (dropLockRef.current) return;
    if (phase !== PHASE.IDLE) return;
    if (!gte(liveBalance, stake)) { setError('INSUFFICIENT_FUNDS'); return; }
    dropLockRef.current = true;
    try {
      setError(null);
      const balBefore = liveBalance;

      // Lock stake from wallet
      const lock = await wallet.lock(accountId, stake, 'plinko');
      if (!lock.ok) { setError(lock.reason); return; }

      // Generate path
      const { path, slotIdx } = generatePath();
      const keyframes = pathToKeyframes(path, layout);
      const multiplier = getMultiplier(risk, slotIdx);
      const payout = (stake * multiplier).toFixed(2);

      const id = ++ballIdRef.current;
      setActiveBall({ id, keyframes, slotIdx, multiplier, payout, path });
      setPhase(PHASE.DROP);
      synthChipClink();
      playChip();

      // Animation duration approx 2.6s; settle after
      const animDuration = 2600;
      setTimeout(() => settle({
        balBefore, slotIdx, multiplier, payout, roundId: lock.roundId, path,
      }), animDuration);
    } finally {
      setTimeout(() => { dropLockRef.current = false; }, 800);
    }
  };

  const settle = async ({ balBefore, slotIdx, multiplier, payout, roundId, path }) => {
    setPhase(PHASE.LANDED);

    const outcome = multiplier >= 1 ? 'WIN' : multiplier > 0 ? 'PARTIAL' : 'LOSS';
    await wallet.settle(accountId, {
      roundId,
      stake: String(stake),
      payout,
      outcome,
      meta: { game: 'plinko', risk, slotIdx, multiplier, rows: ROWS },
    });
    const balAfter = useWalletStore.getState().available;

    const net = Number(payout) - stake;

    auditRound({
      gameId: 'plinko',
      roundId,
      accountId,
      bets: [{ type: 'STAKE', amount: String(stake), label: `Plinko ${risk}` }],
      stake: String(stake),
      result: { risk, slotIdx, multiplier, path: path.join('') },
      payout, outcome,
      balanceBefore: balBefore,
      balanceAfter:  balAfter,
    });

    setLastResult({ slotIdx, multiplier, payout, net, risk });
    setHistory((h) => [{
      ts: Date.now(), slotIdx, multiplier, net, risk,
    }, ...h].slice(0, 12));

    if (multiplier >= 2)      synthWinFanfare();
    else if (multiplier < 1)  synthLoss();
    playReveal();
  };

  const nextDrop = () => {
    if (phase !== PHASE.LANDED) return;
    setActiveBall(null);
    setPhase(PHASE.IDLE);
  };

  /* ---- 3D world ---- */
  const world = useMemo(() => <PlinkoStage />, []);

  /* ---- Overlay ---- */
  const overlay = (
    <>
      <BackToHall router={router} t={t} />
      <LowBalanceBanner visible={phase === PHASE.IDLE && !gte(liveBalance, STAKE_OPTIONS[0])} />

      {/* Title */}
      <motion.div
        initial={{ opacity: 0, y: -16 }} animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4, duration: 0.9 }}
        className="absolute top-24 left-1/2 -translate-x-1/2 text-center z-30"
      >
        <div className="flex items-center justify-center gap-3 mb-1">
          <span className="hairline-gold w-8" />
          <span className="engraved text-[8px] text-aurum-gold/80">{t('plinko.subtitle')}</span>
          <span className="hairline-gold w-8" />
        </div>
        <h2 className="font-display text-3xl md:text-4xl gold-leaf tracking-[0.06em]">
          {t('plinko.title')}
        </h2>
      </motion.div>

      {/* Board */}
      <PlinkoBoard
        layout={layout}
        risk={risk}
        activeBall={activeBall}
        phase={phase}
        landedSlot={lastResult?.slotIdx}
        landedMultiplier={lastResult?.multiplier}
      />

      {/* History strip */}
      {history.length > 0 && (
        <div className="absolute top-44 left-8 z-30 max-w-[280px]">
          <div className="engraved text-[8px] text-aurum-gold/55 tracking-[0.32em] mb-2">
            {t('plinko.history')}
          </div>
          <div className="flex flex-wrap gap-1.5">
            {history.map((h, i) => (
              <div
                key={i}
                className="px-2 py-0.5 rounded-sm text-[10px] tabular-nums font-display"
                style={{
                  background: 'rgba(8,4,2,0.7)',
                  border: '1px solid rgba(244,215,138,0.25)',
                  color: h.multiplier >= 2 ? '#F4D78A'
                       : h.multiplier >= 1 ? '#EDE3CE'
                       : h.multiplier >= 0.7 ? '#C8A24A'
                       : '#E0573B',
                }}
              >
                {h.multiplier}×
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Result panel — replaces idle HUD when LANDED */}
      {phase === PHASE.LANDED && lastResult && (
        <ResultPanel result={lastResult} stake={stake} onNext={nextDrop} t={t} />
      )}

      {/* Action HUD */}
      {phase === PHASE.IDLE && (
        <IdleHUD
          stake={stake} setStake={setStake}
          risk={risk}   setRisk={setRisk}
          onDrop={dropBall}
          error={error}
          t={t}
        />
      )}

      {phase === PHASE.DROP && (
        <div className="absolute z-40 left-1/2 bottom-12 -translate-x-1/2 text-center">
          <div className="engraved text-[9px] text-aurum-gold/80 tracking-[0.42em]">
            {t('plinko.dropping')}…
          </div>
        </div>
      )}
    </>
  );

  return (
    <GameRoom
      world={world}
      overlay={overlay}
      cameraProps={{ position: [0, 3.5, 5], fov: 42 }}
      beamProps={{ position: [0, 5.5, 0], height: 5, radius: 2.5, intensity: 0.85 }}
      fogColor="#06040C"
    />
  );
}

/* ===================================================================== */
/*  Board                                                                */
/* ===================================================================== */

function PlinkoBoard({ layout, risk, activeBall, phase, landedSlot, landedMultiplier }) {
  const multipliers = MULTIPLIERS[risk];

  return (
    <div
      className="absolute z-20 pointer-events-none"
      style={{
        left: '50%', top: '50%',
        transform: 'translate(-50%, -42%)',
        width: 'min(500px, 60vw)',
        aspectRatio: `${BOARD.width} / ${BOARD.height}`,
      }}
    >
      <svg
        viewBox={`0 0 ${BOARD.width} ${BOARD.height}`}
        className="w-full h-full"
        style={{ filter: 'drop-shadow(0 8px 32px rgba(244,215,138,0.12))' }}
      >
        <defs>
          {/* Peg gradient */}
          <radialGradient id="pl-peg" cx="40%" cy="40%" r="60%">
            <stop offset="0%" stopColor="#FFF1C7" />
            <stop offset="60%" stopColor="#C8A24A" />
            <stop offset="100%" stopColor="#7A5C18" />
          </radialGradient>
          {/* Ball gradient */}
          <radialGradient id="pl-ball" cx="35%" cy="35%" r="65%">
            <stop offset="0%" stopColor="#FAF3E0" />
            <stop offset="60%" stopColor="#F4D78A" />
            <stop offset="100%" stopColor="#7A5C18" />
          </radialGradient>
          {/* Background panel */}
          <radialGradient id="pl-bg" cx="50%" cy="40%" r="70%">
            <stop offset="0%" stopColor="rgba(28, 18, 36, 0.7)" />
            <stop offset="100%" stopColor="rgba(8, 4, 14, 0.95)" />
          </radialGradient>
          <filter id="pl-glow">
            <feGaussianBlur stdDeviation="2" result="blur"/>
            <feMerge>
              <feMergeNode in="blur"/>
              <feMergeNode in="SourceGraphic"/>
            </feMerge>
          </filter>
        </defs>

        {/* Background panel */}
        <rect x="0" y="0" width={BOARD.width} height={BOARD.height}
              rx="12" fill="url(#pl-bg)"
              stroke="rgba(244,215,138,0.25)" strokeWidth="1" />

        {/* Pegs */}
        {layout.pegs.map((p, i) => (
          <circle
            key={`peg-${i}`}
            cx={p.x} cy={p.y} r={3.2}
            fill="url(#pl-peg)"
            opacity={0.92}
          />
        ))}

        {/* Slot multiplier labels */}
        {layout.slots.map((s, i) => {
          const m = multipliers[i];
          const isHit = phase === PHASE.LANDED && landedSlot === i;
          const tier  = m >= 8 ? 'extreme' : m >= 2 ? 'high' : m >= 1 ? 'mid' : 'low';
          const color = {
            extreme: '#F4D78A',
            high:    '#EDE3CE',
            mid:     '#C8A24A',
            low:     '#7A5C18',
          }[tier];
          const bg = {
            extreme: 'rgba(244,215,138,0.20)',
            high:    'rgba(244,215,138,0.12)',
            mid:     'rgba(122,92,24,0.30)',
            low:     'rgba(40,20,10,0.50)',
          }[tier];
          return (
            <g key={`slot-${i}`}>
              <motion.rect
                x={s.x - 12} y={s.y - 8}
                width={24} height={22} rx={3}
                fill={bg}
                stroke={isHit ? '#F4D78A' : 'rgba(244,215,138,0.35)'}
                strokeWidth={isHit ? 1.5 : 0.6}
                animate={isHit
                  ? { scale: [1, 1.18, 1.1], strokeOpacity: [1, 1, 1] }
                  : { scale: 1 }}
                transition={{ duration: 0.8, repeat: isHit ? Infinity : 0, ease: 'easeInOut' }}
                style={{ transformOrigin: `${s.x}px ${s.y + 3}px`,
                         filter: isHit ? 'drop-shadow(0 0 6px rgba(244,215,138,0.85))' : 'none' }}
              />
              <text
                x={s.x} y={s.y + 7}
                textAnchor="middle"
                fontFamily="Cormorant Garamond, serif"
                fontSize="10"
                fontWeight={tier === 'extreme' ? 600 : 500}
                fill={color}
                style={{ pointerEvents: 'none' }}
              >
                {m}×
              </text>
            </g>
          );
        })}

        {/* Ball */}
        <AnimatePresence>
          {activeBall && phase !== PHASE.IDLE && (
            <BallAnimation key={activeBall.id} keyframes={activeBall.keyframes} />
          )}
        </AnimatePresence>

        {/* Landed ball — stays at slot */}
        {phase === PHASE.LANDED && activeBall && (
          <circle
            cx={activeBall.keyframes[activeBall.keyframes.length - 1].x}
            cy={activeBall.keyframes[activeBall.keyframes.length - 1].y}
            r={6}
            fill="url(#pl-ball)"
            filter="url(#pl-glow)"
          />
        )}
      </svg>
    </div>
  );
}

/* Ball animation. We keyframe through the (x,y) points returned by
   pathToKeyframes. Each peg hit is one frame; framer-motion interpolates
   smoothly between them. */
function BallAnimation({ keyframes }) {
  const xs = keyframes.map((k) => k.x);
  const ys = keyframes.map((k) => k.y);
  const n = keyframes.length;
  // Distribute easing so the ball accelerates downward (gravity feel)
  const times = keyframes.map((_, i) => i / (n - 1));

  return (
    <motion.circle
      r={6}
      fill="url(#pl-ball)"
      filter="url(#pl-glow)"
      initial={{ cx: xs[0], cy: ys[0], scale: 0.7, opacity: 0 }}
      animate={{
        cx: xs,
        cy: ys,
        scale: 1,
        opacity: 1,
      }}
      transition={{
        cx: { duration: 2.4, times, ease: 'linear' },
        cy: { duration: 2.4, times, ease: [0.45, 0, 0.55, 1] },
        scale: { duration: 0.2 },
        opacity: { duration: 0.2 },
      }}
    />
  );
}

/* ===================================================================== */
/*  HUDs                                                                 */
/* ===================================================================== */

function IdleHUD({ stake, setStake, risk, setRisk, onDrop, error, t }) {
  return (
    <div className="absolute z-40"
         style={{ bottom: '2.5rem', left: '50%', transform: 'translateX(-50%)' }}>
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.7 }}>
        <GlassPanel tint="noir" frame corners animate={false} className="px-8 py-4 rounded-md">
          <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-3">
            {/* Risk selector */}
            <div className="text-center">
              <div className="engraved text-[8px] text-aurum-gold/70 mb-2 tracking-[0.22em]">
                {t('plinko.risk')}
              </div>
              <div className="flex items-center gap-2">
                {[RISK.SAFE, RISK.DARING].map((r) => {
                  const isActive = risk === r;
                  return (
                    <motion.button
                      key={r}
                      whileTap={{ scale: 0.94 }}
                      whileHover={{ y: -1 }}
                      onClick={() => { playClick(); synthClick(); setRisk(r); }}
                      className={`px-4 py-2 rounded-sm text-[10px] tracking-[0.22em] uppercase
                                  transition-colors font-medium
                                  ${isActive ? 'gold-leaf' : 'text-aurum-ivory/55 hover:text-aurum-goldHi'}`}
                      style={{
                        background: isActive
                          ? 'linear-gradient(180deg, rgba(244,215,138,0.20), rgba(0,0,0,0.4))'
                          : 'rgba(15,11,22,0.5)',
                        border: '1px solid rgba(244,215,138,0.18)',
                      }}
                    >
                      {t(`plinko.${r.toLowerCase()}`)}
                    </motion.button>
                  );
                })}
              </div>
            </div>

            <div className="w-px h-12 bg-aurum-gold/20" />

            {/* Stake */}
            <div className="text-center">
              <div className="engraved text-[8px] text-aurum-gold/70 mb-2 tracking-[0.22em]">
                {t('plinko.stake')}
              </div>
              <div className="flex items-center gap-1.5">
                {STAKE_OPTIONS.map((v) => (
                  <motion.button
                    key={v}
                    whileTap={{ scale: 0.94 }}
                    whileHover={{ y: -1 }}
                    onClick={() => { playClick(); synthClick(); setStake(v); }}
                    className={`px-2.5 py-1.5 rounded-sm text-[11px] tracking-[0.14em] font-display transition-colors
                      ${stake === v ? 'gold-leaf' : 'text-aurum-ivory/55 hover:text-aurum-goldHi'}`}
                    style={{
                      background: stake === v
                        ? 'linear-gradient(180deg, rgba(244,215,138,0.18), rgba(0,0,0,0.4))'
                        : 'rgba(15,11,22,0.5)',
                      border: '1px solid rgba(244,215,138,0.18)',
                    }}
                  >${v}</motion.button>
                ))}
              </div>
            </div>

            <div className="w-px h-12 bg-aurum-gold/20" />

            <CinematicButton onClick={onDrop} size="md">
              {t('plinko.drop')} · ${stake}
            </CinematicButton>
          </div>
          {error && (
            <div className="text-center mt-3 text-[10px] tracking-[0.18em] text-red-400/80">
              {error.replace(/_/g, ' ')}
            </div>
          )}
        </GlassPanel>
      </motion.div>
    </div>
  );
}

function ResultPanel({ result, stake, onNext, t }) {
  const isWin = result.net > 0;
  const isLoss = result.net < 0;
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      className="absolute z-40"
      style={{ bottom: '2.5rem', left: '50%', transform: 'translateX(-50%)' }}
    >
      <GlassPanel tint="noir" frame corners animate={false} className="px-8 py-5 rounded-md min-w-[340px]">
        <div className="text-center">
          <div className="engraved text-[8px] text-aurum-gold/70 tracking-[0.32em] mb-2">
            {t('plinko.landed')}
          </div>
          <div className="flex items-center justify-center gap-6 mb-3">
            <div>
              <div className="engraved text-[7px] text-aurum-gold/55 tracking-[0.22em]">
                {t('plinko.multiplier')}
              </div>
              <div className="font-display text-2xl gold-leaf tabular-nums"
                   style={{ filter: result.multiplier >= 8 ? 'drop-shadow(0 0 8px #F4D78A)' : 'none' }}>
                {result.multiplier}×
              </div>
            </div>
            <div className="w-px h-12 bg-aurum-gold/30" />
            <div>
              <div className="engraved text-[7px] text-aurum-gold/55 tracking-[0.22em]">
                {t('plinko.net')}
              </div>
              <div
                className="font-display text-2xl tabular-nums"
                style={{
                  color: isWin ? '#F4D78A' : isLoss ? '#9C9C9C' : '#EDE3CE',
                  filter: isWin && result.multiplier >= 8 ? 'drop-shadow(0 0 8px #F4D78A)' : 'none',
                }}
              >
                {isWin ? '+' : ''}${result.net.toFixed(2)}
              </div>
            </div>
            <div className="w-px h-12 bg-aurum-gold/30" />
            <div>
              <div className="engraved text-[7px] text-aurum-gold/55 tracking-[0.22em]">
                {t('plinko.payout')}
              </div>
              <div className="font-display text-xl text-aurum-ivory/85 tabular-nums">
                ${result.payout}
              </div>
            </div>
          </div>
          <button
            onClick={onNext}
            className="px-6 py-2 rounded-sm text-[10px] tracking-[0.22em] uppercase
                       text-aurum-goldHi hover:text-aurum-gold-pale
                       border border-aurum-goldHi/40 hover:border-aurum-goldHi/70
                       transition-colors"
          >
            {t('plinko.next')}
          </button>
        </div>
      </GlassPanel>
    </motion.div>
  );
}

/* ===================================================================== */
/*  Back link                                                            */
/* ===================================================================== */

function BackToHall({ router, t }) {
  return (
    <motion.button
      initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}
      transition={{ delay: 0.6, duration: 0.7 }}
      onClick={() => { playClick(); router.push('/lounge'); }}
      className="absolute top-24 left-8 engraved text-aurum-ivory/60 hover:text-aurum-goldHi
                 flex items-center gap-3 group z-30"
    >
      <span className="w-8 h-px bg-aurum-gold/40 group-hover:bg-aurum-goldHi transition-colors" />
      {t('game.back')}
    </motion.button>
  );
}

/* ===================================================================== */
/*  3D stage — pedestal w/ subtle base                                   */
/* ===================================================================== */

function PlinkoStage() {
  return (
    <group position={[0, 0, 0]}>
      {/* Round base */}
      <mesh position={[0, 0.05, 0]} receiveShadow>
        <cylinderGeometry args={[2.6, 2.8, 0.1, 64]} />
        <meshStandardMaterial color="#1A0E08" roughness={0.7} />
      </mesh>
      {/* Gold ring */}
      <mesh position={[0, 0.11, 0]} receiveShadow>
        <torusGeometry args={[2.55, 0.05, 16, 64]} />
        <meshStandardMaterial color="#7A5C18" metalness={0.8} roughness={0.3} />
      </mesh>
      {/* Inner felt */}
      <mesh position={[0, 0.08, 0]} receiveShadow>
        <cylinderGeometry args={[2.4, 2.4, 0.04, 64]} />
        <meshStandardMaterial color="#0E1A2A" roughness={0.95} />
      </mesh>
    </group>
  );
}
