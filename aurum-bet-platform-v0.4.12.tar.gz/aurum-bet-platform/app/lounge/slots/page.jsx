'use client';

import { useState, useMemo, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useRouter } from 'next/navigation';

import { GameRoom } from '@/ds/scenes';
import { GlassPanel, CinematicButton, Chip } from '@/ds/components';
import LowBalanceBanner from '@/components/ui/LowBalanceBanner';
import ChipSelector    from '@/components/ui/ChipSelector';
import BetSummary      from '@/components/ui/BetSummary';
import { playClick, playChip, playSpin, playReveal } from '@/lib/audio';
import { useT } from '@/lib/i18n';
import { formatCurrency, D, gte } from '@/services/money';
import { auditRound } from '@/services/audit';
import { paylineLabel } from '@/lib/winningLine';

import { useAccountStore } from '@/store/useAccountStore';
import { useWalletStore }  from '@/store/useWalletStore';
import {
  REELS, SYMBOLS, PAYTABLE, PAYLINES, spin, settle,
} from '@/games/slots/engine';

const SYMBOL_GLYPH = Object.fromEntries(
  Object.entries(SYMBOLS).map(([k, v]) => [k, v.glyph])
);
const SYMBOL_COLOR = {
  AURUM: '#F4D78A',
  SEVEN: '#E0573B',
  STAR:  '#FFF1C7',
  DIAM:  '#9CC8FF',
  SPADE: '#0A0608',
  HEART: '#7A0E14',
  CLUB:  '#0A0608',
  DCARD: '#7A0E14',
};

const CHIP_DENOM = [1, 5, 25, 100, 500];

/* Reel cell geometry — must match the markup below */
const REEL_W = 120;   // per reel width
const REEL_GAP = 12;  // gap between reels
const ROW_H = 100;    // visible row height (300px / 3 rows)
const PAD_X = 6;      // inset inside each reel
const PAD_Y = 6;

const PHASE = { IDLE: 'IDLE', SPINNING: 'SPINNING', RESOLVING: 'RESOLVING', RESULT: 'RESULT' };

export default function SlotsPage() {
  const router    = useRouter();
  const accountId = useAccountStore((s) => s.accountId);
  const wallet    = useWalletStore();
  const t         = useT();

  const [chipValue,    setChipValue]   = useState(25);
  const [lines,        setLines]       = useState(5);
  const [view,         setView]        = useState(REELS.map((r) => r.slice(0, 3)));
  const [reelState,    setReelState]   = useState(['idle', 'idle', 'idle']);
  const [phase,        setPhase]       = useState(PHASE.IDLE);
  const [lastResult,   setLastResult]  = useState(null);
  const [recent,       setRecent]      = useState([]);
  const [displayBal,   setDisplayBal]  = useState(null);
  const [autoplay,     setAutoplay]    = useState(0);
  const [error,        setError]       = useState(null);
  const spinTokenRef                   = useRef(0);

  const liveBalance = useWalletStore((s) => s.available);

  // Animated balance counter
  useEffect(() => {
    if (displayBal === null) { setDisplayBal(parseFloat(liveBalance) || 0); return; }
    const target = parseFloat(liveBalance) || 0;
    if (Math.abs(target - displayBal) < 0.01) return;
    const step = (target - displayBal) / 18;
    const id = setInterval(() => {
      setDisplayBal((cur) => {
        const next = cur + step;
        if ((step > 0 && next >= target) || (step < 0 && next <= target)) {
          clearInterval(id);
          return target;
        }
        return next;
      });
    }, 35);
    return () => clearInterval(id);
  }, [liveBalance]);

  if (!accountId) {
    if (typeof window !== 'undefined') router.replace('/account/login');
    return null;
  }

  const isLocked = phase === PHASE.SPINNING || phase === PHASE.RESOLVING;

  /* --------- Spin orchestration --------- */

  const runSpin = async () => {
    if (phase !== PHASE.IDLE && phase !== PHASE.RESULT) return;
    const token = ++spinTokenRef.current;

    setError(null);
    const balanceBefore = liveBalance;
    const totalStake = chipValue;

    const lock = await wallet.lock(accountId, totalStake, 'slots');
    if (!lock.ok) { setError(lock.reason); return; }
    if (spinTokenRef.current !== token) return;

    setPhase(PHASE.SPINNING);
    playSpin();

    // Deterministic result
    const result = spin({ lines });

    setReelState(['spinning', 'spinning', 'spinning']);

    await wait(1400);
    if (spinTokenRef.current !== token) return;
    setReelState((s) => ['idle', s[1], s[2]]);
    setView((v) => [result.view[0], v[1], v[2]]);

    await wait(700);
    if (spinTokenRef.current !== token) return;
    setReelState((s) => [s[0], 'idle', s[2]]);
    setView((v) => [v[0], result.view[1], v[2]]);

    // anticipation
    const center1 = result.view[0][1];
    const center2 = result.view[1][1];
    const isClose = center1 === center2 && center1 !== 'DCARD' && center1 !== 'CLUB';
    if (isClose) {
      setReelState((s) => [s[0], s[1], 'anticipating']);
      await wait(1600);
    } else {
      await wait(700);
    }
    if (spinTokenRef.current !== token) return;

    setReelState(['idle', 'idle', 'idle']);
    setView(result.view);
    setPhase(PHASE.RESOLVING);

    // Settle
    const { outcome, payout } = settle(totalStake, result);
    await wallet.settle(accountId, {
      roundId: lock.roundId, stake: totalStake, payout, outcome,
      meta: { game: 'slots', view: result.view, wins: result.wins, lines },
    });

    const balanceAfter = useWalletStore.getState().available;
    const net = D(payout).minus(D(totalStake)).toFixed();

    const resultRecord = {
      ts: Date.now(),
      view: result.view,
      wins: result.wins,
      outcome,
      stake: String(totalStake),
      payout,
      net,
      lines,
      balanceBefore,
      balanceAfter,
    };

    auditRound({
      gameId: 'slots',
      roundId: lock.roundId,
      accountId,
      bets: [{ type: 'STAKE', amount: String(totalStake), label: `${lines} lines` }],
      stake: String(totalStake),
      result: result.view,
      payout, outcome, balanceBefore, balanceAfter,
      extra: { wins: result.wins, lines },
    });

    setLastResult(resultRecord);
    setRecent((r) => [{
      view: result.view, total: result.total, payout,
      outcome, ts: Date.now()
    }, ...r].slice(0, 8));

    if (outcome === 'WIN') playReveal();
    setPhase(PHASE.RESULT);

    // Autoplay
    if (autoplay > 0) {
      setAutoplay((n) => n - 1);
      setTimeout(() => {
        if (spinTokenRef.current === token) {
          setPhase(PHASE.IDLE);
          runSpin();
        }
      }, 1800);
    } else {
      // remain in RESULT until user spins again
    }
  };

  const stopAutoplay = () => setAutoplay(0);

  /* --------- 3D world --------- */
  const world = useMemo(() => <Cabinet />, []);

  /* --------- Overlay --------- */
  const overlay = (
    <>
      <BackToHall router={router} label={t('game.back')} />

      <LowBalanceBanner visible={!isLocked && !gte(liveBalance, CHIP_DENOM[0])} />

      <motion.div
        initial={{ opacity: 0, y: -16 }} animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4, duration: 0.9 }}
        className="absolute top-24 left-1/2 -translate-x-1/2 text-center"
      >
        <div className="flex items-center justify-center gap-3 mb-1">
          <span className="hairline-gold w-8" />
          <span className="engraved text-[8px] text-aurum-gold/80">{t('slots.subtitle')}</span>
          <span className="hairline-gold w-8" />
        </div>
        <h2 className="font-display text-3xl md:text-4xl gold-leaf tracking-[0.06em]">
          {t('slots.title')}
        </h2>
      </motion.div>

      {/* Center reel display + winning line overlay */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-20">
        <ReelStack
          view={view}
          reelState={reelState}
          wins={phase === PHASE.RESULT ? (lastResult?.wins || []) : []}
        />
      </div>

      {/* LEFT: Recent history */}
      <GlassPanel
        tint="noir" animate={false}
        className="absolute top-44 left-8 px-4 py-3 rounded-sm w-[136px]"
      >
        <div className="engraved text-[8px] text-aurum-gold/70 mb-2.5 text-center">
          {t('slots.recent')}
        </div>
        {recent.length === 0 ? (
          <div className="text-[9px] text-aurum-smoke italic text-center py-2">—</div>
        ) : (
          <div className="space-y-1.5">
            {recent.map((r) => (
              <div key={r.ts} className="flex items-center justify-between text-[10px]">
                <div className="flex gap-1 leading-none"
                     style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '14px' }}>
                  <span style={{ color: SYMBOL_COLOR[r.view[0][1]] }}>{SYMBOL_GLYPH[r.view[0][1]]}</span>
                  <span style={{ color: SYMBOL_COLOR[r.view[1][1]] }}>{SYMBOL_GLYPH[r.view[1][1]]}</span>
                  <span style={{ color: SYMBOL_COLOR[r.view[2][1]] }}>{SYMBOL_GLYPH[r.view[2][1]]}</span>
                </div>
                <span className={`tabular-nums text-[9px] ${r.outcome === 'WIN' ? 'text-aurum-goldHi' : 'text-aurum-smoke'}`}>
                  {r.outcome === 'WIN' ? '+$' + parseFloat(r.payout).toFixed(0) : '—'}
                </span>
              </div>
            ))}
          </div>
        )}
      </GlassPanel>

      {/* RIGHT: ResultPanel + Paytable */}
      <div className="absolute top-44 right-8 z-30 w-[220px] max-w-[25vw]">
        <SlotsResultPanel result={lastResult} phase={phase} t={t} />
        <GlassPanel
          tint="noir" animate={false}
          className="px-4 py-3 rounded-sm mt-3"
        >
          <div className="engraved text-[8px] text-aurum-gold/70 mb-2 text-center">
            {t('slots.paytable')}
          </div>
          <div className="space-y-1 text-[10px]">
            {Object.entries(PAYTABLE).map(([sym, mult]) => (
              <div key={sym} className="flex items-center justify-between">
                <span style={{
                  color: SYMBOL_COLOR[sym], fontSize: '12px',
                  filter: sym === 'AURUM' ? 'drop-shadow(0 0 4px currentColor)' : 'none',
                }}>
                  {SYMBOL_GLYPH[sym]} {SYMBOL_GLYPH[sym]} {SYMBOL_GLYPH[sym]}
                </span>
                <span className="font-display gold-leaf tabular-nums">×{mult}</span>
              </div>
            ))}
          </div>
          <div className="hairline-gold mt-2 mb-1.5 opacity-50" />
          <div className="text-[7px] text-aurum-smoke text-center tracking-wide">
            {t('slots.wild')}
          </div>
        </GlassPanel>
      </div>

      {/* BOTTOM-LEFT: animated balance */}
      <motion.div
        initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.7 }}
        className="absolute bottom-32 left-8 text-center z-30"
      >
        <div className="engraved text-[8px] text-aurum-gold/70 mb-1 tracking-[0.18em]">
          {t('slots.balance')}
        </div>
        <div className="font-display text-2xl gold-leaf tabular-nums"
             style={{ filter: 'drop-shadow(0 0 4px rgba(244,215,138,0.3))' }}>
          {displayBal !== null ? formatCurrency(displayBal) : '—'}
        </div>
      </motion.div>

      {/* Bottom HUD
          ARCH NOTE — positioning lives on the outer plain <div>; GlassPanel
          does only visual. Entrance animation is on an inner motion.div
          using opacity only (no transform, to avoid colliding with the
          translateX(-50%) of the outer positioning). */}
      <div
        className="absolute z-40"
        style={{
          bottom: '3rem',
          left: '50%',
          transform: 'translateX(-50%)',
        }}
      >
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1], delay: 0.2 }}
        >
          <GlassPanel
            tint="noir" frame corners animate={false}
            className="px-8 py-5 rounded-md"
          >
            <div className="flex flex-wrap items-center justify-center gap-x-8 gap-y-3">
            <ChipSelector
              denominations={CHIP_DENOM}
              value={chipValue}
              onChange={(v) => !isLocked && setChipValue(v)}
              disabled={isLocked}
              labelKey="slots.bet"
            />

            <div className="w-px h-16 bg-aurum-gold/20" />

            <div className="text-center">
              <div className="engraved text-[8px] text-aurum-gold/70 mb-2">{t('slots.lines')}</div>
              <div className="flex items-center gap-2">
                {[1, 3, 5].map((n) => (
                  <motion.button
                    key={n}
                    whileTap={{ scale: 0.9 }}
                    disabled={isLocked}
                    onClick={() => { playClick(); setLines(n); }}
                    className={`
                      w-10 h-10 rounded-full text-[12px] font-display
                      transition-all duration-300 disabled:opacity-40
                      ${lines === n ? 'gold-leaf' : 'text-aurum-ivory/55 hover:text-aurum-goldHi'}
                    `}
                    style={{
                      background: lines === n
                        ? 'linear-gradient(180deg, rgba(244,215,138,0.18), rgba(0,0,0,0.4))'
                        : 'rgba(15,11,22,0.5)',
                      border: '1px solid rgba(244,215,138,0.18)',
                    }}
                  >
                    {n}
                  </motion.button>
                ))}
              </div>
            </div>

            <div className="w-px h-16 bg-aurum-gold/20" />

            <motion.div
              animate={!isLocked ? { scale: [1, 1.02, 1] } : { scale: 1 }}
              transition={!isLocked ? { duration: 2.4, repeat: Infinity, ease: 'easeInOut' } : { duration: 0.3 }}
            >
              <CinematicButton
                onClick={() => { if (phase === PHASE.RESULT) setPhase(PHASE.IDLE); runSpin(); }}
                size="md"
                className={isLocked ? 'opacity-60 pointer-events-none' : ''}
              >
                {phase === PHASE.SPINNING  ? t('slots.spinning')
               : phase === PHASE.RESOLVING ? '…'
               : `${t('slots.spin')} · ${formatCurrency(chipValue)}`}
              </CinematicButton>
            </motion.div>

            <div className="w-px h-16 bg-aurum-gold/20" />

            <div className="text-center">
              <div className="engraved text-[8px] text-aurum-gold/70 mb-2">{t('slots.auto')}</div>
              <div className="flex items-center gap-2">
                {autoplay > 0 ? (
                  <motion.button
                    whileTap={{ scale: 0.9 }}
                    onClick={stopAutoplay}
                    className="px-3 py-2 rounded-sm text-[10px] tracking-[0.18em]
                               text-red-300 border border-red-400/30"
                  >
                    {t('slots.stop')} · {autoplay}
                  </motion.button>
                ) : (
                  [10, 25, 50].map((n) => (
                    <motion.button
                      key={n}
                      whileTap={{ scale: 0.9 }}
                      whileHover={{ y: -1 }}
                      disabled={isLocked}
                      onClick={() => { playClick(); setAutoplay(n); runSpin(); }}
                      className="px-2.5 py-2 rounded-sm text-[10px] font-mono
                                 text-aurum-ivory/55 hover:text-aurum-goldHi
                                 border border-aurum-gold/15 hover:border-aurum-gold/40
                                 transition-colors disabled:opacity-40"
                    >
                      {n}×
                    </motion.button>
                  ))
                )}
              </div>
            </div>
          </div>
        </GlassPanel>
        </motion.div>
      </div>

      {error && (
        <div className="absolute top-44 left-1/2 -translate-x-1/2
                        text-[10px] tracking-[0.18em] text-red-400/80 z-40">
          {error.replace(/_/g, ' ')}
        </div>
      )}

      {/* WIN celebration (transient overlay) */}
      <AnimatePresence>
        {phase === PHASE.RESULT && lastResult?.outcome === 'WIN' && (
          <motion.div
            initial={{ opacity: 0, scale: 0.6, filter: 'blur(20px)' }}
            animate={{ opacity: 1, scale: 1,   filter: 'blur(0px)'  }}
            exit   ={{ opacity: 0, scale: 0.9 }}
            transition={{ duration: 1.0, ease: [0.22, 1, 0.36, 1] }}
            className="absolute top-32 left-1/2 -translate-x-1/2 z-40 pointer-events-none"
          >
            <div className="text-center">
              <div className="engraved text-[10px] text-aurum-goldHi mb-2"
                   style={{ filter: 'drop-shadow(0 0 12px #F4D78A)' }}>
                {lastResult.wins.length === 1 ? t('slots.win') : `${lastResult.wins.length} ${t('slots.wins')}`}
              </div>
              <div
                className="font-display gold-leaf"
                style={{
                  fontSize: 'clamp(48px, 8vw, 96px)',
                  filter: 'drop-shadow(0 0 30px rgba(244,215,138,0.6))',
                }}
              >
                +{formatCurrency(lastResult.payout)}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );

  return (
    <GameRoom
      world={world}
      overlay={overlay}
      cameraProps={{ position: [0, 1.6, 5], fov: 38 }}
      beamProps={{ position: [0, 5, 0], height: 4.5, radius: 1.6, intensity: 1.0 }}
      fogColor="#08060E"
    />
  );
}

/* =====================================================================
   Reel stack with winning-line overlay
   ===================================================================== */

function ReelStack({ view, reelState, wins }) {
  const winCells = useMemo(() => {
    const set = new Set();
    for (const w of wins) {
      const pl = PAYLINES[w.line - 1];
      for (let r = 0; r < 3; r++) set.add(`${r}-${pl[r]}`);
    }
    return set;
  }, [wins]);

  // Stack dimensions: 3 reels × 120px + 2 gaps × 12px + padding
  const stackW = 3 * REEL_W + 2 * REEL_GAP + 12;
  const stackH = 3 * ROW_H + 12;

  return (
    <div
      className="relative grid grid-cols-3 gap-3 p-6 rounded-md gold-frame"
      style={{
        background: 'linear-gradient(180deg, rgba(20,16,28,0.88), rgba(8,6,14,0.96))',
        boxShadow: 'var(--shadow-cinematic), inset 0 1px 0 rgba(255,255,255,0.04)',
      }}
    >
      {[0, 1, 2].map((reelIdx) => {
        const state = reelState[reelIdx];
        const spinning = state === 'spinning';
        const anticipating = state === 'anticipating';
        return (
          <div
            key={reelIdx}
            className="relative w-[120px] h-[300px] overflow-hidden rounded-sm"
            style={{
              background: 'linear-gradient(180deg, #FAF3E0, #E8DCB8)',
              boxShadow: 'inset 0 2px 8px rgba(0,0,0,0.4), inset 0 -2px 8px rgba(0,0,0,0.4)',
            }}
          >
            <div className="absolute inset-1 border border-aurum-gold/40 rounded-sm pointer-events-none z-10" />

            {anticipating && (
              <motion.div
                className="absolute inset-0 rounded-sm pointer-events-none z-20"
                animate={{
                  boxShadow: [
                    '0 0 0px 0px rgba(244,215,138,0)',
                    '0 0 24px 4px rgba(244,215,138,0.8)',
                    '0 0 0px 0px rgba(244,215,138,0)',
                  ],
                }}
                transition={{ duration: 0.8, repeat: Infinity, ease: 'easeInOut' }}
              />
            )}

            <motion.div
              className="absolute inset-0 flex flex-col"
              animate={{
                y: spinning ? [-30, -300, 0]
                  : anticipating ? [-3, 3, -3]
                  : 0,
                filter: spinning ? 'blur(8px)'
                      : anticipating ? 'blur(1.5px)'
                      : 'blur(0px)',
              }}
              transition={spinning
                ? { duration: 1.2, ease: 'linear', repeat: Infinity }
                : anticipating
                ? { duration: 0.18, repeat: Infinity }
                : { duration: 0.4, ease: [0.22, 1, 0.36, 1] }
              }
            >
              {[0, 1, 2].map((rowIdx) => {
                const sym = view[reelIdx]?.[rowIdx] || 'DCARD';
                const isWin = winCells.has(`${reelIdx}-${rowIdx}`);
                return (
                  <motion.div
                    key={`${reelIdx}-${rowIdx}-${sym}`}
                    animate={isWin ? {
                      scale: [1, 1.15, 1],
                      filter: ['drop-shadow(0 0 0 rgba(244,215,138,0))',
                               'drop-shadow(0 0 24px rgba(244,215,138,0.9))',
                               'drop-shadow(0 0 0 rgba(244,215,138,0))'],
                    } : {}}
                    transition={isWin ? { duration: 1.0, repeat: Infinity, ease: 'easeInOut' } : {}}
                    className="flex-1 flex items-center justify-center"
                    style={{
                      color: SYMBOL_COLOR[sym],
                      fontSize: '64px',
                      fontFamily: 'Cormorant Garamond, serif',
                      fontStyle: sym === 'SEVEN' ? 'italic' : 'normal',
                      fontWeight: 600,
                      textShadow: sym === 'AURUM'
                        ? '0 0 16px rgba(244,215,138,0.6), 0 2px 0 rgba(0,0,0,0.3)'
                        : '0 1px 0 rgba(0,0,0,0.15)',
                      background: isWin
                        ? 'radial-gradient(ellipse at center, rgba(244,215,138,0.18), transparent 70%)'
                        : 'transparent',
                    }}
                  >
                    {SYMBOL_GLYPH[sym]}
                  </motion.div>
                );
              })}
            </motion.div>

            <div className="absolute inset-x-0 top-1/3 h-px bg-aurum-gold/15 z-20" />
            <div className="absolute inset-x-0 top-2/3 h-px bg-aurum-gold/15 z-20" />
          </div>
        );
      })}

      {/* Winning-line overlay — drawn ABOVE the reels, semi-transparent */}
      {wins.length > 0 && (
        <svg
          className="absolute inset-6 pointer-events-none z-30"
          width={stackW} height={stackH}
          viewBox={`0 0 ${stackW} ${stackH}`}
          style={{ overflow: 'visible' }}
        >
          {wins.map((w, idx) => {
            const pl = PAYLINES[w.line - 1];
            const pts = pl.map((row, col) => ({
              x: col * (REEL_W + REEL_GAP) + REEL_W / 2,
              y: row * ROW_H + ROW_H / 2,
            }));
            const polyline = pts.map((p) => `${p.x},${p.y}`).join(' ');
            return (
              <g key={`line-${w.line}`}>
                {/* Glow underlay */}
                <motion.polyline
                  points={polyline}
                  fill="none"
                  stroke="#F4D78A"
                  strokeWidth="14"
                  strokeOpacity="0.18"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  initial={{ pathLength: 0 }}
                  animate={{ pathLength: 1 }}
                  transition={{ duration: 0.7, delay: idx * 0.18 }}
                />
                {/* Crisp line */}
                <motion.polyline
                  points={polyline}
                  fill="none"
                  stroke="#F4D78A"
                  strokeWidth="3"
                  strokeOpacity="0.95"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  initial={{ pathLength: 0 }}
                  animate={{ pathLength: 1 }}
                  transition={{ duration: 0.7, delay: idx * 0.18 }}
                  style={{ filter: 'drop-shadow(0 0 6px #F4D78A)' }}
                />
                {/* Symbol-center halos */}
                {pts.map((p, i) => (
                  <motion.circle
                    key={i}
                    cx={p.x} cy={p.y} r="32"
                    fill="none"
                    stroke="#F4D78A"
                    strokeWidth="1.5"
                    strokeOpacity="0.5"
                    initial={{ scale: 0.6, opacity: 0 }}
                    animate={{ scale: 1, opacity: [0, 0.7, 0] }}
                    transition={{
                      duration: 1.4,
                      delay: idx * 0.18 + i * 0.06,
                      repeat: Infinity,
                    }}
                  />
                ))}
                {/* Line label at the rightmost point */}
                <motion.text
                  x={pts[pts.length - 1].x + 24}
                  y={pts[pts.length - 1].y + 4}
                  fontFamily="Inter Tight, sans-serif"
                  fontSize="9"
                  fontWeight="500"
                  letterSpacing="2"
                  fill="#F4D78A"
                  initial={{ opacity: 0, x: pts[pts.length - 1].x }}
                  animate={{ opacity: 1, x: pts[pts.length - 1].x + 24 }}
                  transition={{ delay: idx * 0.18 + 0.6, duration: 0.4 }}
                  style={{ filter: 'drop-shadow(0 0 4px #F4D78A)' }}
                >
                  ×{w.multiplier}
                </motion.text>
              </g>
            );
          })}
        </svg>
      )}
    </div>
  );
}

/* =====================================================================
   SlotsResultPanel — top-right, persistent
   ===================================================================== */

function SlotsResultPanel({ result, phase, t }) {
  if (!result) {
    return (
      <GlassPanel tint="noir" className="p-4 rounded-sm text-center" animate={false}>
        <div className="engraved text-[7px] text-aurum-gold/55 tracking-[0.32em] mb-1">
          {phase}
        </div>
        <div className="text-[10px] text-aurum-smoke italic">
          {t('game.noLastResult')}
        </div>
      </GlassPanel>
    );
  }

  const isWin = result.outcome === 'WIN';

  return (
    <GlassPanel tint="noir" frame className="p-4 rounded-sm" animate={false}>
      <div className="engraved text-[7px] text-aurum-gold/60 tracking-[0.32em] mb-2">
        {phase}
      </div>

      {/* Headline */}
      <div className="text-center mb-3">
        <div className="engraved text-[7px] text-aurum-gold/60 tracking-[0.32em] mb-1">
          {isWin ? t('game.win') : t('game.loss')}
        </div>
        <div
          className="font-display text-2xl tabular-nums leading-none"
          style={{
            color: isWin ? '#F4D78A' : '#9C9C9C',
            filter: isWin ? 'drop-shadow(0 0 8px #F4D78A)' : 'none',
          }}
        >
          {isWin ? '+' : ''}${parseFloat(result.net).toFixed(2)}
        </div>
      </div>

      {/* Winning lines list */}
      {isWin && result.wins.length > 0 && (
        <>
          <div className="hairline-gold opacity-50 mb-2" />
          <div className="engraved text-[7px] text-aurum-gold/60 tracking-[0.32em] mb-1">
            {t('game.winningLine')}
          </div>
          <div className="space-y-1 mb-3">
            {result.wins.map((w) => (
              <div key={w.line} className="flex items-center justify-between text-[10px]">
                <span className="text-aurum-ivory/75">
                  <span style={{ color: SYMBOL_COLOR[w.symbol] }}>{SYMBOL_GLYPH[w.symbol]}</span>
                  {' '}{paylineLabel(w.line)}
                </span>
                <span className="font-display text-aurum-goldHi tabular-nums">×{w.multiplier}</span>
              </div>
            ))}
          </div>
        </>
      )}

      <div className="hairline-gold opacity-50 mb-2" />
      <div className="space-y-1 text-[10px]">
        <Row label={t('slots.bet')}            value={`$${parseFloat(result.stake).toFixed(2)}`} />
        <Row label={t('game.balanceBefore')}   value={`$${parseFloat(result.balanceBefore).toFixed(2)}`} />
        <Row label={t('game.balanceAfter')}    value={`$${parseFloat(result.balanceAfter).toFixed(2)}`} />
      </div>
    </GlassPanel>
  );
}

function Row({ label, value }) {
  return (
    <div className="flex items-center justify-between">
      <span className="engraved text-[7px] text-aurum-gold/55 tracking-[0.22em]">{label}</span>
      <span className="font-display text-aurum-ivory/85 tabular-nums">{value}</span>
    </div>
  );
}

function wait(ms) { return new Promise((r) => setTimeout(r, ms)); }

/* ---------- 3D cabinet ---------- */
function Cabinet() {
  return (
    <group position={[0, 0, -1]}>
      <mesh position={[0, 1.5, 0]} castShadow receiveShadow>
        <boxGeometry args={[3.4, 3.6, 1.5]} />
        <meshStandardMaterial color="#2A0E08" roughness={0.55} metalness={0.15} />
      </mesh>
      <mesh position={[0, 2.6, 0.76]}>
        <boxGeometry args={[2.8, 0.5, 0.04]} />
        <meshStandardMaterial color="#C8A24A" metalness={1} roughness={0.2} />
      </mesh>
      <mesh position={[0, 3.1, 0.77]}>
        <boxGeometry args={[1.8, 0.18, 0.02]} />
        <meshStandardMaterial color="#0A0608" metalness={0.3} roughness={0.5} />
      </mesh>
      <mesh position={[0, 1.7, 0.74]}>
        <boxGeometry args={[2.6, 1.7, 0.04]} />
        <meshStandardMaterial color="#0A0608" />
      </mesh>
      <mesh position={[1.85, 1.5, 0]} rotation={[0, 0, -0.3]} castShadow>
        <cylinderGeometry args={[0.05, 0.05, 1.0, 12]} />
        <meshStandardMaterial color="#C8A24A" metalness={1} roughness={0.18} />
      </mesh>
      <mesh position={[2.0, 2.0, 0]} castShadow>
        <sphereGeometry args={[0.12, 24, 24]} />
        <meshStandardMaterial color="#7A0E14" metalness={0.4} roughness={0.35} />
      </mesh>
      <mesh position={[0, 0.05, 0]} receiveShadow>
        <boxGeometry args={[3.6, 0.1, 1.7]} />
        <meshStandardMaterial color="#1A0604" roughness={0.55} metalness={0.2} />
      </mesh>
      <mesh position={[0, 0.18, 0.7]} castShadow>
        <boxGeometry args={[2.0, 0.06, 0.2]} />
        <meshStandardMaterial color="#C8A24A" metalness={1} roughness={0.2} />
      </mesh>
    </group>
  );
}

function BackToHall({ router, label }) {
  return (
    <motion.button
      initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}
      transition={{ delay: 0.6, duration: 0.7 }}
      onClick={() => { playClick(); router.push('/lounge'); }}
      className="absolute top-24 left-8 engraved text-aurum-ivory/60 hover:text-aurum-goldHi
                 flex items-center gap-3 group z-30"
    >
      <span className="w-8 h-px bg-aurum-gold/40 group-hover:bg-aurum-goldHi transition-colors" />
      {label}
    </motion.button>
  );
}
