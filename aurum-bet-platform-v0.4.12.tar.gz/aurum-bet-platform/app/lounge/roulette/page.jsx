'use client';

import { useState, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useRouter } from 'next/navigation';
import { OrbitControls } from '@react-three/drei';

import { GameRoom } from '@/ds/scenes';
import { GlassPanel, CinematicButton, Chip } from '@/ds/components';
import LowBalanceBanner from '@/components/ui/LowBalanceBanner';
import ChipSelector    from '@/components/ui/ChipSelector';
import BetSummary      from '@/components/ui/BetSummary';
import RouletteTable   from '@/components/three/RouletteTable';
import RouletteWheel   from '@/components/three/RouletteWheel';
import BettingFelt     from '@/games/roulette/BettingFelt';

import { playClick, playChip, playSpin, playReveal } from '@/lib/audio';
import { useAccountStore } from '@/store/useAccountStore';
import { useWalletStore }  from '@/store/useWalletStore';
import { useT } from '@/lib/i18n';
import { formatCurrency, D, add, gte } from '@/services/money';
import { auditRound } from '@/services/audit';
import { spin, settleAll, colorOf, isRed, BET_LABEL } from '@/games/roulette/engine';

const CHIP_DENOMS = [1, 5, 25, 100, 500];

/**
 * Phase machine for the round lifecycle. Every transition must go
 * through `setPhase()` so the locks (no double-submit, no chip changes
 * mid-spin, etc.) are enforced in one place.
 *
 *   IDLE      — fresh table, can place bets
 *   BETTING   — chips placed; SPIN button enabled (still IDLE shaped)
 *   SPINNING  — wheel turning, no input accepted
 *   RESOLVING — wheel stopped, settle running (very brief)
 *   RESULT    — result on screen, balance settled, player can review
 *               or click to start a new round
 */
const PHASE = { IDLE: 'IDLE', SPINNING: 'SPINNING', RESOLVING: 'RESOLVING', RESULT: 'RESULT' };

export default function RoulettePage() {
  const router    = useRouter();
  const accountId = useAccountStore((s) => s.accountId);
  const wallet    = useWalletStore();
  const liveBalance = useWalletStore((s) => s.available);
  const t         = useT();

  // ----- State -----
  const [bets,         setBets]        = useState({});
  const [lastBets,     setLastBets]    = useState({});
  const [chipValue,    setChipValue]   = useState(25);
  const [phase,        setPhase]       = useState(PHASE.IDLE);
  const [lastResult,   setLastResult]  = useState(null);  // persistent until next spin
  const [history,      setHistory]     = useState([]);    // last 10 results (number array)
  const [error,        setError]       = useState(null);
  const spinTokenRef                   = useRef(0);       // guard against double-submit

  if (!accountId) {
    if (typeof window !== 'undefined') router.replace('/account/login');
    return null;
  }

  // ----- Derived -----
  const totalStake = useMemo(
    () => Object.values(bets).reduce((acc, b) => add(acc, D(b.amount)), D(0)),
    [bets]
  );
  const totalStakeStr = totalStake.toFixed();
  const hasBets       = totalStake.gt(0);
  const isLocked      = phase === PHASE.SPINNING || phase === PHASE.RESOLVING;

  /* Potential return — sum of max payouts for each placed bet.
     (A "max" because some bets cover overlapping numbers; this is the
     theoretical ceiling, useful as a "if every bet hits" indicator.) */
  const potentialReturn = useMemo(() => {
    let max = D(0);
    for (const b of Object.values(bets)) {
      const mult = {
        STRAIGHT: 36, SPLIT: 18, STREET: 12, CORNER: 9, SIXLINE: 6,
        DOZEN: 3, COLUMN: 3,
        RED: 2, BLACK: 2, EVEN: 2, ODD: 2, LOW: 2, HIGH: 2,
      }[b.type] || 1;
      max = max.plus(D(b.amount).times(mult));
    }
    return max.toFixed();
  }, [bets]);

  // ----- Handlers -----
  const placeChip = (zone) => {
    if (isLocked) return;
    setError(null);
    playChip();
    setBets((prev) => {
      const cur = prev[zone.id];
      const newAmt = add(D(cur?.amount || 0), D(chipValue)).toFixed();
      return {
        ...prev,
        [zone.id]: {
          id: zone.id,
          type: zone.type,
          numbers: zone.numbers,
          amount: newAmt,
          chipCount: (cur?.chipCount || 0) + 1,
          label: zone.label,
        },
      };
    });
  };

  const clearBets = () => {
    if (isLocked) return;
    playClick();
    setBets({});
    setError(null);
  };
  const repeatBets = () => {
    if (isLocked) return;
    playClick();
    if (Object.keys(lastBets).length) setBets(lastBets);
  };

  const handleSpin = async () => {
    // SINGLE entry point with double-submit guard
    if (!hasBets) return;
    if (phase !== PHASE.IDLE && phase !== PHASE.RESULT) return;
    const token = ++spinTokenRef.current;

    setError(null);

    // Snapshot balance BEFORE moving any money
    const balanceBefore = liveBalance;

    // Combined lock for total
    const lock = await wallet.lock(accountId, totalStakeStr, 'roulette');
    if (!lock.ok) { setError(lock.reason); return; }
    if (spinTokenRef.current !== token) return;  // stale, abandon

    setPhase(PHASE.SPINNING);
    playSpin();

    // Determine result deterministically
    const r = spin();

    // Animate for suspense
    await new Promise((res) => setTimeout(res, 4000));
    if (spinTokenRef.current !== token) return;  // ignored: user navigated away

    setPhase(PHASE.RESOLVING);
    const settled = settleAll(Object.values(bets), r);

    await wallet.settle(accountId, {
      roundId: lock.roundId,
      stake:   totalStakeStr,
      payout:  settled.totalPayout,
      outcome: settled.outcome,
      meta:    { game: 'roulette', result: r, bets: Object.values(bets) },
    });

    const balanceAfter = useWalletStore.getState().available;

    // Build the persistent result record. Everything the player needs
    // to understand what happened, all in one object.
    const resultRecord = {
      ts: Date.now(),
      number: r,
      color: colorOf(r),
      parity: r === 0 ? 'ZERO' : (r % 2 === 0 ? 'EVEN' : 'ODD'),
      range:  r === 0 ? null : (r <= 18 ? 'LOW' : 'HIGH'),
      stake:  totalStakeStr,
      payout: settled.totalPayout,
      net:    settled.net,
      outcome: settled.outcome,
      winners: settled.winners,
      losers:  settled.losers,
      balanceBefore,
      balanceAfter,
    };

    // Audit
    auditRound({
      gameId: 'roulette',
      roundId: lock.roundId,
      accountId,
      bets: Object.values(bets),
      stake: totalStakeStr,
      result: r,
      payout: settled.totalPayout,
      outcome: settled.outcome,
      balanceBefore,
      balanceAfter,
      extra: { color: resultRecord.color, parity: resultRecord.parity, range: resultRecord.range },
    });

    if (settled.outcome === 'WIN') playReveal();

    setLastResult(resultRecord);
    setHistory((h) => [r, ...h].slice(0, 10));
    setLastBets(bets);
    setPhase(PHASE.RESULT);
  };

  const startNewRound = () => {
    if (isLocked) return;
    playClick();
    setBets({});
    setPhase(PHASE.IDLE);
    // We deliberately KEEP lastResult visible so the player can still
    // see "what just happened" even after starting to place new chips.
  };

  // ----- 3D world -----
  const isSpinning = phase === PHASE.SPINNING;
  const world = useMemo(() => (
    <>
      <RouletteTable position={[0, 0, 0]} />
      <RouletteWheel position={[0, 0.18, -0.4]} scale={0.95} isSpinning={isSpinning} />
      <OrbitControls
        enablePan={false} enableZoom={false}
        minPolarAngle={Math.PI / 4} maxPolarAngle={Math.PI / 2.4}
        autoRotate={!isSpinning} autoRotateSpeed={0.25}
        target={[0, 0.4, 0]}
      />
    </>
  ), [isSpinning]);

  // ----- Overlay -----
  const overlay = (
    <>
      {/* Back */}
      <motion.button
        initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 0.6, duration: 0.7 }}
        onClick={() => { playClick(); router.push('/lounge'); }}
        className="absolute top-24 left-8 engraved text-aurum-ivory/60 hover:text-aurum-goldHi
                   flex items-center gap-3 group z-30"
      >
        <span className="w-8 h-px bg-aurum-gold/40 group-hover:bg-aurum-goldHi transition-colors" />
        {t('game.back')}
      </motion.button>

      <LowBalanceBanner visible={!isLocked && !gte(liveBalance, CHIP_DENOMS[0])} />

      {/* Title */}
      <motion.div
        initial={{ opacity: 0, y: -16 }} animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4, duration: 0.9 }}
        className="absolute top-24 left-1/2 -translate-x-1/2 text-center"
      >
        <div className="flex items-center justify-center gap-3 mb-1">
          <span className="hairline-gold w-8" />
          <span className="engraved text-[8px] text-aurum-gold/80">
            {t('roulette.subtitle')}
          </span>
          <span className="hairline-gold w-8" />
        </div>
        <h2 className="font-display text-3xl md:text-4xl gold-leaf tracking-[0.06em]">
          {t('roulette.title')}
        </h2>
      </motion.div>

      {/* RESULT PANEL — top-right, always there once we have a result */}
      <ResultPanel
        result={lastResult}
        phase={phase}
        t={t}
        onNewRound={startNewRound}
      />

      {/* History dots — top-left */}
      <HistoryStrip history={history} />

      {/* Betting felt
          Sits at bottom-52 (208px from viewport bottom) to clear the
          ~150px-tall bottom HUD anchored at bottom-6 (24px). That gives
          ~32px of breathing room so the outside bets row (1-18, EVEN,
          RED, BLACK, ODD, 19-36) and dozens row stay fully visible. */}
      <div className="absolute bottom-52 left-1/2 -translate-x-1/2 w-full max-w-[820px] px-4 z-20">
        <BettingFelt
          bets={bets}
          chipValue={chipValue}
          onPlace={placeChip}
          highlight={lastResult?.number}
          disabled={isLocked}
        />
      </div>

      {/* Bottom HUD
          See slots/page.jsx for the architectural note — positioning on
          outer plain <div>, GlassPanel renders only visual, entrance
          animation on inner motion.div using opacity only. */}
      <div
        className="absolute z-30"
        style={{
          bottom: '1.5rem',
          left: '50%',
          transform: 'translateX(-50%)',
        }}
      >
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1], delay: 0.3 }}
        >
          <GlassPanel
            tint="noir" frame corners animate={false}
            className="px-6 py-3 rounded-md"
          >
            <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-3">
            <ChipSelector
              denominations={CHIP_DENOMS}
              value={chipValue}
              onChange={(v) => !isLocked && setChipValue(v)}
              disabled={isLocked}
              size={38}
              label="CHIPS"
            />

            <div className="w-px h-12 bg-aurum-gold/20" />

            <BetSummary
              stake={totalStakeStr}
              chipValue={chipValue}
              potentialReturn={hasBets ? potentialReturn : null}
              compact
              className="min-w-[150px]"
            />

            <div className="w-px h-12 bg-aurum-gold/20" />

            <CinematicButton
              onClick={handleSpin}
              size="md"
              className={(!hasBets || isLocked) ? 'opacity-50 pointer-events-none' : ''}
            >
              {phase === PHASE.SPINNING  ? t('game.spinning')
              : phase === PHASE.RESOLVING ? '…'
              : t('game.spin')}
            </CinematicButton>

            <div className="w-px h-12 bg-aurum-gold/20" />

            <div className="flex flex-col gap-1.5">
              <button
                onClick={clearBets}
                disabled={isLocked || !hasBets}
                className="px-3 py-1 rounded-sm text-[9px] tracking-[0.15em] uppercase
                           text-aurum-ivory/60 hover:text-aurum-goldHi
                           border border-aurum-ivory/15 hover:border-aurum-goldHi/40
                           transition-colors disabled:opacity-30"
              >
                {t('game.clearBets')}
              </button>
              <button
                onClick={repeatBets}
                disabled={isLocked || !Object.keys(lastBets).length}
                className="px-3 py-1 rounded-sm text-[9px] tracking-[0.15em] uppercase
                           text-aurum-ivory/60 hover:text-aurum-goldHi
                           border border-aurum-ivory/15 hover:border-aurum-goldHi/40
                           transition-colors disabled:opacity-30"
              >
                {t('game.repeatBet')}
              </button>
            </div>
          </div>
        </GlassPanel>
        </motion.div>
      </div>

      {error && (
        <div className="absolute bottom-32 right-8
                        text-[10px] tracking-[0.18em] text-red-400/85 z-40">
          {error.replace(/_/g, ' ')}
        </div>
      )}
    </>
  );

  return (
    <GameRoom
      world={world}
      overlay={overlay}
      cameraProps={{ position: [0, 4.5, 5.5], fov: 38 }}
      beamProps={{ position: [0, 6, 0], height: 5.5, radius: 2.2, intensity: 0.85 }}
      fogColor="#08060E"
    />
  );
}

/* =====================================================================
   ResultPanel — persistent, top-right
   ===================================================================== */

function ResultPanel({ result, phase, t, onNewRound }) {
  return (
    <div className="absolute top-44 right-8 z-50 w-[280px] max-w-[30vw]">
      {/* Phase indicator */}
      <div className="flex items-center justify-end gap-2 mb-2">
        <PhaseLight phase={phase} />
        <span className="engraved text-[7px] text-aurum-gold/60 tracking-[0.32em]">
          {phase}
        </span>
      </div>

      {!result ? (
        <GlassPanel tint="noir" className="px-4 py-5 rounded-sm text-center" animate={false}>
          <div className="engraved text-[8px] text-aurum-gold/60 tracking-[0.32em]">
            {t('game.noLastResult')}
          </div>
        </GlassPanel>
      ) : (
        <AnimatePresence mode="wait">
          <motion.div
            key={result.ts}
            initial={{ opacity: 0, y: -10, scale: 0.96 }}
            animate={{ opacity: 1, y: 0,   scale: 1    }}
            transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
          >
            <GlassPanel tint="noir" frame className="p-4 rounded-sm" animate={false}>
              {/* Headline: huge winning number */}
              <div className="flex items-center gap-3 mb-3">
                <div
                  className="w-14 h-14 rounded-full flex items-center justify-center
                             font-display text-3xl font-semibold flex-shrink-0"
                  style={{
                    background: result.number === 0 ? '#1F4D3A'
                              : isRed(result.number) ? '#7A0E14' : '#0A0608',
                    color: '#F4D78A',
                    border: '2px solid #F4D78A',
                    boxShadow: '0 0 16px rgba(244,215,138,0.55), inset 0 1px 0 rgba(255,255,255,0.15)',
                  }}
                >
                  {result.number}
                </div>
                <div className="flex-1">
                  <div className="engraved text-[7px] text-aurum-gold/60 tracking-[0.32em] mb-0.5">
                    {t('game.winningNumber')}
                  </div>
                  <div className="text-[11px] text-aurum-ivory/85 leading-tight">
                    {result.color} · {result.parity}{result.range ? ` · ${result.range === 'LOW' ? '1–18' : '19–36'}` : ''}
                  </div>
                </div>
              </div>

              <div className="hairline-gold opacity-50 mb-3" />

              {/* Numerical breakdown */}
              <div className="space-y-1 text-[11px]">
                <Row label={t('slots.bet')}            value={`$${parseFloat(result.stake).toFixed(2)}`} />
                <Row label={t('hud.wealth') + ' ' + t('game.balanceBefore')}
                     value={`$${parseFloat(result.balanceBefore).toFixed(2)}`} />
                <Row label={t('hud.wealth') + ' ' + t('game.balanceAfter')}
                     value={`$${parseFloat(result.balanceAfter).toFixed(2)}`} />
              </div>

              <div className="hairline-gold opacity-50 my-3" />

              {/* Outcome */}
              <div className="text-center">
                <div className="engraved text-[7px] text-aurum-gold/60 tracking-[0.32em] mb-1">
                  {result.outcome === 'WIN'  ? t('game.win')
                 : result.outcome === 'LOSS' ? t('game.loss')
                 : t('game.push')}
                </div>
                <div
                  className="font-display text-2xl tabular-nums leading-none"
                  style={{
                    color: result.outcome === 'WIN'  ? '#F4D78A'
                         : result.outcome === 'LOSS' ? '#7A0E14'
                         : '#EDE3CE',
                    filter: result.outcome === 'WIN' ? 'drop-shadow(0 0 10px #F4D78A)' : 'none',
                  }}
                >
                  {result.outcome === 'WIN' ? '+' : ''}
                  ${parseFloat(result.net).toFixed(2)}
                </div>
                <div className="text-[8px] text-aurum-smoke mt-1">
                  {result.winners.length}/{result.winners.length + result.losers.length} bets won
                </div>
              </div>

              {phase === PHASE.RESULT && (
                <button
                  onClick={onNewRound}
                  className="mt-3 w-full px-3 py-2 rounded-sm text-[9px] tracking-[0.22em] uppercase
                             text-aurum-goldHi hover:text-aurum-gold-pale
                             border border-aurum-goldHi/40 hover:border-aurum-goldHi/70
                             transition-colors"
                >
                  {t('blackjack.newHand')}
                </button>
              )}
            </GlassPanel>
          </motion.div>
        </AnimatePresence>
      )}
    </div>
  );
}

function Row({ label, value }) {
  return (
    <div className="flex items-center justify-between">
      <span className="engraved text-[7px] text-aurum-gold/55 tracking-[0.22em]">{label}</span>
      <span className="font-display text-aurum-ivory/85 tabular-nums">{value}</span>
    </div>
  );
}

function PhaseLight({ phase }) {
  const colorMap = {
    IDLE:      '#9C9C9C',
    SPINNING:  '#F4D78A',
    RESOLVING: '#F4D78A',
    RESULT:    '#22C55E',
  };
  const pulse = phase === 'SPINNING' || phase === 'RESOLVING';
  const c = colorMap[phase] || '#9C9C9C';
  return (
    <motion.span
      animate={pulse ? { opacity: [0.4, 1, 0.4] } : { opacity: 1 }}
      transition={pulse ? { duration: 1.0, repeat: Infinity } : { duration: 0.3 }}
      className="w-1.5 h-1.5 rounded-full inline-block"
      style={{ background: c, boxShadow: `0 0 6px ${c}` }}
    />
  );
}

/* =====================================================================
   HistoryStrip — top-left, latest 10 spins as colored pills
   ===================================================================== */

function HistoryStrip({ history }) {
  if (!history.length) return null;
  return (
    <div className="absolute top-44 left-8 z-30 flex flex-col items-start gap-2">
      <span className="engraved text-[8px] text-aurum-gold/70 tracking-[0.32em] mb-0.5">
        HISTORY
      </span>
      <div className="flex items-center gap-1.5 flex-wrap max-w-[200px]">
        {history.map((n, i) => (
          <motion.span
            key={`${i}-${n}-${Date.now()}`}
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1 - i * 0.05, scale: 1 }}
            transition={{ duration: 0.3 }}
            className="flex items-center justify-center font-display font-semibold tabular-nums"
            style={{
              width: 32, height: 32, fontSize: 14,
              borderRadius: '50%',
              background: n === 0 ? '#1F4D3A' : isRed(n) ? '#7A0E14' : '#0A0608',
              color: '#F4D78A',
              border: i === 0 ? '1.5px solid #F4D78A' : '1px solid rgba(244,215,138,0.55)',
              boxShadow: i === 0 ? '0 0 8px rgba(244,215,138,0.5)' : 'none',
            }}
          >
            {n}
          </motion.span>
        ))}
      </div>
    </div>
  );
}
