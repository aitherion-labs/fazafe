'use client';

import { useState, useMemo, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useRouter } from 'next/navigation';

import { GameRoom } from '@/ds/scenes';
import { GlassPanel, CinematicButton, Chip } from '@/ds/components';
import { playClick, playChip, playReveal } from '@/lib/audio';

import BlackjackTable from '@/games/blackjack/BlackjackTable';
import Card3D         from '@/games/blackjack/Card3D';
import {
  freshDeck, shuffle, value, isBlackjack, isBust,
  dealerPlay, settle,
} from '@/games/blackjack/engine';

import { useAccountStore } from '@/store/useAccountStore';
import { useWalletStore }  from '@/store/useWalletStore';
import { useT } from '@/lib/i18n';
import { formatCurrency, gte } from '@/services/money';
import { auditRound } from '@/services/audit';
import LowBalanceBanner from '@/components/ui/LowBalanceBanner';

const CHIP_DENOM = [10, 50, 100, 500];

/**
 * Blackjack flow state machine:
 *   IDLE          → waiting for stake
 *   DEALING       → first 4 cards animate
 *   PLAYER_TURN   → Hit / Stand / Double available
 *   DEALER_TURN   → dealer reveals + draws
 *   RESOLVED      → outcome shown
 */

export default function BlackjackPage() {
  const router    = useRouter();
  const accountId = useAccountStore((s) => s.accountId);
  const wallet    = useWalletStore();
  const liveBalance = useWalletStore((s) => s.available);
  const t         = useT();

  const [phase, setPhase]         = useState('IDLE');
  const [chipValue, setChipValue] = useState(50);
  const [stake, setStake]         = useState(null);
  const [round, setRound]         = useState(null);
  const [deck, setDeck]           = useState([]);
  const [player, setPlayer]       = useState([]);
  const [dealer, setDealer]       = useState([]);
  const [hideHole, setHideHole]   = useState(true);
  const [outcome, setOutcome]     = useState(null);
  const [error, setError]         = useState(null);

  if (!accountId) {
    if (typeof window !== 'undefined') router.replace('/account/login');
    return null;
  }

  const playerVal = value(player);
  const dealerVal = value(hideHole ? dealer.slice(0, 1) : dealer);

  /* ---------- Deal ---------- */

  const startRoundLockRef = useRef(false);

  const startRound = async () => {
    if (startRoundLockRef.current) return;
    if (phase !== 'IDLE') return;
    startRoundLockRef.current = true;
    try {
      setError(null);
      const balBefore = useWalletStore.getState().available;
      const r = await wallet.lock(accountId, chipValue, 'blackjack');
      if (!r.ok) { setError(r.reason); return; }
      setStake(chipValue); setRound({ ...r, balanceBefore: balBefore });
      playChip();

      const d = shuffle(freshDeck(6));
      const p = [d.shift(), d.shift()];
      const dl = [d.shift(), d.shift()];
      setDeck(d); setPlayer(p); setDealer(dl); setHideHole(true);
      setPhase('DEALING');

      // Brief deal animation, then check for naturals
      setTimeout(() => {
        if (isBlackjack(p) || isBlackjack(dl)) {
          setHideHole(false);
          finalize(p, dl, { ...r, balanceBefore: balBefore });
        } else {
          setPhase('PLAYER_TURN');
        }
      }, 1100);
    } finally {
      // re-allow start once the user has fully resolved this round
      setTimeout(() => { startRoundLockRef.current = false; }, 1200);
    }
  };

  /* ---------- Player actions ---------- */

  const hit = () => {
    if (phase !== 'PLAYER_TURN') return;
    playChip();
    const d = deck.slice();
    const p = player.concat([d.shift()]);
    setDeck(d); setPlayer(p);
    if (isBust(p) || value(p) === 21) {
      setHideHole(false);
      setTimeout(() => finalize(p, dealer, round), 600);
    }
  };

  const stand = () => {
    if (phase !== 'PLAYER_TURN') return;
    playClick();
    setPhase('DEALER_TURN');
    setHideHole(false);
    setTimeout(() => {
      const { deck: d, dealer: dl } = dealerPlay(deck, dealer);
      setDeck(d); setDealer(dl);
      setTimeout(() => finalize(player, dl, round), 700);
    }, 700);
  };

  const doubleDown = async () => {
    if (phase !== 'PLAYER_TURN' || player.length !== 2) return;
    const r2 = await wallet.lock(accountId, stake, 'blackjack');
    if (!r2.ok) { setError(r2.reason); return; }
    playChip();
    const d = deck.slice();
    const p = player.concat([d.shift()]);
    setDeck(d); setPlayer(p);
    setStake(stake * 2);
    // also need to settle the second locked stake — we'll merge into the
    // outcome by passing payout multiplied logic
    setHideHole(false);
    setTimeout(() => {
      // dealer plays out
      const { deck: d2, dealer: dl } = isBust(p) ? { deck: d, dealer: dealer } : dealerPlay(d, dealer);
      setDeck(d2); setDealer(dl);
      // settle BOTH locked rounds against the same hand result.
      finalizeDouble(p, dl, round, r2);
    }, 800);
  };

  /* ---------- Resolve ---------- */

  const finalize = async (p, dl, r) => {
    const balBefore = r?.balanceBefore ?? useWalletStore.getState().available;
    const { outcome, payout } = settle(stake, p, dl);
    await wallet.settle(accountId, {
      roundId: r.roundId, stake, payout, outcome,
      meta: { game: 'blackjack', player: p, dealer: dl },
    });
    const balAfter = useWalletStore.getState().available;

    auditRound({
      gameId: 'blackjack',
      roundId: r.roundId,
      accountId,
      bets: [{ type: 'STAKE', amount: String(stake), label: 'Blackjack hand' }],
      stake: String(stake),
      result: { player: p.map(c => `${c.r}${c.s}`), dealer: dl.map(c => `${c.r}${c.s}`) },
      payout, outcome, balanceBefore: balBefore, balanceAfter: balAfter,
    });

    setOutcome({ outcome, payout, balanceBefore: balBefore, balanceAfter: balAfter });
    setPhase('RESOLVED');
    playReveal();
  };

  const finalizeDouble = async (p, dl, r1, r2) => {
    // Settle each lock with the same outcome (each at the original stake)
    const original = stake / 2; // we doubled stake state earlier
    const result = settle(original, p, dl);
    for (const r of [r1, r2]) {
      await wallet.settle(accountId, {
        roundId: r.roundId, stake: original,
        payout: result.payout, outcome: result.outcome,
        meta: { game: 'blackjack', double: true, player: p, dealer: dl },
      });
    }
    setOutcome(result);
    setPhase('RESOLVED');
    playReveal();
  };

  const newRound = () => {
    setPhase('IDLE'); setStake(null); setRound(null);
    setDeck([]); setPlayer([]); setDealer([]); setOutcome(null);
    setHideHole(true);
  };

  /* ---------- 3D layout ---------- */

  const world = useMemo(() => (
    <>
      <BlackjackTable position={[0, 0, 0]} />
      {/* Player cards — fanned in front */}
      {player.map((c, i) => (
        <Card3D
          key={`p-${i}-${c.rank}-${c.suit}`}
          card={c}
          faceUp
          position={[
            -0.6 + i * 0.32,
            0.12 + i * 0.005,
            1.4 - i * 0.05,
          ]}
          rotation={[-Math.PI / 2.1, 0, (i - player.length / 2) * 0.08]}
        />
      ))}
      {/* Dealer cards */}
      {dealer.map((c, i) => (
        <Card3D
          key={`d-${i}-${c.rank}-${c.suit}`}
          card={c}
          faceUp={!(i === 1 && hideHole)}
          position={[
            -0.6 + i * 0.32,
            0.12 + i * 0.005,
            -0.8 + i * 0.05,
          ]}
          rotation={[-Math.PI / 2.1, 0, 0]}
        />
      ))}
    </>
  ), [player, dealer, hideHole]);

  const overlay = (
    <>
      <BackToHall router={router} t={t} />

      <LowBalanceBanner visible={phase === 'IDLE' && !gte(liveBalance, CHIP_DENOM[0])} />

      {/* Title plaque */}
      <motion.div
        initial={{ opacity: 0, y: -16 }}
        animate={{ opacity: 1, y:   0 }}
        transition={{ delay: 0.4, duration: 0.9 }}
        className="absolute top-24 left-1/2 -translate-x-1/2 text-center"
      >
        <div className="flex items-center justify-center gap-3 mb-1">
          <span className="hairline-gold w-8" />
          <span className="engraved text-[8px] text-aurum-gold/80">{t('blackjack.subtitle')}</span>
          <span className="hairline-gold w-8" />
        </div>
        <h2 className="font-display text-3xl md:text-4xl gold-leaf tracking-[0.06em]">
          {t('blackjack.title')}
        </h2>
      </motion.div>

      {/* Hand totals (top) */}
      <div className="absolute top-44 left-1/2 -translate-x-1/2 flex items-center gap-12">
        <HandTotal label={t('blackjack.dealer')} value={dealer.length ? dealerVal : '—'}
                   bust={!hideHole && isBust(dealer)} />
        <HandTotal label={t('blackjack.player')} value={player.length ? playerVal : '—'}
                   bust={isBust(player)} />
      </div>

      {/* Right panel — bet + actions */}
      <GlassPanel
        tint="noir" frame corners
        className="absolute top-1/2 right-8 -translate-y-1/2 w-[320px] p-6 rounded-md"
      >
        <div className="hairline-gold mb-4" />
        <div className="engraved text-[8px] text-aurum-gold/70 mb-3">
          {phase === 'IDLE' ? t('game.your_bet') : t('blackjack.atStake')}
        </div>

        {phase === 'IDLE' ? (
          <>
            <div className="flex items-center justify-around mb-6 perspective">
              {CHIP_DENOM.map((v) => (
                <Chip
                  key={v} value={v} size={56}
                  selected={chipValue === v}
                  onClick={() => setChipValue(v)}
                />
              ))}
            </div>
            <CinematicButton onClick={startRound} size="md" className="w-full">
              {t('blackjack.deal')}
            </CinematicButton>
          </>
        ) : (
          <>
            <div className="text-center mb-5">
              <div className="font-display text-3xl gold-leaf">{formatCurrency(stake)}</div>
            </div>
            <div className="hairline-gold mb-4" />
            <div className="engraved text-[8px] text-aurum-gold/70 mb-3">{t('blackjack.action')}</div>
            <div className="grid grid-cols-2 gap-2">
              <ActionBtn label={t('blackjack.hit')}    disabled={phase !== 'PLAYER_TURN'} onClick={hit}/>
              <ActionBtn label={t('blackjack.stand')}  disabled={phase !== 'PLAYER_TURN'} onClick={stand}/>
              <ActionBtn
                label={t('blackjack.double')}
                disabled={phase !== 'PLAYER_TURN' || player.length !== 2}
                onClick={doubleDown}
                className="col-span-2"
              />
            </div>
          </>
        )}

        <AnimatePresence>
          {error && (
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="mt-3 text-center text-[10px] tracking-[0.18em] text-red-400/80"
            >
              {error.replace(/_/g, ' ')}
            </motion.div>
          )}
        </AnimatePresence>
      </GlassPanel>

      {/* Outcome modal */}
      <AnimatePresence>
        {phase === 'RESOLVED' && outcome && (
          <motion.div
            initial={{ opacity: 0, scale: 0.5, filter: 'blur(20px)' }}
            animate={{ opacity: 1, scale: 1,   filter: 'blur(0px)'  }}
            exit   ={{ opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"
          >
            <GlassPanel tint="noir" frame corners className="px-12 py-10 rounded-sm text-center min-w-[320px]">
              <div className="engraved text-[8px] text-aurum-gold/70 mb-3">
                {outcome.outcome === 'WIN'  ? t('blackjack.win') :
                 outcome.outcome === 'PUSH' ? t('blackjack.push') : t('blackjack.loss')}
              </div>
              <div
                className="font-display text-[100px] leading-none tracking-tight"
                style={{
                  color: outcome.outcome === 'WIN' ? '#F4D78A'
                       : outcome.outcome === 'PUSH' ? '#EDE3CE' : '#7A0E14',
                  textShadow: '0 0 40px currentColor, 0 4px 0 rgba(0,0,0,0.6)',
                }}
              >
                {outcome.outcome === 'WIN' ? '+' : outcome.outcome === 'PUSH' ? '=' : '×'}
              </div>
              <div className="engraved text-[10px] text-aurum-goldHi mt-3">
                {t('blackjack.gain')} {formatCurrency(outcome.payout)}
              </div>
              <div className="mt-6">
                <CinematicButton onClick={newRound} size="sm">
                  {t('blackjack.newHand')}
                </CinematicButton>
              </div>
            </GlassPanel>
          </motion.div>
        )}
      </AnimatePresence>

      <style jsx>{`.perspective { perspective: 600px; }`}</style>
    </>
  );

  return (
    <GameRoom
      world={world}
      overlay={overlay}
      cameraProps={{ position: [0, 3.8, 4.2], fov: 38 }}
      beamProps={{ position: [0, 6, -0.6], height: 5.5, radius: 2.4, intensity: 0.85 }}
      fogColor="#08060E"
    />
  );
}

/* ---------- atoms ---------- */

function HandTotal({ label, value, bust }) {
  return (
    <GlassPanel tint="noir" animate={false} className="px-5 py-2 rounded-full">
      <div className="flex items-center gap-3">
        <span className="engraved text-[8px] text-aurum-smoke">{label}</span>
        <span
          className="font-display text-2xl"
          style={{
            color: bust ? '#E0573B' : '#F4D78A',
            filter: bust ? 'drop-shadow(0 0 8px #E0573B)' : 'drop-shadow(0 0 6px rgba(244,215,138,0.4))',
          }}
        >
          {value}
        </span>
      </div>
    </GlassPanel>
  );
}

function ActionBtn({ label, disabled, onClick, className = '' }) {
  return (
    <motion.button
      whileHover={{ y: -2 }}
      whileTap={{ scale: 0.95 }}
      onClick={() => { if (!disabled) { playClick(); onClick(); } }}
      disabled={disabled}
      className={`
        relative px-3 py-3 rounded-sm text-[10px] tracking-[0.24em]
        font-medium uppercase overflow-hidden disabled:opacity-30
        ${className}
      `}
      style={{
        background: 'linear-gradient(180deg, rgba(244,215,138,0.18), rgba(0,0,0,0.4))',
        color: '#F4D78A',
        border: '1px solid rgba(244,215,138,0.25)',
        boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.08)',
      }}
    >
      {label}
    </motion.button>
  );
}

function BackToHall({ router, t }) {
  return (
    <motion.button
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x:   0 }}
      transition={{ delay: 0.6, duration: 0.7 }}
      onClick={() => { playClick(); router.push('/lounge'); }}
      className="absolute top-24 left-8 engraved text-aurum-ivory/60 hover:text-aurum-goldHi
                 flex items-center gap-3 group"
    >
      <span className="w-8 h-px bg-aurum-gold/40 group-hover:bg-aurum-goldHi transition-colors" />
      {t ? t('game.back') : '← Back to the Floor'}
    </motion.button>
  );
}
