'use client';

import { Suspense } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { motion } from 'framer-motion';
import { useRouter } from 'next/navigation';
import dynamic from 'next/dynamic';

import { useAurumStore } from '@/store/useAurumStore';
import PortalCard         from '@/components/ui/PortalCard';
import CinematicLighting  from '@/components/three/CinematicLighting';
import LobbyRoom          from '@/components/three/LobbyRoom';
import DustParticles      from '@/components/effects/DustParticles';
import VolumetricBeam     from '@/components/effects/VolumetricBeam';
import { rigFor } from '@/ds/lighting';
import { playClick } from '@/lib/audio';
import { useT } from '@/lib/i18n';

const PostFX = dynamic(() => import('@/components/effects/PostFX'), { ssr: false });

const PORTAL_KEYS = [
  { id: 'roulette',  titleKey: 'rooms.roulette',  subKey: 'rooms.roulette.sub',  descKey: 'rooms.roulette.desc',  accent: '#C8A24A', href: '/lounge/roulette',  artId: 'roulette' },
  { id: 'blackjack', titleKey: 'rooms.blackjack', subKey: 'rooms.blackjack.sub', descKey: 'rooms.blackjack.desc', accent: '#E0573B', href: '/lounge/blackjack', artId: 'blackjack' },
  { id: 'slots',     titleKey: 'rooms.slots',     subKey: 'rooms.slots.sub',     descKey: 'rooms.slots.desc',     accent: '#6FA8DC', href: '/lounge/slots',     artId: 'slots' },
  { id: 'poker',     titleKey: 'rooms.poker',     subKey: 'rooms.poker.sub',     descKey: 'rooms.poker.desc',     accent: '#9B6FE0', href: '/lounge/poker',     artId: 'poker' },
  { id: 'plinko',    titleKey: 'rooms.plinko',    subKey: 'rooms.plinko.sub',    descKey: 'rooms.plinko.desc',    accent: '#4FA89A', href: '/lounge/plinko',    artId: 'plinko' },
];

const ART_FOR = {
  roulette:  <RouletteArt  />,
  blackjack: <BlackjackArt />,
  slots:     <SlotsArt     />,
  poker:     <PokerArt     />,
  plinko:    <PlinkoArt    />,
};

function LivingCamera({ targetPos = [0, 2.2, 5] }) {
  const { camera } = useThree();
  useFrame(({ clock }) => {
    const t = clock.elapsedTime;
    camera.position.x = targetPos[0] + Math.sin(t * 0.25) * 0.18;
    camera.position.y = targetPos[1] + Math.sin(t * 0.18) * 0.08;
    camera.lookAt(0, 1.5, -3);
  });
  return null;
}

export default function LoungePage() {
  const router = useRouter();
  const atmosphere = useAurumStore((s) => s.atmosphere);
  const rig = rigFor(atmosphere);
  const t = useT();

  const handlePortal = (id) => {
    const p = PORTAL_KEYS.find((x) => x.id === id);
    if (p) { playClick(); router.push(p.href); }
  };

  return (
    <motion.section
      initial={{ opacity: 0, filter: 'blur(20px)' }}
      animate={{ opacity: 1, filter: 'blur(0px)'  }}
      exit   ={{ opacity: 0, filter: 'blur(20px)' }}
      transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1] }}
      className="relative w-full h-screen overflow-hidden"
    >
      <div className="absolute inset-0">
        <Canvas
          camera={{ position: [0, 2.2, 5], fov: 42 }}
          dpr={[1, 1.6]}
          shadows
          gl={{ antialias: true, toneMapping: 2, toneMappingExposure: 0.95 }}
        >
          <Suspense fallback={null}>
            <fog attach="fog" args={['#0B0814', 6, 24]} />
            <CinematicLighting {...rig} />
            <LivingCamera targetPos={[0, 2.2, 5]} />
            <VolumetricBeam position={[-6, 6, -2]} height={6} radius={1.4} color="#FFC68A" intensity={0.6} />
            <VolumetricBeam position={[-2, 6, -3]} height={6} radius={1.4} color="#FFC68A" intensity={0.7} />
            <VolumetricBeam position={[ 2, 6, -3]} height={6} radius={1.4} color="#FFC68A" intensity={0.7} />
            <VolumetricBeam position={[ 6, 6, -2]} height={6} radius={1.4} color="#FFC68A" intensity={0.6} />
            <DustParticles count={500} area={16} color="#F4D78A" />
            <LobbyRoom />
            <PostFX intensity={0.95} />
          </Suspense>
        </Canvas>
      </div>

      {/* Title overlay */}
      <motion.div
        initial={{ opacity: 0, y: -16 }}
        animate={{ opacity: 1, y:   0 }}
        transition={{ duration: 1.2, delay: 0.3 }}
        className="absolute top-28 left-1/2 -translate-x-1/2 z-20 text-center pointer-events-none"
      >
        <div className="flex items-center justify-center gap-4 mb-3">
          <span className="hairline-gold w-12" />
          <span className="engraved text-[9px] text-aurum-gold/70">{t('lobby.subtitle')}</span>
          <span className="hairline-gold w-12" />
        </div>
        <h2 className="font-display text-5xl md:text-6xl gold-leaf tracking-[0.04em]">
          {t('lobby.title')}
        </h2>
        <p className="mt-3 text-aurum-ivory/50 italic text-sm md:text-base">
          {t('lobby.helper')}
        </p>
      </motion.div>

      {/* Portal cards — 4 rooms, fully translated */}
      <div className="absolute inset-x-0 bottom-12 z-20 flex items-end justify-center gap-6 px-8 pointer-events-auto flex-wrap">
        {PORTAL_KEYS.map((p, i) => (
          <PortalCard
            key={p.id}
            id={p.id}
            title={t(p.titleKey)}
            subtitle={t(p.subKey)}
            description={t(p.descKey)}
            accent={p.accent}
            sceneArt={ART_FOR[p.artId]}
            index={i}
            onActivate={handlePortal}
          />
        ))}
      </div>

      <div className="absolute inset-0 pointer-events-none z-30 vignette grain" />
    </motion.section>
  );
}

/* ---------- DIORAMAS ---------- */

function RouletteArt() {
  return (
    <svg viewBox="0 0 200 200" className="w-[80%] h-[80%]">
      <defs>
        <radialGradient id="rart-bg" cx="50%" cy="40%">
          <stop offset="0%" stopColor="#3A2A12" />
          <stop offset="100%" stopColor="#0A0608" />
        </radialGradient>
        <linearGradient id="rart-gold" x1="0" y1="0" x2="100%" y2="100%">
          <stop offset="0%"   stopColor="#FFF1C7" />
          <stop offset="50%"  stopColor="#C8A24A" />
          <stop offset="100%" stopColor="#7A5C18" />
        </linearGradient>
      </defs>
      <circle cx="100" cy="100" r="90" fill="url(#rart-bg)" />
      <g style={{ transformOrigin: '100px 100px', animation: 'spin 24s linear infinite' }}>
        <circle cx="100" cy="100" r="78" fill="none" stroke="url(#rart-gold)" strokeWidth="3" />
        {Array.from({ length: 37 }).map((_, i) => {
          const a = (i / 37) * Math.PI * 2;
          const x = 100 + Math.cos(a) * 70;
          const y = 100 + Math.sin(a) * 70;
          return (
            <circle key={i} cx={x} cy={y} r="3.5"
              fill={i === 0 ? '#0E4A2A' : i % 2 ? '#7A0E14' : '#0A0608'}
              stroke="url(#rart-gold)" strokeWidth="0.3" />
          );
        })}
      </g>
      <circle cx="100" cy="100" r="20" fill="url(#rart-gold)" />
      <circle cx="100" cy="100" r="6" fill="#05040A" />
    </svg>
  );
}

function BlackjackArt() {
  return (
    <svg viewBox="0 0 200 200" className="w-[80%] h-[80%]">
      <defs>
        <linearGradient id="bj-card" x1="0" y1="0" x2="100%" y2="100%">
          <stop offset="0%"  stopColor="#FAF3E0" />
          <stop offset="100%" stopColor="#D8C9A0" />
        </linearGradient>
        <linearGradient id="bj-gold" x1="0" y1="0" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#F4D78A" />
          <stop offset="100%" stopColor="#7A5C18" />
        </linearGradient>
      </defs>
      <ellipse cx="100" cy="120" rx="90" ry="60" fill="#1F4A3A" />
      <ellipse cx="100" cy="120" rx="80" ry="52" fill="none" stroke="url(#bj-gold)" strokeWidth="1" />
      {/* fanned cards */}
      {[-30, -10, 10, 30].map((rot, i) => (
        <g key={i} transform={`translate(100, 110) rotate(${rot}) translate(0, -25)`}>
          <rect x="-22" y="-32" width="44" height="64" rx="3"
            fill="url(#bj-card)" stroke="#7A5C18" strokeWidth="0.6" />
          <text x="-14" y="-18" fontFamily="Cormorant Garamond, serif" fontSize="14"
            fontWeight="500" fill={i % 2 ? '#7A0E14' : '#0A0608'}>
            {['A','J','Q','K'][i]}
          </text>
          <text x="-15" y="0" fontFamily="serif" fontSize="22"
            fill={i % 2 ? '#7A0E14' : '#0A0608'}>
            {['♠','♦','♣','♥'][i]}
          </text>
        </g>
      ))}
    </svg>
  );
}

function SlotsArt() {
  return (
    <svg viewBox="0 0 200 200" className="w-[80%] h-[80%]">
      <defs>
        <linearGradient id="sl-bg" x1="0" y1="0" x2="0" y2="100%">
          <stop offset="0%" stopColor="#2A1810" />
          <stop offset="100%" stopColor="#0A0608" />
        </linearGradient>
        <linearGradient id="sl-gold" x1="0" y1="0" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#F4D78A" />
          <stop offset="100%" stopColor="#7A5C18" />
        </linearGradient>
      </defs>
      <rect x="20" y="20" width="160" height="160" rx="8" fill="url(#sl-bg)" stroke="url(#sl-gold)" strokeWidth="2" />
      <rect x="34" y="60" width="40" height="80" fill="#0A0608" stroke="url(#sl-gold)" strokeWidth="1" />
      <rect x="80" y="60" width="40" height="80" fill="#0A0608" stroke="url(#sl-gold)" strokeWidth="1" />
      <rect x="126" y="60" width="40" height="80" fill="#0A0608" stroke="url(#sl-gold)" strokeWidth="1" />
      {['7', '7', '7'].map((s, i) => (
        <text key={i} x={54 + i * 46} y="108"
          textAnchor="middle"
          fontFamily="Cormorant Garamond, serif" fontStyle="italic"
          fontSize="36" fill="url(#sl-gold)">
          {s}
        </text>
      ))}
      <rect x="34" y="40" width="132" height="14" fill="url(#sl-gold)" rx="2" />
      <text x="100" y="51" textAnchor="middle" fontSize="9"
        fontFamily="Inter Tight, sans-serif" fontWeight="600"
        letterSpacing="3" fill="#05040A">
        AURUM
      </text>
    </svg>
  );
}

function PokerArt() {
  return (
    <svg viewBox="0 0 200 200" className="w-[80%] h-[80%]">
      <defs>
        <radialGradient id="pk-felt" cx="50%" cy="50%" r="80%">
          <stop offset="0%" stopColor="#3A0E18" />
          <stop offset="100%" stopColor="#0A0408" />
        </radialGradient>
        <linearGradient id="pk-gold" x1="0" y1="0" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#F4D78A" />
          <stop offset="100%" stopColor="#7A5C18" />
        </linearGradient>
      </defs>
      <ellipse cx="100" cy="110" rx="92" ry="55" fill="url(#pk-felt)" />
      <ellipse cx="100" cy="110" rx="82" ry="48" fill="none" stroke="url(#pk-gold)" strokeWidth="0.8" />
      {/* community cards */}
      {[-32, -16, 0, 16, 32].map((dx, i) => (
        <g key={i} transform={`translate(${100 + dx}, 110)`}>
          <rect x="-7" y="-12" width="14" height="22" rx="1.5"
            fill="#FAF3E0" stroke="#7A5C18" strokeWidth="0.4" />
        </g>
      ))}
      {/* chip stacks */}
      {[20, 50, 80, 150, 180].map((cx, i) => (
        <g key={i} transform={`translate(${cx}, 145)`}>
          {[0, -3, -6, -9].map((dy) => (
            <ellipse key={dy} cx="0" cy={dy} rx="9" ry="2.5" fill="url(#pk-gold)" />
          ))}
        </g>
      ))}
    </svg>
  );
}

function PlinkoArt() {
  // Triangle of glowing pegs over a dark felt — instantly readable as Plinko
  return (
    <svg viewBox="0 0 200 200" className="w-[80%] h-[80%]">
      <defs>
        <radialGradient id="pl-art-bg" cx="50%" cy="35%" r="80%">
          <stop offset="0%" stopColor="#0E1E2A" />
          <stop offset="100%" stopColor="#04060A" />
        </radialGradient>
        <radialGradient id="pl-art-peg" cx="40%" cy="40%" r="60%">
          <stop offset="0%" stopColor="#FFF1C7" />
          <stop offset="100%" stopColor="#7A5C18" />
        </radialGradient>
      </defs>
      <rect x="20" y="20" width="160" height="160" rx="12" fill="url(#pl-art-bg)"
            stroke="rgba(244,215,138,0.3)" strokeWidth="0.6" />
      {/* triangle of pegs */}
      {[0,1,2,3,4,5,6].map((row) =>
        Array.from({ length: row + 1 }).map((_, col) => (
          <circle
            key={`${row}-${col}`}
            cx={100 + (col - row / 2) * 18}
            cy={42 + row * 16}
            r={2.4}
            fill="url(#pl-art-peg)"
          />
        ))
      )}
      {/* slots row */}
      {[-3,-2,-1,0,1,2,3].map((s, i) => {
        const x = 100 + s * 18;
        const high = Math.abs(s) >= 3;
        return (
          <g key={i}>
            <rect x={x - 8} y={162} width={16} height={14} rx={1.5}
                  fill={high ? 'rgba(244,215,138,0.25)' : 'rgba(40,30,15,0.4)'}
                  stroke="rgba(244,215,138,0.3)" strokeWidth={0.4} />
          </g>
        );
      })}
      {/* falling ball */}
      <circle cx="100" cy="32" r="3.5" fill="#F4D78A"
              style={{ filter: 'drop-shadow(0 0 4px #F4D78A)' }} />
    </svg>
  );
}
