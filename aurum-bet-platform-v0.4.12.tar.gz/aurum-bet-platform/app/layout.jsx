import './globals.css';
import Providers from '@/components/Providers';

export const metadata = {
  title:       'AURUM — Maison de Jeu',
  description: 'Une expérience privée. Là où le hasard se fait soie.',
  manifest:    '/manifest.json',
  appleWebApp: {
    capable:   true,
    statusBarStyle: 'black-translucent',
    title:     'AURUM',
  },
  icons: {
    icon:       [{ url: '/icons/icon-192.svg', type: 'image/svg+xml' }],
    apple:      [{ url: '/icons/icon-192.svg' }],
  },
};

export const viewport = {
  width:        'device-width',
  initialScale: 1,
  maximumScale: 1,
  themeColor:   '#05040A',
};

export default function RootLayout({ children }) {
  return (
    <html lang="fr">
      <body className="antialiased">
        <Providers>
          {children}
        </Providers>
      </body>
    </html>
  );
}
