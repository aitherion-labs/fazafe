'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

import AuthShell      from '@/components/ui/AuthShell';
import FormField      from '@/components/ui/FormField';
import CinematicButton from '@/components/ui/CinematicButton';
import { useAccountStore } from '@/store/useAccountStore';
import { playClick } from '@/lib/audio';
import { useT } from '@/lib/i18n';

export default function LoginPage() {
  const router = useRouter();
  const login  = useAccountStore((s) => s.login);
  const t      = useT();
  const [email, setEmail] = useState('');
  const [pwd, setPwd]     = useState('');
  const [err, setErr]     = useState(null);

  const submit = (e) => {
    e?.preventDefault?.();
    if (!email.includes('@')) { setErr('Email invalide'); return; }
    if (pwd.length < 4)       { setErr('Mot de passe trop court'); return; }
    playClick();
    const r = login({ email });
    if (r.ok) router.push('/lounge');
  };

  return (
    <AuthShell
      title={t('auth.login.title')}
      subtitle={t('auth.login.subtitle')}
      footer={
        <>
          Pas encore membre ?{' '}
          <Link href="/account/signup" className="text-aurum-goldHi hover:text-aurum-gold-pale underline-offset-4 hover:underline">
            Demander adhésion
          </Link>
        </>
      }
    >
      <FormField
        label="Adresse électronique"
        type="email"
        value={email}
        onChange={setEmail}
        placeholder="vous@maison.fr"
        autoComplete="email"
      />
      <FormField
        label="Mot de passe"
        type="password"
        value={pwd}
        onChange={setPwd}
        placeholder="••••••••"
        autoComplete="current-password"
      />

      {err && (
        <div className="text-[10px] tracking-[0.18em] text-red-400/80 text-center mb-4">
          {err}
        </div>
      )}

      <div className="mt-2">
        <CinematicButton onClick={submit} size="md" className="w-full">
          {t('common.enter')}
        </CinematicButton>
      </div>

      <div className="mt-4 text-center">
        <button
          onClick={() => router.push('/demo')}
          className="text-[9px] tracking-[0.32em] text-aurum-smoke hover:text-aurum-gold uppercase"
        >
          ◇ ou démonstration ◇
        </button>
      </div>

      <p className="mt-5 text-center engraved text-[7px] text-aurum-smoke leading-relaxed">
        V0.1 · Auth simulée · Toute saisie crée une session locale
      </p>
    </AuthShell>
  );
}
