'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { motion } from 'framer-motion';

import AuthShell from '@/components/ui/AuthShell';
import { GlassPanel, CinematicButton } from '@/ds/components';
import { useAccountStore } from '@/store/useAccountStore';
import { useWalletStore }  from '@/store/useWalletStore';
import { getStatus } from '@/services/compliance';
import { playClick } from '@/lib/audio';

export default function ProfilePage() {
  const router    = useRouter();
  const account   = useAccountStore();
  const wallet    = useWalletStore((s) => s.formatted());
  const [comp, setComp] = useState(null);

  useEffect(() => { setComp(getStatus()); }, []);

  if (!account.accountId) {
    if (typeof window !== 'undefined') router.replace('/account/login');
    return null;
  }

  const sessionStarted = account.sessionStart
    ? new Date(account.sessionStart).toLocaleString('fr-FR')
    : '—';

  return (
    <AuthShell title="Mon Dossier" subtitle={`Bonsoir, ${account.handle}.`}>
      <div className="space-y-4">
        <Row label="Pseudonyme"      value={account.handle} />
        <Row label="Adresse"         value={account.email} />
        <Row label="Identifiant"     value={account.accountId} mono />
        <Row label="Session ouverte" value={sessionStarted} />

        <div className="hairline-gold !my-6" />

        <Row label="Patrimoine disponible" value={wallet.available} highlight />
        <Row label="Mises en jeu"          value={wallet.locked} />
        <Row label="Total déposé"          value={wallet.lifetime} />

        <div className="hairline-gold !my-6" />

        <Row
          label="Niveau KYC"
          value={comp ? `Niveau ${comp.kycLevel}` : '—'}
          accent={comp?.kycLevel >= 2}
        />
        <Row
          label="Auto-exclusion"
          value={comp?.selfExcluded ? 'ACTIVE' : 'inactive'}
          warning={comp?.selfExcluded}
        />
      </div>

      <div className="mt-6 grid grid-cols-2 gap-2">
        <Link href="/wallet" onClick={playClick}>
          <button className="w-full px-3 py-2.5 rounded-sm text-[10px] tracking-[0.24em]
                            font-medium uppercase text-aurum-goldHi hover:text-aurum-gold-pale
                            border border-aurum-gold/25 transition-colors">
            La Voûte
          </button>
        </Link>
        <Link href="/compliance" onClick={playClick}>
          <button className="w-full px-3 py-2.5 rounded-sm text-[10px] tracking-[0.24em]
                            font-medium uppercase text-aurum-goldHi hover:text-aurum-gold-pale
                            border border-aurum-gold/25 transition-colors">
            Conformité
          </button>
        </Link>
      </div>

      <div className="mt-6">
        <button
          onClick={() => { playClick(); account.logout(); router.push('/'); }}
          className="w-full px-3 py-2.5 rounded-sm text-[10px] tracking-[0.32em]
                    font-medium uppercase text-aurum-ivory/50 hover:text-red-400/80
                    border border-aurum-ivory/10 hover:border-red-400/30 transition-colors"
        >
          Quitter la maison
        </button>
      </div>
    </AuthShell>
  );
}

function Row({ label, value, mono = false, highlight = false, accent = false, warning = false }) {
  return (
    <div className="flex items-baseline justify-between gap-4">
      <span className="engraved text-[8px] text-aurum-smoke">{label}</span>
      <span
        className={`
          ${mono ? 'font-mono text-[10px]' : 'font-display text-base'}
          ${highlight ? 'gold-leaf' :
            accent ? 'text-aurum-goldHi' :
            warning ? 'text-red-400/80' : 'text-aurum-ivory/85'}
          truncate max-w-[60%] text-right
        `}
      >
        {value}
      </span>
    </div>
  );
}
