'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

import AuthShell      from '@/components/ui/AuthShell';
import FormField      from '@/components/ui/FormField';
import CinematicButton from '@/components/ui/CinematicButton';
import { useAccountStore } from '@/store/useAccountStore';
import { setStatus as setCompliance } from '@/services/compliance';
import { playClick } from '@/lib/audio';
import { useT } from '@/lib/i18n';

export default function SignupPage() {
  const router = useRouter();
  const signup = useAccountStore((s) => s.signup);
  const t      = useT();
  const [handle, setHandle] = useState('');
  const [email,  setEmail]  = useState('');
  const [pwd,    setPwd]    = useState('');
  const [agree,  setAgree]  = useState(false);
  const [err,    setErr]    = useState(null);

  const submit = (e) => {
    e?.preventDefault?.();
    if (!handle)         return setErr('Choisissez un pseudonyme');
    if (!email.includes('@')) return setErr('Email invalide');
    if (pwd.length < 4)  return setErr('Mot de passe trop court');
    if (!agree)          return setErr('Veuillez accepter les conditions');
    playClick();
    const r = signup({ email, handle });
    setCompliance({ acceptedTerms: true, email, kycLevel: 1, emailVerified: true });
    if (r.ok) router.push('/compliance/kyc');
  };

  return (
    <AuthShell
      title={t('auth.signup.title')}
      subtitle={t('auth.signup.subtitle')}
      footer={
        <>
          Déjà membre ?{' '}
          <Link href="/account/login" className="text-aurum-goldHi hover:text-aurum-gold-pale underline-offset-4 hover:underline">
            S'identifier
          </Link>
        </>
      }
    >
      <FormField label="Pseudonyme" value={handle} onChange={setHandle} placeholder="initié-23" />
      <FormField label="Adresse électronique" type="email" value={email} onChange={setEmail} placeholder="vous@maison.fr" autoComplete="email" />
      <FormField label="Mot de passe" type="password" value={pwd} onChange={setPwd} placeholder="••••••••" autoComplete="new-password" />

      <label className="flex items-start gap-3 mb-5 cursor-pointer">
        <input
          type="checkbox"
          checked={agree}
          onChange={(e) => setAgree(e.target.checked)}
          className="mt-1"
          style={{ accentColor: '#C8A24A' }}
        />
        <span className="text-[10px] text-aurum-ivory/60 leading-relaxed">
          J'accepte les{' '}
          <Link href="/compliance" className="text-aurum-goldHi underline-offset-4 hover:underline">
            Conditions d'usage
          </Link>{' '}
          et confirme avoir 18 ans révolus.
        </span>
      </label>

      {err && (
        <div className="text-[10px] tracking-[0.18em] text-red-400/80 text-center mb-4">
          {err}
        </div>
      )}

      <CinematicButton onClick={submit} size="md" className="w-full">
        Demander adhésion
      </CinematicButton>

      <p className="mt-5 text-center engraved text-[7px] text-aurum-smoke leading-relaxed">
        Une vérification (KYC) suivra l'inscription
      </p>
    </AuthShell>
  );
}
