'use client';

import { Suspense, useState } from 'react';
import { Canvas } from '@react-three/fiber';
import { motion, AnimatePresence } from 'framer-motion';
import { useRouter } from 'next/navigation';
import dynamic from 'next/dynamic';

import { useAurumStore }   from '@/store/useAurumStore';
import { useAccountStore } from '@/store/useAccountStore';
import { audio } from '@/lib/audio';
import { useT }  from '@/lib/i18n';

import CinematicButton    from '@/components/ui/CinematicButton';
import Loader             from '@/components/ui/Loader';
import CinematicLighting  from '@/components/three/CinematicLighting';
import RouletteWheel      from '@/components/three/RouletteWheel';
import DustParticles      from '@/components/effects/DustParticles';
import VolumetricBeam     from '@/components/effects/VolumetricBeam';

const PostFX = dynamic(() => import('@/components/effects/PostFX'), { ssr: false });

/**
 * AURUM — root entry page.
 * Identical cinematic feel to V0.0, now wired to Next.js router.
 *  - "Franchir le Seuil"  → /lounge      (or /account/login if not auth'd)
 *  - "Mode Démonstration" → /demo
 */
export default function HomePage() {
  const router    = useRouter();
  const isLoading = useAurumStore((s) => s.isLoading);
  const toggleA   = useAurumStore((s) => s.toggleAudio);
  const audioOn   = useAurumStore((s) => s.audioEnabled);
  const isAuth    = useAccountStore((s) => s.isAuthenticated());
  const t         = useT();
  const [exiting, setExiting] = useState(false);

  const enter = (target) => {
    if (!audioOn) { audio.enable(); toggleA(); }
    setExiting(true);
    setTimeout(() => router.push(target), 700);
  };

  return (
    <>
      <AnimatePresence>{isLoading && <Loader />}</AnimatePresence>

      <motion.section
        animate={{ opacity: exiting ? 0 : 1, filter: exiting ? 'blur(20px)' : 'blur(0px)' }}
        transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        className="relative w-full h-screen overflow-hidden grain vignette spotlight"
      >
        {/* defocused 3D wheel */}
        <div className="absolute inset-0" style={{ filter: 'blur(14px) saturate(1.1) brightness(0.7)' }}>
          <Canvas camera={{ position: [0, 1.2, 4.5], fov: 35 }} dpr={[1, 1.6]} shadows
                  gl={{ antialias: true, toneMapping: 2 }}>
            <Suspense fallback={null}>
              <CinematicLighting intensity={1.0} />
              <fog attach="fog" args={['#05040A', 4, 14]} />
              <VolumetricBeam position={[0, 4, 0]} height={6} radius={2.2} intensity={0.9} />
              <DustParticles count={400} area={8} color="#F4D78A" />
              <RouletteWheel position={[0, 0, 0]} scale={1.1} />
              <PostFX intensity={1.1} />
            </Suspense>
          </Canvas>
        </div>

        {/* cinematic bars */}
        <motion.div initial={{ y: '-100%' }} animate={{ y: 0 }}
          transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
          className="absolute top-0 left-0 right-0 h-[8vh] z-30 pointer-events-none"
          style={{ background: 'linear-gradient(180deg, #000 0%, transparent 100%)' }} />
        <motion.div initial={{ y: '100%' }} animate={{ y: 0 }}
          transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1], delay: 0.1 }}
          className="absolute bottom-0 left-0 right-0 h-[12vh] z-30 pointer-events-none"
          style={{ background: 'linear-gradient(0deg, #000 0%, transparent 100%)' }} />

        {/* content */}
        <div className="absolute inset-0 z-40 flex flex-col items-center justify-center px-6">
          <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.2, delay: 0.3 }}
            className="absolute top-12 left-1/2 -translate-x-1/2 flex items-center gap-4">
            <span className="hairline-gold w-12" />
            <span className="engraved text-[9px] text-aurum-gold/80">{t('entry.private')}</span>
            <span className="hairline-gold w-12" />
          </motion.div>

          <motion.div initial={{ opacity: 0, scale: 0.8, filter: 'blur(20px)' }}
            animate={{ opacity: 1, scale: 1, filter: 'blur(0px)' }}
            transition={{ duration: 1.8, delay: 0.6, ease: [0.22, 1, 0.36, 1] }}
            className="mb-8">
            <Sigil />
          </motion.div>

          <motion.h1 initial={{ opacity: 0, y: 30, letterSpacing: '0.4em' }}
            animate={{ opacity: 1, y: 0, letterSpacing: '0.18em' }}
            transition={{ duration: 2.2, delay: 0.9, ease: [0.22, 1, 0.36, 1] }}
            className="font-display text-[clamp(72px,14vw,200px)] leading-none tracking-[0.18em]
                       gold-leaf select-none"
            style={{ filter: 'drop-shadow(0 0 60px rgba(244,215,138,0.18))' }}>
            AURUM
          </motion.h1>

          <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.4, delay: 1.6 }}
            className="mt-2 font-display italic text-aurum-ivory/70 text-lg md:text-xl">
            {t('entry.tagline')}
          </motion.p>

          <motion.div initial={{ width: 0, opacity: 0 }} animate={{ width: 220, opacity: 1 }}
            transition={{ duration: 1.8, delay: 1.9 }}
            className="hairline-gold mt-10 mb-12" />

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.2, delay: 2.1 }}
            className="flex flex-col items-center gap-5">
            <CinematicButton onClick={() => enter(isAuth ? '/lounge' : '/account/login')} size="lg">
              {t('entry.cta')}
            </CinematicButton>
            <button
              onClick={() => enter('/demo')}
              className="text-[10px] tracking-[0.32em] text-aurum-smoke hover:text-aurum-gold uppercase transition-colors mt-2"
            >
              {t('entry.demo')}
            </button>
          </motion.div>

          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
            transition={{ duration: 1.0, delay: 2.5 }}
            className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-3">
            <div className="flex items-center gap-3 engraved text-[8px] text-aurum-smoke">
              <span>· EST. MMXXV ·</span>
              <span className="text-aurum-gold/40">◆</span>
              <span>· MEMBRES UNIQUEMENT ·</span>
              <span className="text-aurum-gold/40">◆</span>
              <span>· DISCRÉTION ABSOLUE ·</span>
            </div>
          </motion.div>
        </div>
      </motion.section>
    </>
  );
}

function Sigil() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" className="drop-shadow-[0_0_24px_rgba(244,215,138,0.4)]">
      <defs>
        <linearGradient id="entry-sigil" x1="0" y1="0" x2="64" y2="64">
          <stop offset="0%"   stopColor="#FFF1C7" />
          <stop offset="50%"  stopColor="#C8A24A" />
          <stop offset="100%" stopColor="#7A5C18" />
        </linearGradient>
      </defs>
      <circle cx="32" cy="32" r="30" fill="none" stroke="url(#entry-sigil)" strokeWidth="0.5" />
      <circle cx="32" cy="32" r="22" fill="none" stroke="url(#entry-sigil)" strokeWidth="0.4" opacity="0.6" />
      <path d="M 32 6 L 36 28 L 58 32 L 36 36 L 32 58 L 28 36 L 6 32 L 28 28 Z" fill="url(#entry-sigil)" />
      <circle cx="32" cy="32" r="3" fill="#05040A" />
    </svg>
  );
}
