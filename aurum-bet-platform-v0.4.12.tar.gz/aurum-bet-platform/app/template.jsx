'use client';

import { motion } from 'framer-motion';

/**
 * App Router template — wraps every route change with a cinematic
 * fade+blur transition. Unlike `layout`, `template` re-mounts on
 * navigation, which is exactly what we want for cross-fades.
 */
export default function Template({ children }) {
  return (
    <motion.div
      initial={{ opacity: 0, filter: 'blur(20px)' }}
      animate={{ opacity: 1, filter: 'blur(0px)' }}
      transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  );
}
