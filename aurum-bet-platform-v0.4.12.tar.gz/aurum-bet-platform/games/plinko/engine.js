/**
 * AURUM PLINKO ENGINE
 *
 * A Galton board: the ball falls through N rows of pegs, bouncing L or R
 * at each one with 50/50 probability. After N decisions, it lands in one
 * of N+1 slots. Each slot has a multiplier, and the player wins
 * stake × multiplier.
 *
 * The final slot follows a binomial distribution Bin(N, 0.5): the middle
 * is by far the most likely (≈22% for the very center with N=12), and
 * the outer edges are rare (1/4096 each for the extremes with N=12).
 *
 * Multipliers are calibrated so that:
 *   • The expected return (RTP) per round is around 93-96%
 *   • The middle slots pay sub-1× (where most balls land — guaranteed
 *     loss-rate for the player), funding the rare large payouts
 *   • The outer slots pay big — they're where the dopamine lives
 *
 * Two risk modes:
 *   SAFE:   low variance, max 16×, middle 0.5×  (RTP 95.58%)
 *   DARING: high variance, max 110×, middle 0.3× (RTP 93.85%)
 *
 * The math behind these RTPs:
 *
 *   Slot probabilities for N=12 (denominator 4096):
 *     slot 0/12: 1 each       slot 1/11: 12 each
 *     slot 2/10: 66 each      slot 3/9:  220 each
 *     slot 4/8:  495 each     slot 5/7:  792 each
 *     slot 6:    924
 *
 *   RTP = Σ P(slot) × mult(slot)
 */

export const ROWS  = 12;
export const SLOTS = ROWS + 1;

export const RISK = { SAFE: 'SAFE', DARING: 'DARING' };

export const MULTIPLIERS = {
  // Symmetric arrays of length SLOTS=13. RTP calculated below.
  SAFE:   [16,  5,  2,  1.3, 1.05, 0.9, 0.5, 0.9, 1.05, 1.3, 2,  5,  16],
  DARING: [110, 8,  3,  1.5, 1,    0.7, 0.3, 0.7, 1,    1.5, 3,  8,  110],
};

// Theoretical RTP based on Bin(12, 0.5) distribution
export const RTP = {
  SAFE:   0.9558,   // verified empirically below
  DARING: 0.9385,
};

/* ---------- Path generation ---------- */

/**
 * Generate one random path through the board.
 *
 * Returns:
 *   {
 *     path:    array of 'L' | 'R' (length = rows)
 *     slotIdx: integer in [0, rows] — the landing slot (= count of 'R')
 *   }
 *
 * Each row independently with P(R) = 0.5. The slot is determined by
 * how many R's appeared (range: 0 = all-left to ROWS = all-right).
 */
export function generatePath(rows = ROWS) {
  const path = [];
  let slotIdx = 0;
  for (let r = 0; r < rows; r++) {
    const right = Math.random() < 0.5;
    path.push(right ? 'R' : 'L');
    if (right) slotIdx++;
  }
  return { path, slotIdx };
}

/**
 * Generate a path that lands in a specific slot. Useful for tests
 * or for "rigged" deterministic demo modes.
 */
export function pathToSlot(targetSlot, rows = ROWS) {
  if (targetSlot < 0 || targetSlot > rows) throw new Error('Invalid slot');
  // Shuffle a sequence of targetSlot R's and (rows - targetSlot) L's
  const moves = [];
  for (let i = 0; i < targetSlot; i++) moves.push('R');
  for (let i = 0; i < rows - targetSlot; i++) moves.push('L');
  // Fisher-Yates
  for (let i = moves.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [moves[i], moves[j]] = [moves[j], moves[i]];
  }
  return { path: moves, slotIdx: targetSlot };
}

/* ---------- Multipliers ---------- */

export function getMultiplier(risk, slotIdx) {
  const arr = MULTIPLIERS[risk];
  if (!arr) return 0;
  return arr[slotIdx] ?? 0;
}

/* ---------- RTP verification ---------- */

/**
 * Empirical RTP via simulation. The theoretical values in `RTP` above
 * should match these within ~0.5% for 100k iterations.
 */
export function simulateRTP(risk, iterations = 100000) {
  const arr = MULTIPLIERS[risk];
  if (!arr) return 0;
  let total = 0;
  for (let i = 0; i < iterations; i++) {
    const { slotIdx } = generatePath();
    total += arr[slotIdx];
  }
  return total / iterations;
}

/* ---------- Layout helpers (used by the page) ---------- */

/**
 * Compute pixel-space peg positions for an SVG board.
 *
 * The board uses a triangular peg layout where row r has r+1 pegs.
 * Row 0 is the topmost row (a single peg), row ROWS-1 is the widest.
 *
 * Coordinate system:
 *   centerX:        horizontal center
 *   topY:           y of the first row
 *   rowSpacing:     y distance between rows
 *   pegSpacing:     x distance between adjacent pegs in the same row
 *
 * Returns:
 *   pegs:  [{ row, col, x, y }]
 *   slots: [{ idx, x, y }] — slot center positions below the last row
 */
export function buildBoardLayout({
  rows = ROWS,
  centerX = 240,
  topY = 40,
  rowSpacing = 28,
  pegSpacing = 28,
} = {}) {
  const half = pegSpacing / 2;
  const pegs = [];
  for (let r = 0; r < rows; r++) {
    const pegCountInRow = r + 1;
    for (let c = 0; c < pegCountInRow; c++) {
      // Pegs spread symmetrically around centerX
      // For r pegs, positions are at center + (c - (pegCountInRow-1)/2) * pegSpacing
      const x = centerX + (c - r / 2) * pegSpacing;
      const y = topY + r * rowSpacing;
      pegs.push({ row: r, col: c, x, y });
    }
  }

  // Slots sit below the last row, one per "gap" between adjacent pegs
  // plus one at each end. With ROWS rows in a triangle layout, the last
  // row has ROWS pegs, so there are ROWS+1 = SLOTS gaps.
  const slotsY = topY + rows * rowSpacing + 26;
  const slots = [];
  for (let s = 0; s < rows + 1; s++) {
    // The ball lands in slot s if it had s R's out of ROWS decisions.
    // Position: starting from leftmost slot, evenly spaced by pegSpacing.
    const x = centerX + (s - rows / 2) * pegSpacing;
    slots.push({ idx: s, x, y: slotsY });
  }

  return { pegs, slots };
}

/**
 * Convert a path (array of L/R) into the (x, y) keyframes the ball
 * travels through. Returns an array of points starting from the top
 * (ball entry) and ending at the slot.
 */
export function pathToKeyframes(path, layout) {
  const { rows = ROWS } = {};
  const pegSpacing = (layout.pegs[1]?.x ?? 28) - (layout.pegs[0]?.x ?? 0);
  // Recover params from layout
  const centerX = layout.pegs[0]?.x ?? 240;  // top-row peg is at centerX
  const topY    = layout.pegs[0]?.y ?? 40;
  const rowSpacing = (layout.pegs[1]?.y ?? topY + 28) - topY;
  const half = (layout.pegs[1] && layout.pegs[2])
    ? Math.abs(layout.pegs[2].x - layout.pegs[1].x) / 2
    : 14;

  // Track ball position in "half-spacing" units (offset from center)
  let offset = 0;
  const points = [];
  // Entry point — just above the first peg
  points.push({ x: centerX, y: topY - 18 });

  for (let r = 0; r < path.length; r++) {
    // After hitting row r's peg, ball drifts L or R by half-spacing
    if (path[r] === 'R') offset += 1;
    else offset -= 1;
    const y = topY + r * rowSpacing + rowSpacing * 0.6;
    const x = centerX + offset * half;
    points.push({ x, y });
  }

  // Final landing — drop into slot
  const slotIdx = path.filter((p) => p === 'R').length;
  const slot = layout.slots[slotIdx];
  if (slot) points.push({ x: slot.x, y: slot.y - 8 });

  return points;
}
