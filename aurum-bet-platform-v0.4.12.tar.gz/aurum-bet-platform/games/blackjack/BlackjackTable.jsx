'use client';

import { useMemo } from 'react';
import * as THREE from 'three';

/**
 * Procedural blackjack table.
 * - Semicircular felt with brass rim
 * - Dealer-side arc with "Dealer must stand on 17" engraving
 * - Player betting spot circle in front
 * - Mahogany under-rail with brass studs
 */
export default function BlackjackTable({ position = [0, 0, 0] }) {
  // ---- felt with engraved arc text (canvas) ----
  const feltMap = useMemo(() => {
    if (typeof document === 'undefined') return null;
    const c = document.createElement('canvas');
    c.width = 1024; c.height = 1024;
    const ctx = c.getContext('2d');
    // base baize green
    ctx.fillStyle = '#1F4A3A';
    ctx.fillRect(0, 0, 1024, 1024);
    // weave noise
    for (let i = 0; i < 28000; i++) {
      ctx.fillStyle = `rgba(${20 + Math.random() * 25},${50 + Math.random() * 30},${30 + Math.random() * 25},0.5)`;
      ctx.fillRect(Math.random() * 1024, Math.random() * 1024, 1, 1);
    }
    // dealer arc text
    ctx.save();
    ctx.translate(512, 320);
    ctx.fillStyle = '#F4D78A';
    ctx.font = 'italic 32px "Cormorant Garamond", serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('· DEALER MUST DRAW TO 16 · STAND ON ALL 17 ·', 0, 0);
    ctx.restore();
    // central insurance line
    ctx.strokeStyle = 'rgba(244, 215, 138, 0.45)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(512, 460, 280, Math.PI * 0.05, Math.PI * 0.95);
    ctx.stroke();
    ctx.font = '500 18px "Inter Tight", sans-serif';
    ctx.fillStyle = 'rgba(244, 215, 138, 0.5)';
    ctx.fillText('I N S U R A N C E    P A Y S    2 : 1', 512, 440);
    // payout text
    ctx.font = 'italic 28px "Cormorant Garamond", serif';
    ctx.fillStyle = '#F4D78A';
    ctx.fillText('Blackjack pays 3 to 2', 512, 750);
    // betting circles
    [-220, 0, 220].forEach((dx) => {
      ctx.strokeStyle = '#F4D78A';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(512 + dx, 870, 60, 0, Math.PI * 2);
      ctx.stroke();
    });
    // vignette
    const grd = ctx.createRadialGradient(512, 600, 200, 512, 600, 700);
    grd.addColorStop(0, 'rgba(0,0,0,0)');
    grd.addColorStop(1, 'rgba(0,0,0,0.55)');
    ctx.fillStyle = grd;
    ctx.fillRect(0, 0, 1024, 1024);
    const t = new THREE.CanvasTexture(c);
    t.anisotropy = 8;
    return t;
  }, []);

  // mahogany texture (procedural)
  const woodMap = useMemo(() => {
    if (typeof document === 'undefined') return null;
    const c = document.createElement('canvas');
    c.width = 512; c.height = 128;
    const ctx = c.getContext('2d');
    const g = ctx.createLinearGradient(0, 0, 0, 128);
    g.addColorStop(0, '#3A1810'); g.addColorStop(0.5, '#2A0E08'); g.addColorStop(1, '#1A0604');
    ctx.fillStyle = g; ctx.fillRect(0, 0, 512, 128);
    for (let i = 0; i < 60; i++) {
      ctx.strokeStyle = `rgba(${40 + Math.random() * 30},${15 + Math.random() * 15},${5 + Math.random() * 10},0.5)`;
      ctx.lineWidth = 0.4 + Math.random() * 0.6;
      ctx.beginPath();
      const y = Math.random() * 128;
      ctx.moveTo(0, y);
      ctx.bezierCurveTo(170, y + (Math.random()-0.5)*10, 340, y + (Math.random()-0.5)*10, 512, y + (Math.random()-0.5)*10);
      ctx.stroke();
    }
    const t = new THREE.CanvasTexture(c);
    t.wrapS = THREE.RepeatWrapping; t.repeat.set(2, 1);
    return t;
  }, []);

  // Half-disc semicircle approximated with a wide cylinder slice
  // (We just use a full ellipse for simplicity — visually it reads as a card-table)

  return (
    <group position={position}>
      {/* TABLE TOP */}
      <mesh receiveShadow position={[0, 0, 0]} scale={[1.4, 1, 1]}>
        <cylinderGeometry args={[2.6, 2.6, 0.18, 64]} />
        <meshStandardMaterial map={woodMap} color="#2A0E08" metalness={0.15} roughness={0.55} />
      </mesh>

      {/* FELT INSET */}
      <mesh receiveShadow position={[0, 0.095, 0]} scale={[1.4, 1, 1]} rotation={[-Math.PI / 2, 0, Math.PI / 2]}>
        <circleGeometry args={[2.35, 64]} />
        <meshStandardMaterial map={feltMap} color="#2A5A40" roughness={1.0} metalness={0.0} />
      </mesh>

      {/* BRASS RIM (outer) */}
      <mesh position={[0, 0.1, 0]} scale={[1.4, 1, 1]}>
        <torusGeometry args={[2.6, 0.05, 16, 96]} />
        <meshStandardMaterial color="#7A5C18" metalness={1} roughness={0.35} />
      </mesh>
      <mesh position={[0, 0.1, 0]} scale={[1.4, 1, 1]}>
        <torusGeometry args={[2.45, 0.04, 16, 96]} />
        <meshStandardMaterial color="#C8A24A" metalness={1} roughness={0.18} />
      </mesh>

      {/* LEATHER ARMREST (player side ~front) */}
      <mesh position={[0, 0.05, 0]} scale={[1.4, 1, 1]} receiveShadow>
        <torusGeometry args={[2.55, 0.1, 24, 96]} />
        <meshStandardMaterial color="#1A0E0A" metalness={0.0} roughness={0.85} />
      </mesh>

      {/* Brass studs around rim */}
      {Array.from({ length: 24 }).map((_, i) => {
        const a = (i / 24) * Math.PI * 2;
        return (
          <mesh
            key={i}
            position={[Math.cos(a) * 3.6, 0.1, Math.sin(a) * 2.55]}
            scale={[1, 1, 1]}
          >
            <sphereGeometry args={[0.04, 8, 8]} />
            <meshStandardMaterial color="#F4D78A" metalness={1} roughness={0.18} />
          </mesh>
        );
      })}

      {/* TABLE LEGS */}
      {[
        [-2.8, -1.15, -1.6],
        [ 2.8, -1.15, -1.6],
        [-2.8, -1.15,  1.6],
        [ 2.8, -1.15,  1.6],
      ].map((p, i) => (
        <mesh key={i} position={p} castShadow>
          <cylinderGeometry args={[0.12, 0.18, 2.4, 16]} />
          <meshStandardMaterial color="#1A0604" metalness={0.2} roughness={0.6} />
        </mesh>
      ))}

      {/* CHIP TRAY in front of dealer */}
      <mesh position={[0, 0.13, -1.6]} castShadow>
        <boxGeometry args={[1.4, 0.05, 0.18]} />
        <meshStandardMaterial color="#C8A24A" metalness={1} roughness={0.2} />
      </mesh>
      {[-0.5, -0.25, 0, 0.25, 0.5].map((dx, i) => (
        <mesh key={i} position={[dx, 0.18, -1.6]} castShadow>
          <cylinderGeometry args={[0.06, 0.06, 0.06, 16]} />
          <meshStandardMaterial color="#0A0608" metalness={0.3} roughness={0.55} />
        </mesh>
      ))}
    </group>
  );
}
