import { D, mul } from '@/services/money';

/* ---------------- Deck ---------------- */

const SUITS = ['♠', '♥', '♦', '♣'];
const RANKS = ['A','2','3','4','5','6','7','8','9','10','J','Q','K'];

export function freshDeck(decks = 6) {
  const d = [];
  for (let n = 0; n < decks; n++) {
    for (const s of SUITS) for (const r of RANKS) d.push({ rank: r, suit: s });
  }
  return d;
}

export function shuffle(deck) {
  const a = deck.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/* ---------------- Hand value (soft / hard) ---------------- */

export function value(hand) {
  let total = 0, aces = 0;
  for (const c of hand) {
    if (c.rank === 'A') { total += 11; aces++; }
    else if (['J','Q','K'].includes(c.rank)) total += 10;
    else total += parseInt(c.rank, 10);
  }
  while (total > 21 && aces > 0) { total -= 10; aces--; }
  return total;
}

export const isBlackjack = (hand) => hand.length === 2 && value(hand) === 21;
export const isBust      = (hand) => value(hand) > 21;

/* ---------------- Dealer plays automatically ---------------- */

export function dealerPlay(deck, dealerHand) {
  const d = deck.slice();
  const h = dealerHand.slice();
  while (value(h) < 17) {
    h.push(d.shift());
  }
  return { deck: d, dealer: h };
}

/* ---------------- Settle ---------------- */

/**
 * Returns { outcome, payout } where payout is a Decimal-string of the
 * GROSS amount returned to the player (0 for loss).
 *
 * Payout rules (V0.1, classic table):
 *   - Player Blackjack vs non-BJ dealer:  3:2 on stake (i.e. 2.5× back)
 *   - Player wins (non-BJ):               1:1 on stake (i.e. 2× back)
 *   - Push:                               return stake (1× back)
 *   - Loss:                               0
 */
export function settle(stake, playerHand, dealerHand) {
  const s = D(stake);
  const pv = value(playerHand), dv = value(dealerHand);
  const pBJ = isBlackjack(playerHand);
  const dBJ = isBlackjack(dealerHand);

  if (isBust(playerHand)) return { outcome: 'LOSS', payout: '0' };
  if (pBJ && !dBJ)        return { outcome: 'WIN',  payout: mul(s, '2.5').toFixed() };
  if (dBJ && !pBJ)        return { outcome: 'LOSS', payout: '0' };
  if (pBJ && dBJ)         return { outcome: 'PUSH', payout: s.toFixed() };
  if (isBust(dealerHand)) return { outcome: 'WIN',  payout: mul(s, '2').toFixed() };
  if (pv > dv)            return { outcome: 'WIN',  payout: mul(s, '2').toFixed() };
  if (pv < dv)            return { outcome: 'LOSS', payout: '0' };
  return { outcome: 'PUSH', payout: s.toFixed() };
}

/* ---------------- Pretty display ---------------- */

export const cardLabel = (c) => `${c.rank}${c.suit}`;
export const suitColor = (c) => (c.suit === '♥' || c.suit === '♦') ? '#7A0E14' : '#0A0608';
