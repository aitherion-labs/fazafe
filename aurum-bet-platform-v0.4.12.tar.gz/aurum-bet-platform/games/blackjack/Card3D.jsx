'use client';

import { useMemo } from 'react';
import * as THREE from 'three';
import { suitColor } from './engine';

/**
 * 3D Card — a flat box with face/back textures generated procedurally.
 * faceUp: false renders the back design; true renders the rank+suit.
 */
export default function Card3D({
  card,
  position = [0, 0, 0],
  rotation = [0, 0, 0],
  faceUp   = true,
  scale    = 1,
}) {
  const { faceTex, backTex } = useMemo(() => {
    if (typeof document === 'undefined') return { faceTex: null, backTex: null };

    // ---- FACE ----
    const fc = document.createElement('canvas');
    fc.width = 256; fc.height = 384;
    const fctx = fc.getContext('2d');
    // ivory base with grain
    const grad = fctx.createLinearGradient(0, 0, 0, 384);
    grad.addColorStop(0, '#FAF3E0');
    grad.addColorStop(1, '#E8DCB8');
    fctx.fillStyle = grad;
    fctx.fillRect(0, 0, 256, 384);
    for (let i = 0; i < 800; i++) {
      fctx.fillStyle = `rgba(120, 90, 40, ${Math.random() * 0.05})`;
      fctx.fillRect(Math.random() * 256, Math.random() * 384, 1, 1);
    }
    // gold inner border
    fctx.strokeStyle = '#7A5C18';
    fctx.lineWidth = 2;
    fctx.strokeRect(8, 8, 240, 368);

    const col = card ? suitColor(card) : '#0A0608';

    if (card) {
      fctx.fillStyle = col;
      fctx.font = '600 56px "Cormorant Garamond", serif';
      fctx.textAlign = 'left';
      fctx.fillText(card.rank, 22, 70);
      fctx.font = '64px serif';
      fctx.fillText(card.suit, 22, 130);
      // center suit
      fctx.font = '180px serif';
      fctx.textAlign = 'center';
      fctx.fillText(card.suit, 128, 240);
      // bottom-right rotated
      fctx.save();
      fctx.translate(234, 314);
      fctx.rotate(Math.PI);
      fctx.font = '600 56px "Cormorant Garamond", serif';
      fctx.textAlign = 'left';
      fctx.fillText(card.rank, 0, 0);
      fctx.font = '64px serif';
      fctx.fillText(card.suit, 0, 60);
      fctx.restore();
    }

    const faceTex = new THREE.CanvasTexture(fc);
    faceTex.anisotropy = 8;

    // ---- BACK ----
    const bc = document.createElement('canvas');
    bc.width = 256; bc.height = 384;
    const bctx = bc.getContext('2d');
    const bg = bctx.createLinearGradient(0, 0, 256, 384);
    bg.addColorStop(0, '#2A0E08');
    bg.addColorStop(1, '#0A0408');
    bctx.fillStyle = bg;
    bctx.fillRect(0, 0, 256, 384);
    // gold ornamental pattern
    bctx.strokeStyle = '#C8A24A';
    bctx.lineWidth = 1.2;
    for (let y = 16; y < 384; y += 24) {
      for (let x = 16; x < 256; x += 24) {
        bctx.beginPath();
        bctx.arc(x, y, 8, 0, Math.PI * 2);
        bctx.stroke();
      }
    }
    // central monogram
    bctx.fillStyle = '#F4D78A';
    bctx.strokeStyle = '#7A5C18';
    bctx.lineWidth = 2;
    bctx.font = 'italic 600 110px "Cormorant Garamond", serif';
    bctx.textAlign = 'center';
    bctx.textBaseline = 'middle';
    bctx.fillText('A', 128, 192);
    bctx.strokeRect(20, 20, 216, 344);

    const backTex = new THREE.CanvasTexture(bc);
    backTex.anisotropy = 8;

    return { faceTex, backTex };
  }, [card]);

  const W = 0.9 * scale;
  const H = 1.35 * scale;
  const D = 0.012 * scale;

  return (
    <group position={position} rotation={rotation}>
      {/* face (positive Z) */}
      <mesh position={[0, 0, D / 2]} castShadow>
        <planeGeometry args={[W, H]} />
        <meshStandardMaterial
          map={faceUp ? faceTex : backTex}
          roughness={0.35}
          metalness={0.05}
        />
      </mesh>
      {/* back (negative Z) */}
      <mesh position={[0, 0, -D / 2]} rotation={[0, Math.PI, 0]} castShadow>
        <planeGeometry args={[W, H]} />
        <meshStandardMaterial
          map={faceUp ? backTex : faceTex}
          roughness={0.35}
          metalness={0.05}
        />
      </mesh>
      {/* edges (thin gold strip) */}
      <mesh position={[0, 0, 0]}>
        <boxGeometry args={[W * 0.99, H * 0.99, D]} />
        <meshStandardMaterial color="#F4D78A" metalness={0.7} roughness={0.4} />
      </mesh>
    </group>
  );
}
