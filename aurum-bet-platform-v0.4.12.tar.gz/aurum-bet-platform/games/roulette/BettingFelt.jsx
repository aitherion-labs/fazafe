'use client';

import { useMemo, useState } from 'react';
import {
  BET_TYPE, BET_LABEL, PAYOUT_MULT,
  REDS, isRed, isZero, betId, coversNumbers,
} from './engine';

/**
 * AURUM ROULETTE BETTING FELT — V0.3
 *
 * Interactive SVG felt that supports every standard European roulette
 * bet. Each click zone is a discrete element, so the chip lands exactly
 * where a real-world table would have it:
 *   - center of cell  → straight
 *   - cell border     → split
 *   - row outer edge  → street
 *   - 4-corner inter. → corner
 *   - street-pair edge → six-line
 *   - dozen cell      → dozen
 *   - 2:1 right cells → column
 *   - bottom row      → outside even-money bets
 *
 * Visually the chips stack with a slight vertical offset so the player
 * can see how many chips are on each spot.
 *
 * Props:
 *   bets:       { [betId]: { type, numbers, amount, label } }   (controlled)
 *   chipValue:  number   the value of the chip being placed
 *   onPlace:    (zone)=>void   called with the zone the user clicked
 *   highlight:  number|null    result number to highlight after spin
 *   disabled:   boolean        no interaction during spin
 */

const CELL_W   = 46;
const CELL_H   = 56;
const Z_W      = 46;
const PAD_X    = 16;
const PAD_Y    = 16;
const NUM_X    = PAD_X + Z_W;
const COL_X    = NUM_X + 12 * CELL_W;
const NUM_BOT  = PAD_Y + 3 * CELL_H;
const DOZ_H    = 36;
const OUT_H    = 36;
const DOZ_Y    = NUM_BOT;
const OUT_Y    = DOZ_Y + DOZ_H;
const TOTAL_W  = COL_X + 46 + PAD_X;
const TOTAL_H  = OUT_Y + OUT_H + PAD_Y;

const RED_FILL   = '#7A0E14';
const BLACK_FILL = '#0A0608';
const GREEN_FILL = '#1F4D3A';
const FELT_FILL  = '#0E2218';  // deep casino green
const GOLD       = '#C8A24A';
const GOLD_HI    = '#F4D78A';

/**
 * Compute display position for any number cell.
 * Display rows top→bottom: row 0 = numbers % 3 === 0 (top), row 1 = 2 (mid),
 * row 2 = 1 (bot). For each col (0..11), the 3 numbers are col*3+1..col*3+3.
 */
function cellOf(n) {
  if (n === 0) return { x: PAD_X, y: PAD_Y, w: Z_W, h: 3 * CELL_H };
  const col = Math.floor((n - 1) / 3);
  const offsetInCol = (n - 1) % 3;            // 0=bottom (1,4,7..), 2=top (3,6,9..)
  const displayRow = 2 - offsetInCol;
  return {
    x: NUM_X + col * CELL_W,
    y: PAD_Y + displayRow * CELL_H,
    w: CELL_W, h: CELL_H,
  };
}

function numberColor(n) {
  if (n === 0) return GREEN_FILL;
  return isRed(n) ? RED_FILL : BLACK_FILL;
}

/* ----------------------------------------------------------------
   Pre-compute all bet zones
   ---------------------------------------------------------------- */

function buildZones() {
  const zones = [];

  // 1. Straight bets (37) — center of each number cell
  for (let n = 0; n <= 36; n++) {
    const c = cellOf(n);
    zones.push({
      id: betId(BET_TYPE.STRAIGHT, n),
      type: BET_TYPE.STRAIGHT,
      numbers: [n],
      cx: c.x + c.w / 2,
      cy: c.y + c.h / 2,
      hitW: c.w * 0.55,
      hitH: c.h * 0.55,
      label: `${n}`,
    });
  }

  // 2. Horizontal splits (between two display rows, same column) — 12 cols × 2 borders = 24
  for (let col = 0; col < 12; col++) {
    for (let row = 0; row < 2; row++) {
      const nTop = col * 3 + (3 - row);
      const nBot = col * 3 + (3 - (row + 1));
      const x    = NUM_X + col * CELL_W + CELL_W / 2;
      const y    = PAD_Y + (row + 1) * CELL_H;
      zones.push({
        id: betId(BET_TYPE.SPLIT, ...[nTop, nBot].sort((a, b) => a - b)),
        type: BET_TYPE.SPLIT,
        numbers: [nTop, nBot].sort((a, b) => a - b),
        cx: x, cy: y,
        hitW: CELL_W * 0.6, hitH: 14,
        label: `Split ${Math.min(nTop, nBot)}/${Math.max(nTop, nBot)}`,
      });
    }
  }

  // 3. Vertical splits (between same display row, adjacent columns) — 11 × 3 = 33
  for (let row = 0; row < 3; row++) {
    for (let col = 0; col < 11; col++) {
      const nL = col       * 3 + (3 - row);
      const nR = (col + 1) * 3 + (3 - row);
      const x  = NUM_X + (col + 1) * CELL_W;
      const y  = PAD_Y + row * CELL_H + CELL_H / 2;
      zones.push({
        id: betId(BET_TYPE.SPLIT, ...[nL, nR].sort((a, b) => a - b)),
        type: BET_TYPE.SPLIT,
        numbers: [nL, nR].sort((a, b) => a - b),
        cx: x, cy: y,
        hitW: 14, hitH: CELL_H * 0.6,
        label: `Split ${Math.min(nL, nR)}/${Math.max(nL, nR)}`,
      });
    }
  }

  // 4. Streets — bottom edge of each display column (12)
  for (let col = 0; col < 12; col++) {
    const nums = [col * 3 + 1, col * 3 + 2, col * 3 + 3];
    zones.push({
      id: betId(BET_TYPE.STREET, nums[0]),
      type: BET_TYPE.STREET,
      numbers: nums,
      cx: NUM_X + col * CELL_W + CELL_W / 2,
      cy: NUM_BOT,
      hitW: CELL_W * 0.7, hitH: 14,
      label: `Street ${nums[0]}–${nums[2]}`,
    });
  }

  // 5. Corners — 22 intersections inside the number grid (11 × 2)
  for (let col = 0; col < 11; col++) {
    for (let row = 0; row < 2; row++) {
      const ntl = col       * 3 + (3 - row);
      const ntr = (col + 1) * 3 + (3 - row);
      const nbl = col       * 3 + (3 - (row + 1));
      const nbr = (col + 1) * 3 + (3 - (row + 1));
      const nums = [ntl, ntr, nbl, nbr].sort((a, b) => a - b);
      zones.push({
        id: betId(BET_TYPE.CORNER, ...nums),
        type: BET_TYPE.CORNER,
        numbers: nums,
        cx: NUM_X + (col + 1) * CELL_W,
        cy: PAD_Y + (row + 1) * CELL_H,
        hitW: 16, hitH: 16,
        label: `Corner ${nums.join('/')}`,
      });
    }
  }

  // 6. Six-lines — edge between two adjacent streets (11)
  for (let col = 0; col < 11; col++) {
    const nums = [];
    for (let n = col * 3 + 1; n <= (col + 2) * 3; n++) nums.push(n);
    zones.push({
      id: betId(BET_TYPE.SIXLINE, nums[0]),
      type: BET_TYPE.SIXLINE,
      numbers: nums,
      cx: NUM_X + (col + 1) * CELL_W,
      cy: NUM_BOT,
      hitW: 18, hitH: 18,
      label: `Six-line ${nums[0]}–${nums[5]}`,
    });
  }

  // 7. Dozens — 3 cells of width 4*CELL_W each
  for (let d = 1; d <= 3; d++) {
    const nums = coversNumbers(BET_TYPE.DOZEN, d);
    zones.push({
      id: betId(BET_TYPE.DOZEN, d),
      type: BET_TYPE.DOZEN,
      numbers: nums,
      cx: NUM_X + (d - 1) * 4 * CELL_W + 2 * CELL_W,
      cy: DOZ_Y + DOZ_H / 2,
      hitW: 4 * CELL_W - 4, hitH: DOZ_H - 4,
      label: ['1st 12', '2nd 12', '3rd 12'][d - 1],
      fullCell: true,
    });
  }

  // 8. Columns (2:1) — 3 cells on the right
  const COL_LABELS = ['2 to 1', '2 to 1', '2 to 1'];
  for (let displayRow = 0; displayRow < 3; displayRow++) {
    const colId = displayRow === 0 ? 3 : displayRow === 1 ? 2 : 1;
    const nums  = coversNumbers(BET_TYPE.COLUMN, colId);
    zones.push({
      id: betId(BET_TYPE.COLUMN, colId),
      type: BET_TYPE.COLUMN,
      numbers: nums,
      cx: COL_X + 23,
      cy: PAD_Y + displayRow * CELL_H + CELL_H / 2,
      hitW: 42, hitH: CELL_H - 4,
      label: `Column ${colId} (2:1)`,
      fullCell: true,
    });
  }

  // 9. Outside even-money bets — 6 cells on bottom row
  const OUT = [
    { type: BET_TYPE.LOW,   label: '1–18' },
    { type: BET_TYPE.EVEN,  label: 'EVEN' },
    { type: BET_TYPE.RED,   label: '♦ RED' },
    { type: BET_TYPE.BLACK, label: '♠ BLACK' },
    { type: BET_TYPE.ODD,   label: 'ODD' },
    { type: BET_TYPE.HIGH,  label: '19–36' },
  ];
  const OUT_W = (12 * CELL_W) / 6;
  for (let i = 0; i < OUT.length; i++) {
    zones.push({
      id: betId(OUT[i].type),
      type: OUT[i].type,
      numbers: coversNumbers(OUT[i].type),
      cx: NUM_X + i * OUT_W + OUT_W / 2,
      cy: OUT_Y + OUT_H / 2,
      hitW: OUT_W - 4, hitH: OUT_H - 4,
      label: OUT[i].label,
      fullCell: true,
    });
  }

  return zones;
}

const ZONES = buildZones();
const ZONE_BY_ID = Object.fromEntries(ZONES.map((z) => [z.id, z]));

/* ----------------------------------------------------------------
   Visual chip stack
   ---------------------------------------------------------------- */

function ChipStack({ x, y, amount, count, accent = GOLD_HI }) {
  // Render 1-4 chips stacked vertically; if larger amount, show count badge
  const stack = Math.min(Math.max(1, Math.round(count)), 4);
  return (
    <g transform={`translate(${x},${y})`} style={{ pointerEvents: 'none' }}>
      {Array.from({ length: stack }).map((_, i) => (
        <g key={i} transform={`translate(0,${-i * 2.2})`}>
          <ellipse cx="0" cy="0" rx="10" ry="3" fill="rgba(0,0,0,0.45)" />
          <circle  cx="0" cy="-1.2" r="8.5"
                   fill={accent} stroke="#0A0608" strokeWidth="1.4"
                   style={{ filter: 'drop-shadow(0 1px 0 rgba(0,0,0,0.5))' }} />
          <circle  cx="0" cy="-1.2" r="5"
                   fill="none" stroke="#0A0608" strokeWidth="0.4"
                   strokeDasharray="1.2 0.8" />
        </g>
      ))}
      <text
        x="0" y={-(stack - 1) * 2.2 - 0.4}
        textAnchor="middle"
        dominantBaseline="central"
        fontSize="7.5"
        fontWeight="700"
        fontFamily="Inter Tight, system-ui, sans-serif"
        fill="#0A0608"
        style={{ pointerEvents: 'none' }}
      >
        ${amount}
      </text>
    </g>
  );
}

/* ----------------------------------------------------------------
   Main component
   ---------------------------------------------------------------- */

export default function BettingFelt({
  bets = {},
  chipValue = 10,
  onPlace,
  highlight = null,
  disabled = false,
}) {
  const [hoverId, setHoverId] = useState(null);

  const handleZoneClick = (zone) => {
    if (disabled) return;
    onPlace?.(zone);
  };

  const tooltipZone = hoverId ? ZONE_BY_ID[hoverId] : null;

  return (
    <div className="relative" style={{ width: '100%', maxWidth: TOTAL_W + 8 }}>
      <svg
        viewBox={`0 0 ${TOTAL_W} ${TOTAL_H}`}
        xmlns="http://www.w3.org/2000/svg"
        style={{
          width: '100%',
          height: 'auto',
          display: 'block',
          filter: 'drop-shadow(0 8px 20px rgba(0,0,0,0.6))',
          userSelect: 'none',
        }}
      >
        {/* Felt background */}
        <defs>
          <radialGradient id="felt" cx="50%" cy="40%" r="70%">
            <stop offset="0%"  stopColor="#163A28" />
            <stop offset="100%" stopColor="#08160F" />
          </radialGradient>
          <linearGradient id="goldBorder" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%"   stopColor={GOLD_HI} />
            <stop offset="50%"  stopColor={GOLD} />
            <stop offset="100%" stopColor="#7A5C18" />
          </linearGradient>
        </defs>

        <rect
          x="2" y="2" width={TOTAL_W - 4} height={TOTAL_H - 4}
          rx="6" ry="6"
          fill="url(#felt)"
          stroke="url(#goldBorder)"
          strokeWidth="2"
        />

        {/* ZERO cell */}
        <g
          onMouseEnter={() => setHoverId(betId(BET_TYPE.STRAIGHT, 0))}
          onMouseLeave={() => setHoverId(null)}
          onClick={() => handleZoneClick(ZONE_BY_ID[betId(BET_TYPE.STRAIGHT, 0)])}
          style={{ cursor: disabled ? 'default' : 'pointer' }}
        >
          <rect
            x={PAD_X} y={PAD_Y}
            width={Z_W} height={3 * CELL_H}
            rx="3" ry="3"
            fill={GREEN_FILL}
            stroke={GOLD}
            strokeWidth="0.6"
          />
          <text
            x={PAD_X + Z_W / 2}
            y={PAD_Y + 1.5 * CELL_H}
            textAnchor="middle"
            dominantBaseline="central"
            fontSize="34"
            fontFamily="Cormorant Garamond, serif"
            fontWeight="600"
            fill={GOLD_HI}
          >
            0
          </text>
          {highlight === 0 && (
            <rect
              x={PAD_X - 1} y={PAD_Y - 1}
              width={Z_W + 2} height={3 * CELL_H + 2}
              rx="4" ry="4"
              fill="none" stroke={GOLD_HI} strokeWidth="2.5"
              style={{ filter: 'drop-shadow(0 0 10px #F4D78A)' }}
            />
          )}
        </g>

        {/* Number cells (1-36) */}
        {Array.from({ length: 36 }, (_, i) => i + 1).map((n) => {
          const c = cellOf(n);
          const isHit = highlight === n;
          return (
            <g
              key={n}
              onMouseEnter={() => setHoverId(betId(BET_TYPE.STRAIGHT, n))}
              onMouseLeave={() => setHoverId(null)}
              onClick={() => handleZoneClick(ZONE_BY_ID[betId(BET_TYPE.STRAIGHT, n)])}
              style={{ cursor: disabled ? 'default' : 'pointer' }}
            >
              <rect
                x={c.x + 0.5} y={c.y + 0.5}
                width={c.w - 1} height={c.h - 1}
                fill={numberColor(n)}
                stroke={GOLD}
                strokeWidth="0.5"
              />
              <text
                x={c.x + c.w / 2}
                y={c.y + c.h / 2}
                textAnchor="middle"
                dominantBaseline="central"
                fontSize="20"
                fontFamily="Cormorant Garamond, serif"
                fontWeight="600"
                fill={GOLD_HI}
                style={{ pointerEvents: 'none' }}
              >
                {n}
              </text>
              {isHit && (
                <rect
                  x={c.x - 1} y={c.y - 1}
                  width={c.w + 2} height={c.h + 2}
                  rx="2" ry="2"
                  fill="none" stroke={GOLD_HI} strokeWidth="2.5"
                  style={{ filter: 'drop-shadow(0 0 8px #F4D78A)' }}
                />
              )}
            </g>
          );
        })}

        {/* Dozens row */}
        {[1, 2, 3].map((d) => {
          const x = NUM_X + (d - 1) * 4 * CELL_W;
          const w = 4 * CELL_W;
          const z = ZONE_BY_ID[betId(BET_TYPE.DOZEN, d)];
          return (
            <g
              key={`doz-${d}`}
              onMouseEnter={() => setHoverId(z.id)}
              onMouseLeave={() => setHoverId(null)}
              onClick={() => handleZoneClick(z)}
              style={{ cursor: disabled ? 'default' : 'pointer' }}
            >
              <rect
                x={x + 0.5} y={DOZ_Y + 0.5}
                width={w - 1} height={DOZ_H - 1}
                fill="#0E2218" stroke={GOLD} strokeWidth="0.5"
              />
              <text
                x={x + w / 2}
                y={DOZ_Y + DOZ_H / 2}
                textAnchor="middle"
                dominantBaseline="central"
                fontSize="14"
                fontFamily="Cormorant Garamond, serif"
                fontWeight="500"
                fill={GOLD_HI}
                letterSpacing="2"
                style={{ pointerEvents: 'none' }}
              >
                {['1ST 12', '2ND 12', '3RD 12'][d - 1]}
              </text>
            </g>
          );
        })}

        {/* Column 2:1 */}
        {[0, 1, 2].map((displayRow) => {
          const colId = displayRow === 0 ? 3 : displayRow === 1 ? 2 : 1;
          const z = ZONE_BY_ID[betId(BET_TYPE.COLUMN, colId)];
          return (
            <g
              key={`col-${displayRow}`}
              onMouseEnter={() => setHoverId(z.id)}
              onMouseLeave={() => setHoverId(null)}
              onClick={() => handleZoneClick(z)}
              style={{ cursor: disabled ? 'default' : 'pointer' }}
            >
              <rect
                x={COL_X + 0.5} y={PAD_Y + displayRow * CELL_H + 0.5}
                width={45} height={CELL_H - 1}
                fill="#0E2218" stroke={GOLD} strokeWidth="0.5"
              />
              <text
                x={COL_X + 23}
                y={PAD_Y + displayRow * CELL_H + CELL_H / 2}
                textAnchor="middle"
                dominantBaseline="central"
                fontSize="11"
                fontFamily="Cormorant Garamond, serif"
                fontWeight="500"
                fill={GOLD_HI}
                letterSpacing="1.5"
                style={{ pointerEvents: 'none' }}
              >
                2 to 1
              </text>
            </g>
          );
        })}

        {/* Outside even-money row */}
        {(() => {
          const OUT = [
            { type: BET_TYPE.LOW,   label: '1–18',     fill: '#0E2218' },
            { type: BET_TYPE.EVEN,  label: 'EVEN',     fill: '#0E2218' },
            { type: BET_TYPE.RED,   label: '◆',        fill: RED_FILL },
            { type: BET_TYPE.BLACK, label: '◆',        fill: BLACK_FILL },
            { type: BET_TYPE.ODD,   label: 'ODD',      fill: '#0E2218' },
            { type: BET_TYPE.HIGH,  label: '19–36',    fill: '#0E2218' },
          ];
          const OUT_W = (12 * CELL_W) / 6;
          return OUT.map((b, i) => {
            const z = ZONE_BY_ID[betId(b.type)];
            return (
              <g
                key={`out-${b.type}`}
                onMouseEnter={() => setHoverId(z.id)}
                onMouseLeave={() => setHoverId(null)}
                onClick={() => handleZoneClick(z)}
                style={{ cursor: disabled ? 'default' : 'pointer' }}
              >
                <rect
                  x={NUM_X + i * OUT_W + 0.5}
                  y={OUT_Y + 0.5}
                  width={OUT_W - 1} height={OUT_H - 1}
                  fill={b.fill}
                  stroke={GOLD} strokeWidth="0.5"
                />
                <text
                  x={NUM_X + i * OUT_W + OUT_W / 2}
                  y={OUT_Y + OUT_H / 2}
                  textAnchor="middle"
                  dominantBaseline="central"
                  fontSize={b.label === '◆' ? '22' : '13'}
                  fontFamily="Cormorant Garamond, serif"
                  fontWeight="500"
                  fill={GOLD_HI}
                  letterSpacing="2"
                  style={{ pointerEvents: 'none' }}
                >
                  {b.label}
                </text>
              </g>
            );
          });
        })()}

        {/* Split / corner / street / six-line invisible hit zones */}
        {ZONES
          .filter((z) =>
            z.type === BET_TYPE.SPLIT ||
            z.type === BET_TYPE.STREET ||
            z.type === BET_TYPE.CORNER ||
            z.type === BET_TYPE.SIXLINE
          )
          .map((z) => (
            <g
              key={`hit-${z.id}`}
              onMouseEnter={() => setHoverId(z.id)}
              onMouseLeave={() => setHoverId(null)}
              onClick={() => handleZoneClick(z)}
              style={{ cursor: disabled ? 'default' : 'pointer' }}
            >
              <rect
                x={z.cx - z.hitW / 2}
                y={z.cy - z.hitH / 2}
                width={z.hitW} height={z.hitH}
                fill={hoverId === z.id ? 'rgba(244,215,138,0.18)' : 'transparent'}
                stroke={hoverId === z.id ? GOLD_HI : 'transparent'}
                strokeWidth="1"
                strokeDasharray="2 2"
              />
            </g>
          ))}

        {/* Chip stacks at each occupied bet position */}
        {Object.entries(bets).map(([id, b]) => {
          const z = ZONE_BY_ID[id];
          if (!z) return null;
          const amount = parseFloat(b.amount);
          const count  = b.chipCount || 1;
          return <ChipStack key={id} x={z.cx} y={z.cy} amount={amount} count={count} />;
        })}
      </svg>

      {/* Tooltip */}
      {tooltipZone && !disabled && (
        <div
          className="absolute top-2 left-1/2 -translate-x-1/2 px-3 py-1.5 rounded-sm
                     text-[10px] tracking-[0.18em] uppercase
                     bg-black/85 text-aurum-goldHi border border-aurum-gold/40
                     pointer-events-none font-mono"
        >
          {tooltipZone.label}
          <span className="ml-2 text-aurum-ivory/55">
            · pays {PAYOUT_MULT[tooltipZone.type] - 1}:1
          </span>
        </div>
      )}
    </div>
  );
}
