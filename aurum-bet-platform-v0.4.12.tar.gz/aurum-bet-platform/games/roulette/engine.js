import { D, mul } from '@/services/money';

/**
 * AURUM ROULETTE ENGINE — V0.3
 *
 * European single-zero roulette (37 pockets: 0..36).
 * Full bet coverage matching a real felt:
 *   - Inside:  straight, split, street, corner, six-line (line)
 *   - Outside: dozen, column, red/black, even/odd, low/high
 *
 * Payouts are expressed as the GROSS multiplier on the stake
 * (stake-back + win combined), so settle() returns the full amount
 * to return to the player's available balance on a winning bet.
 *
 *   Straight 35:1 → multiplier 36
 *   Split    17:1 → multiplier 18
 *   Street   11:1 → multiplier 12
 *   Corner    8:1 → multiplier  9
 *   Six-line  5:1 → multiplier  6
 *   Dozen     2:1 → multiplier  3
 *   Column    2:1 → multiplier  3
 *   Red/Black 1:1 → multiplier  2
 *   Even/Odd  1:1 → multiplier  2
 *   Low/High  1:1 → multiplier  2
 *
 * Zero loses ALL outside even-money bets (no la-partage rule in V0.3).
 */

export const POCKETS = [
  0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 10,
  5, 24, 16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26,
];

export const REDS = new Set(
  [1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36]
);

export const isRed   = (n) => REDS.has(n);
export const isBlack = (n) => n !== 0 && !REDS.has(n);
export const isZero  = (n) => n === 0;
export const colorOf = (n) => isZero(n) ? 'GREEN' : isRed(n) ? 'RED' : 'BLACK';

/* ----------------------------------------------------------------
   Bet types
   ---------------------------------------------------------------- */

export const BET_TYPE = {
  STRAIGHT: 'STRAIGHT',   // single number
  SPLIT:    'SPLIT',      // 2 adjacent numbers
  STREET:   'STREET',     // 3 numbers in a row
  CORNER:   'CORNER',     // 4 numbers at a corner
  SIXLINE:  'SIXLINE',    // 6 numbers (two adjacent streets)
  DOZEN:    'DOZEN',      // 1st/2nd/3rd dozen
  COLUMN:   'COLUMN',     // a column (1-2-3 column)
  RED:      'RED',
  BLACK:    'BLACK',
  EVEN:     'EVEN',
  ODD:      'ODD',
  LOW:      'LOW',        // 1-18
  HIGH:     'HIGH',       // 19-36
};

export const PAYOUT_MULT = {
  [BET_TYPE.STRAIGHT]: 36,
  [BET_TYPE.SPLIT]:    18,
  [BET_TYPE.STREET]:   12,
  [BET_TYPE.CORNER]:    9,
  [BET_TYPE.SIXLINE]:   6,
  [BET_TYPE.DOZEN]:     3,
  [BET_TYPE.COLUMN]:    3,
  [BET_TYPE.RED]:       2,
  [BET_TYPE.BLACK]:     2,
  [BET_TYPE.EVEN]:      2,
  [BET_TYPE.ODD]:       2,
  [BET_TYPE.LOW]:       2,
  [BET_TYPE.HIGH]:      2,
};

/* Short human label */
export const BET_LABEL = {
  [BET_TYPE.STRAIGHT]: 'Straight',
  [BET_TYPE.SPLIT]:    'Split',
  [BET_TYPE.STREET]:   'Street',
  [BET_TYPE.CORNER]:   'Corner',
  [BET_TYPE.SIXLINE]:  'Six-Line',
  [BET_TYPE.DOZEN]:    'Dozen',
  [BET_TYPE.COLUMN]:   'Column',
  [BET_TYPE.RED]:      'Red',
  [BET_TYPE.BLACK]:    'Black',
  [BET_TYPE.EVEN]:     'Even',
  [BET_TYPE.ODD]:      'Odd',
  [BET_TYPE.LOW]:      '1–18',
  [BET_TYPE.HIGH]:     '19–36',
};

/* ----------------------------------------------------------------
   Bet shape & coverage helpers
   ---------------------------------------------------------------- */

/**
 * A bet record:
 *   { id: string, type: BET_TYPE, numbers: number[], amount: string }
 *
 * `numbers` is the set covered (so we can resolve quickly), and `id` is
 * a stable string we use as the canvas key for chip stacking on the felt
 * (e.g. "STRAIGHT:17", "SPLIT:14,17", "CORNER:5,6,8,9").
 */

export function coversNumbers(type, ...args) {
  switch (type) {
    case BET_TYPE.STRAIGHT: return [args[0]];
    case BET_TYPE.SPLIT:    return [args[0], args[1]].sort((a,b) => a-b);
    case BET_TYPE.STREET:   return [args[0], args[0]+1, args[0]+2]; // pass row-start
    case BET_TYPE.CORNER:   return [args[0], args[0]+1, args[0]+3, args[0]+4]; // top-left of corner
    case BET_TYPE.SIXLINE:  return [args[0], args[0]+1, args[0]+2, args[0]+3, args[0]+4, args[0]+5];
    case BET_TYPE.DOZEN: {
      const start = (args[0] - 1) * 12 + 1;
      const out = [];
      for (let i = 0; i < 12; i++) out.push(start + i);
      return out;
    }
    case BET_TYPE.COLUMN: {
      // args[0] in {1,2,3} — column 1 = numbers ≡ 1 (mod 3), column 2 ≡ 2, column 3 ≡ 0
      const col = args[0];
      const out = [];
      for (let n = 1; n <= 36; n++) {
        if ((col === 3 && n % 3 === 0) || (col !== 3 && n % 3 === col)) out.push(n);
      }
      return out;
    }
    case BET_TYPE.RED:   return Array.from(REDS);
    case BET_TYPE.BLACK: { const out=[]; for (let n=1;n<=36;n++) if (!REDS.has(n)) out.push(n); return out; }
    case BET_TYPE.EVEN:  { const out=[]; for (let n=2;n<=36;n+=2) out.push(n); return out; }
    case BET_TYPE.ODD:   { const out=[]; for (let n=1;n<=36;n+=2) out.push(n); return out; }
    case BET_TYPE.LOW:   { const out=[]; for (let n=1;n<=18;n++) out.push(n); return out; }
    case BET_TYPE.HIGH:  { const out=[]; for (let n=19;n<=36;n++) out.push(n); return out; }
    default: return [];
  }
}

/* Canonical bet id used for chip-stacking on the same spot */
export function betId(type, ...args) {
  return `${type}:${args.join(',')}`;
}

/* ----------------------------------------------------------------
   Settlement
   ---------------------------------------------------------------- */

/**
 * Settle a single bet against the result number.
 * Returns { won, payout } where payout is a Decimal-string of the GROSS
 * amount returned to the player (0 for a loss).
 */
export function settleBet(bet, result) {
  const won = bet.numbers.includes(result);
  if (!won) return { won: false, payout: '0' };
  const mult = PAYOUT_MULT[bet.type] || 0;
  return { won: true, payout: mul(bet.amount, mult).toFixed() };
}

/**
 * Settle a list of bets (the typical "felt with many chips" case).
 * Returns:
 *   {
 *     winners: Bet[],
 *     losers:  Bet[],
 *     totalStake:  string,
 *     totalPayout: string,
 *     net:         string,     // positive ⇒ player wins
 *     outcome:     'WIN' | 'LOSS' | 'PUSH'
 *   }
 *
 * NOTE: each bet still settles independently — `totalPayout` is the sum
 * of gross payouts (including stake-back on winning bets). Losing bets
 * contribute 0. This is what gets credited back to `available` balance.
 */
export function settleAll(bets, result) {
  let totalStake  = D('0');
  let totalPayout = D('0');
  const winners = [], losers = [];
  for (const b of bets) {
    totalStake = totalStake.plus(D(b.amount));
    const { won, payout } = settleBet(b, result);
    if (won) { winners.push({ ...b, payout }); totalPayout = totalPayout.plus(D(payout)); }
    else     { losers.push(b); }
  }
  const net = totalPayout.minus(totalStake);
  const outcome = net.gt(0) ? 'WIN' : net.lt(0) ? 'LOSS' : 'PUSH';
  return {
    winners, losers,
    totalStake:  totalStake.toFixed(),
    totalPayout: totalPayout.toFixed(),
    net:         net.toFixed(),
    outcome,
  };
}

/**
 * Convenience for outside-only legacy callers. Returns { outcome, payout }
 * with payout being the GROSS for one bet.
 */
export function settle(betType, stake, result) {
  const numbers = coversNumbers(betType);
  const bet = { id: betType, type: betType, numbers, amount: stake };
  const { won, payout } = settleBet(bet, result);
  return { outcome: won ? 'WIN' : 'LOSS', payout };
}

/* ----------------------------------------------------------------
   The wheel
   ---------------------------------------------------------------- */

export function spin(rng = Math.random) {
  return Math.floor(rng() * 37);
}
