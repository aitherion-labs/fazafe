/**
 * AURUM POKER ENGINE — Texas Hold'em (heads-up)
 *
 * Pure functions only. The page (`app/lounge/poker/page.jsx`) is the
 * stateful host that wires this engine into React state, wallet, audit,
 * and animations.
 *
 * Conventions:
 *   Card    = { r: '2'..'A', s: '♠'|'♥'|'♦'|'♣' }
 *   Hand    = 5-card subset of [player_hole(2) + community(0..5)]
 *   Eval    = [rankClass, ...tiebreakers]  — lexicographic comparable
 *
 * The evaluator uses the standard 9+1 hand-rank scale:
 *   0=HIGH_CARD, 1=ONE_PAIR, 2=TWO_PAIR, 3=THREE_OF_A_KIND,
 *   4=STRAIGHT, 5=FLUSH, 6=FULL_HOUSE, 7=FOUR_OF_A_KIND,
 *   8=STRAIGHT_FLUSH, 9=ROYAL_FLUSH
 *
 * It enumerates the C(7,5)=21 sub-hands to find the best 5-card hand
 * from 7 (2 hole + 5 community). At 21 combinations per call, this is
 * fast enough for client-side use; a Monte Carlo equity estimator would
 * need a faster path but we don't need that for AI decisions here.
 */

export const RANKS = ['2','3','4','5','6','7','8','9','T','J','Q','K','A'];
export const SUITS = ['♠','♥','♦','♣'];
export const RANK_VALUE = {
  '2':2,'3':3,'4':4,'5':5,'6':6,'7':7,'8':8,'9':9,
  'T':10,'J':11,'Q':12,'K':13,'A':14,
};

export const HAND_RANK = {
  HIGH_CARD:       0,
  ONE_PAIR:        1,
  TWO_PAIR:        2,
  THREE_OF_A_KIND: 3,
  STRAIGHT:        4,
  FLUSH:           5,
  FULL_HOUSE:      6,
  FOUR_OF_A_KIND:  7,
  STRAIGHT_FLUSH:  8,
  ROYAL_FLUSH:     9,
};

export const HAND_NAME = [
  'High Card', 'One Pair', 'Two Pair', 'Three of a Kind', 'Straight',
  'Flush', 'Full House', 'Four of a Kind', 'Straight Flush', 'Royal Flush',
];

/* ---------- Deck ---------- */

export function freshDeck() {
  return SUITS.flatMap((s) => RANKS.map((r) => ({ r, s })));
}

export function shuffle(deck) {
  const a = [...deck];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

const rv = (c) => RANK_VALUE[c.r];

/* ---------- Hand evaluator ---------- */

/** Evaluate exactly 5 cards. Returns [rankClass, ...tiebreakers]. */
function eval5(cards) {
  const sorted = [...cards].sort((a, b) => rv(b) - rv(a));
  const values = sorted.map(rv);
  const suits  = sorted.map((c) => c.s);

  // Rank occurrence counting, sorted most-frequent then highest
  const counts = new Map();
  for (const v of values) counts.set(v, (counts.get(v) || 0) + 1);
  const groups = Array.from(counts.entries())
    .map(([v, c]) => ({ v, c }))
    .sort((a, b) => b.c - a.c || b.v - a.v);

  const isFlush = suits.every((s) => s === suits[0]);

  // Straight detection
  let isStraight = false;
  let straightHigh = 0;
  const uniq = [...new Set(values)].sort((a, b) => b - a);
  if (uniq.length === 5) {
    if (uniq[0] - uniq[4] === 4) {
      isStraight = true;
      straightHigh = uniq[0];
    }
    // Wheel: A-2-3-4-5 (the "5-high straight")
    else if (uniq[0] === 14 && uniq[1] === 5 && uniq[2] === 4 && uniq[3] === 3 && uniq[4] === 2) {
      isStraight = true;
      straightHigh = 5;
    }
  }

  if (isFlush && isStraight) {
    if (straightHigh === 14) return [HAND_RANK.ROYAL_FLUSH];
    return [HAND_RANK.STRAIGHT_FLUSH, straightHigh];
  }
  if (groups[0].c === 4) {
    return [HAND_RANK.FOUR_OF_A_KIND, groups[0].v, groups[1].v];
  }
  if (groups[0].c === 3 && groups[1].c === 2) {
    return [HAND_RANK.FULL_HOUSE, groups[0].v, groups[1].v];
  }
  if (isFlush) {
    return [HAND_RANK.FLUSH, ...values];
  }
  if (isStraight) {
    return [HAND_RANK.STRAIGHT, straightHigh];
  }
  if (groups[0].c === 3) {
    return [HAND_RANK.THREE_OF_A_KIND, groups[0].v, ...groups.slice(1).map((g) => g.v)];
  }
  if (groups[0].c === 2 && groups[1].c === 2) {
    const hi = Math.max(groups[0].v, groups[1].v);
    const lo = Math.min(groups[0].v, groups[1].v);
    return [HAND_RANK.TWO_PAIR, hi, lo, groups[2].v];
  }
  if (groups[0].c === 2) {
    return [HAND_RANK.ONE_PAIR, groups[0].v, ...groups.slice(1).map((g) => g.v)];
  }
  return [HAND_RANK.HIGH_CARD, ...values];
}

/** Best 5-card hand from 5-7 cards. */
export function evalBest(cards) {
  if (cards.length < 5) return [HAND_RANK.HIGH_CARD, 0];
  if (cards.length === 5) return eval5(cards);

  let best = null;
  let bestCards = null;
  const n = cards.length;
  // C(7,5) = 21, C(6,5) = 6 — small enough for brute force
  for (let a = 0; a < n - 4; a++)
  for (let b = a + 1; b < n - 3; b++)
  for (let c = b + 1; c < n - 2; c++)
  for (let d = c + 1; d < n - 1; d++)
  for (let e = d + 1; e < n; e++) {
    const five = [cards[a], cards[b], cards[c], cards[d], cards[e]];
    const r = eval5(five);
    if (!best || compareEval(r, best) > 0) {
      best = r;
      bestCards = five;
    }
  }
  // Attach the actual 5 cards used (for highlighting on the table)
  best.usedCards = bestCards;
  return best;
}

/** Compare two eval tuples. +1 if a > b, -1 if a < b, 0 if equal. */
export function compareEval(a, b) {
  const max = Math.max(a.length, b.length);
  for (let i = 0; i < max; i++) {
    const av = a[i] ?? 0;
    const bv = b[i] ?? 0;
    if (av > bv) return 1;
    if (av < bv) return -1;
  }
  return 0;
}

export function nameOf(evalTuple) {
  return HAND_NAME[evalTuple[0]] || 'Unknown';
}

/* ---------- AI ---------- */

/**
 * AI decision for heads-up Hold'em.
 *
 * Returns { action: 'fold'|'check'|'call'|'raise', amount?: number }.
 *
 * The AI estimates current hand strength from preflop charts (preflop)
 * or evaluated hand rank (postflop), adds a small random bluff factor,
 * and chooses based on the amount to call vs the pot size.
 *
 * This is a simple AI — sufficient for demo play, not for serious
 * gameplay. It does not bluff convincingly, does not track opponent
 * tendencies, and does not use pot odds rigorously. It's an opponent,
 * not a champion.
 *
 * Inputs:
 *   holeCards    AI's 2 hole cards
 *   community    visible community cards (0, 3, 4, or 5)
 *   currentBet   amount the active bettor has committed this round
 *   myBet        amount the AI has already committed this round
 *   myStack      AI's remaining stack
 *   potSize      total pot before AI's decision
 *   phase        'preflop' | 'flop' | 'turn' | 'river'
 */
export function aiDecision({
  holeCards, community, currentBet, myBet, myStack, potSize, phase,
}) {
  const toCall = Math.max(0, currentBet - myBet);

  // Hand strength: 0 (terrible) to 1 (nuts)
  let strength;
  if (!community || community.length === 0) {
    strength = preflopStrength(holeCards);
  } else {
    const best = evalBest([...holeCards, ...community]);
    strength = postflopStrength(best, community.length);
  }

  // Small bluff factor — AI is not 100% rational
  const bluff = (Math.random() - 0.5) * 0.2;
  const score = Math.max(0, Math.min(1, strength + bluff));

  // No call needed: check or value-bet
  if (toCall === 0) {
    if (score > 0.7) {
      const raise = Math.min(myStack, Math.max(20, Math.round(potSize * 0.6)));
      return { action: 'raise', amount: raise };
    }
    return { action: 'check' };
  }

  // Pot odds: how much of the future pot we'd have to commit
  const newPot = potSize + toCall;
  const callValue = toCall / newPot;

  // Very weak → fold (especially if asked for a lot)
  if (score < 0.25) return { action: 'fold' };
  if (score < 0.4 && toCall > myStack * 0.25) return { action: 'fold' };

  // Strong → raise
  if (score > 0.8) {
    const raise = Math.min(myStack, currentBet * 2 + Math.round(potSize * 0.4));
    if (raise >= currentBet) return { action: 'raise', amount: raise };
    return { action: 'call' };
  }

  // Medium → call if pot odds favorable
  if (score > callValue + 0.1) return { action: 'call' };

  // Marginal — occasional bluff call
  if (Math.random() < 0.3) return { action: 'call' };
  return { action: 'fold' };
}

function preflopStrength(hole) {
  if (!hole || hole.length !== 2) return 0;
  const a = rv(hole[0]);
  const b = rv(hole[1]);
  const high = Math.max(a, b);
  const low  = Math.min(a, b);
  const suited = hole[0].s === hole[1].s;
  const paired = a === b;

  if (paired) {
    if (high >= 10) return 0.95;   // TT-AA
    if (high >= 7)  return 0.75;   // 77-99
    return 0.6;                     // 22-66
  }
  if (high === 14 && low >= 10) return suited ? 0.9  : 0.85;  // AK-AT
  if (high === 13 && low >= 10) return suited ? 0.8  : 0.7;   // KQ-KT
  if (high >= 11  && low >= 10) return suited ? 0.7  : 0.6;   // QJ, QT, JT
  if (suited && high - low === 1 && low >= 7) return 0.55;     // suited connectors 78s-T9s
  if (suited && high >= 12) return 0.5;                        // suited A/K with low kicker
  if (high === 14) return 0.4;                                  // any ace
  return 0.18;
}

function postflopStrength(evalTuple, communityCount) {
  // Map hand rank to base strength, then add small bonus for top-pair quality
  const [cls] = evalTuple;
  switch (cls) {
    case HAND_RANK.ROYAL_FLUSH:
    case HAND_RANK.STRAIGHT_FLUSH:
    case HAND_RANK.FOUR_OF_A_KIND:
      return 1.0;
    case HAND_RANK.FULL_HOUSE: return 0.95;
    case HAND_RANK.FLUSH:      return 0.85;
    case HAND_RANK.STRAIGHT:   return 0.78;
    case HAND_RANK.THREE_OF_A_KIND: return 0.68;
    case HAND_RANK.TWO_PAIR:   return 0.52;
    case HAND_RANK.ONE_PAIR: {
      const pairValue = evalTuple[1] || 0;
      // Pair of As-Ks is much stronger than pair of 2s-3s
      return 0.25 + (pairValue / 14) * 0.15;
    }
    default: return 0.1 + ((evalTuple[1] || 0) / 14) * 0.05;
  }
}

/* =====================================================================
   Monte Carlo equity simulator
   ===================================================================== */

/**
 * Estimate winning equity vs N random opponents by simulating many
 * possible runouts. Deals random hole cards to each opponent, completes
 * the board if needed, then evaluates and counts wins.
 *
 * Computationally cheap (each iteration is ~21 hand-evals × N_opponents
 * worst case), so we can afford 100-300 iterations per AI decision and
 * still respond in <10ms.
 *
 *   myHole       this player's two cards
 *   community    [] (preflop) | 3 cards (flop) | 4 (turn) | 5 (river)
 *   deadCards    cards we know are out of the deck (other folded hands
 *                we've seen; usually empty in this demo)
 *   nOpponents   how many opponents are still in the hand
 *   iterations   Monte Carlo trials (default 150 — good accuracy/speed)
 */
export function simulateEquity(myHole, community, deadCards, nOpponents, iterations = 150) {
  if (nOpponents <= 0) return 1;
  const used = new Set();
  const key = (c) => `${c.r}${c.s}`;
  for (const c of [...myHole, ...community, ...deadCards]) used.add(key(c));
  const remaining = freshDeck().filter((c) => !used.has(key(c)));

  let wins = 0;
  let ties = 0;

  for (let i = 0; i < iterations; i++) {
    // Fisher-Yates partial shuffle of just what we need
    const need = 2 * nOpponents + (5 - community.length);
    const deck = [...remaining];
    for (let k = 0; k < need; k++) {
      const j = k + Math.floor(Math.random() * (deck.length - k));
      [deck[k], deck[j]] = [deck[j], deck[k]];
    }

    let p = 0;
    const opp = [];
    for (let o = 0; o < nOpponents; o++) opp.push([deck[p++], deck[p++]]);
    const board = [...community];
    while (board.length < 5) board.push(deck[p++]);

    const myEval = evalBest([...myHole, ...board]);
    let bestOpp = null;
    for (const oh of opp) {
      const oe = evalBest([...oh, ...board]);
      if (!bestOpp || compareEval(oe, bestOpp) > 0) bestOpp = oe;
    }
    const cmp = compareEval(myEval, bestOpp);
    if (cmp > 0) wins++;
    else if (cmp === 0) ties++;
  }

  return (wins + ties * 0.5) / iterations;
}

/* =====================================================================
   Side pots
   ===================================================================== */

/**
 * Compute side pots for an N-way hand. Each "level" of commitment
 * creates a pot layer that only the players who committed up to that
 * level are eligible to win.
 *
 * Example: A commits 100, B commits 200, C commits 200.
 *   Layer 1: 0→100 → 100 × 3 = 300, eligible: all three (if not folded)
 *   Layer 2: 100→200 → 100 × 2 = 200, eligible: B and C
 *
 * Folded players still contribute (their chips go into the pot), but
 * cannot win any layer.
 *
 *   players: [{ id, committed, folded }]
 *   returns: [{ amount, eligible: [id...] }]
 */
export function computeSidePots(players) {
  const contributors = players.filter((p) => p.committed > 0);
  if (contributors.length === 0) return [];

  const levels = [...new Set(contributors.map((p) => p.committed))].sort((a, b) => a - b);
  const pots = [];
  let prev = 0;

  for (const level of levels) {
    const layerAmount = level - prev;
    const inLayer = contributors.filter((p) => p.committed >= level);
    const potAmount = layerAmount * inLayer.length;
    const eligible = inLayer.filter((p) => !p.folded).map((p) => p.id);
    if (potAmount > 0 && eligible.length > 0) {
      pots.push({ amount: potAmount, eligible });
    } else if (potAmount > 0) {
      // Everyone in this layer folded — the chips still need a home.
      // Add to the previous pot (rare edge case in practice).
      if (pots.length) pots[pots.length - 1].amount += potAmount;
    }
    prev = level;
  }
  return pots;
}

/* =====================================================================
   AI decision V2 — equity-driven
   ===================================================================== */

/**
 * Smarter AI using Monte Carlo equity vs the pot odds being offered.
 *
 * Position-aware (loose in late position, tight in early), stack-aware
 * (won't commit a huge stack on marginal equity), and lightly random
 * to avoid being exploitable.
 *
 * Not a champion. Sufficient for a polished demo.
 *
 *   nOpponents  active opponents (not folded)
 *   position    'early' | 'middle' | 'late'  (affects threshold)
 *   spr         stack-to-pot ratio at this decision
 */
export function aiDecisionV2({
  holeCards, community, currentBet, myBet, myStack, potSize,
  phase, nOpponents = 1, position = 'middle', deadCards = [], minRaise,
}) {
  const toCall = Math.max(0, currentBet - myBet);

  // Estimate equity
  const equity = simulateEquity(holeCards, community || [], deadCards, nOpponents, 120);

  // Pot odds: equity needed to call profitably
  const newPot = potSize + toCall;
  const requiredEquity = toCall === 0 ? 0 : toCall / newPot;

  // Position bonus — willing to play looser in late position
  const posBonus = position === 'late' ? 0.05 : position === 'early' ? -0.05 : 0;
  const adjusted = equity + posBonus;

  // Stack pressure — if calling commits a huge portion of stack, tighten up
  const stackCommit = toCall === 0 ? 0 : toCall / myStack;

  /* ---- No call needed: check or value bet ---- */
  if (toCall === 0) {
    if (adjusted > 0.72) {
      // Strong: bet for value, 50-70% of pot
      const betSize = Math.min(myStack, Math.max(minRaise || 10, Math.round(potSize * (0.55 + Math.random() * 0.2))));
      return { action: 'raise', amount: betSize };
    }
    if (adjusted > 0.5 && Math.random() < 0.35) {
      // Medium: thin value or semi-bluff
      const betSize = Math.min(myStack, Math.max(minRaise || 10, Math.round(potSize * 0.35)));
      return { action: 'raise', amount: betSize };
    }
    return { action: 'check' };
  }

  /* ---- Need to call ---- */
  // Strong: raise
  if (adjusted > 0.78 && stackCommit < 0.5) {
    const raise = Math.min(myStack, Math.max(minRaise || (currentBet + 10), currentBet * 2 + Math.round(potSize * 0.35)));
    if (raise > currentBet) return { action: 'raise', amount: raise };
    return { action: 'call' };
  }
  // Good equity: call
  if (adjusted > requiredEquity + 0.12) return { action: 'call' };
  // Marginal equity but pot odds support: call
  if (adjusted > requiredEquity + 0.04 && stackCommit < 0.4) return { action: 'call' };
  // Bluff catch occasionally
  if (adjusted > requiredEquity - 0.05 && Math.random() < 0.15) return { action: 'call' };
  // Very weak or asking too much
  return { action: 'fold' };
}

/* =====================================================================
   Award pots at showdown
   ===================================================================== */

/**
 * Given the final side pots and each player's hole cards + the
 * community board, evaluate each player's best 5-card hand and award
 * each pot to its eligible winner(s). Splits ties evenly.
 *
 *   sidePots:    [{ amount, eligible: [id...] }]
 *   players:     [{ id, hole, folded }]
 *   community:   [card, card, card, card, card]
 *   returns:     { awards: { [id]: amount }, hands: { [id]: { eval, name, usedCards } } }
 */
export function awardSidePots(sidePots, players, community) {
  const hands = {};
  for (const p of players) {
    if (p.folded) continue;
    const ev = evalBest([...p.hole, ...community]);
    hands[p.id] = { eval: ev, name: nameOf(ev), usedCards: ev.usedCards };
  }

  const awards = {};
  for (const pot of sidePots) {
    const contenders = pot.eligible.filter((id) => hands[id]);
    if (contenders.length === 0) continue;

    // Find best hand among contenders
    let bestId = contenders[0];
    let winners = [bestId];
    for (let i = 1; i < contenders.length; i++) {
      const id = contenders[i];
      const cmp = compareEval(hands[id].eval, hands[bestId].eval);
      if (cmp > 0) {
        bestId = id;
        winners = [id];
      } else if (cmp === 0) {
        winners.push(id);
      }
    }

    // Split pot among ties (integer cents, dust goes to first)
    const share = Math.floor(pot.amount / winners.length);
    const dust  = pot.amount - share * winners.length;
    for (let i = 0; i < winners.length; i++) {
      awards[winners[i]] = (awards[winners[i]] || 0) + share + (i === 0 ? dust : 0);
    }
  }

  return { awards, hands };
}
