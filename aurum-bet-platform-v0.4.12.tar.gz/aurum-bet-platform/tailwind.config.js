/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './app/**/*.{js,jsx,ts,tsx}',
    './components/**/*.{js,jsx,ts,tsx}',
    './scenes/**/*.{js,jsx,ts,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        aurum: {
          black:    '#05040A',
          obsidian: '#0B0A12',
          velvet:   '#15101C',
          ash:      '#1F1A28',
          gold:     '#C8A24A',
          goldHi:   '#F4D78A',
          goldDeep: '#7A5C18',
          ember:    '#E0573B',
          ivory:    '#EDE3CE',
          smoke:    '#7A7383',
        },
      },
      fontFamily: {
        display: ['"Cormorant Garamond"', 'serif'],
        body:    ['"Inter Tight"', 'system-ui', 'sans-serif'],
        mono:    ['"JetBrains Mono"', 'monospace'],
      },
      boxShadow: {
        'gold-glow': '0 0 40px rgba(200, 162, 74, 0.35), 0 0 80px rgba(200, 162, 74, 0.15)',
        'velvet':    '0 30px 80px -20px rgba(0,0,0,0.7), inset 0 1px 0 rgba(255,255,255,0.05)',
        'inset-deep': 'inset 0 2px 30px rgba(0,0,0,0.6)',
      },
      backdropBlur: {
        'xs': '2px',
        '4xl': '72px',
      },
      animation: {
        'breathe':       'breathe 6s ease-in-out infinite',
        'shimmer':       'shimmer 3.5s linear infinite',
        'flicker':       'flicker 4s ease-in-out infinite',
        'rotate-slow':   'spin 60s linear infinite',
      },
      keyframes: {
        breathe: {
          '0%, 100%': { transform: 'scale(1)',    opacity: '0.85' },
          '50%':      { transform: 'scale(1.02)', opacity: '1'    },
        },
        shimmer: {
          '0%':   { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0'  },
        },
        flicker: {
          '0%, 100%': { opacity: '1'    },
          '45%':      { opacity: '0.92' },
          '50%':      { opacity: '0.7'  },
          '55%':      { opacity: '0.95' },
        },
      },
    },
  },
  plugins: [],
};
