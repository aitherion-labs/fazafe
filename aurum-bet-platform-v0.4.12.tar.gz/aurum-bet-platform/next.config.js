/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  transpilePackages: ['three'],
  webpack: (config, { dev }) => {
    // GLSL imports
    config.module.rules.push({
      test: /\.(glsl|vs|fs|vert|frag)$/,
      use: ['raw-loader'],
    });

    // Bump chunk-load timeout. Default is 120s; on slow filesystems
    // (WSL → /mnt/c/, network mounts, antivirus-scanned dirs) the dev
    // server can stall while compiling on first request and webpack
    // bails out client-side with `ChunkLoadError`. 5-minute ceiling
    // is plenty for any realistic dev environment.
    config.output = config.output || {};
    config.output.chunkLoadTimeout = 300000; // 5 minutes

    return config;
  },
  experimental: {
    optimizePackageImports: ['@react-three/drei', '@react-three/fiber'],
  },
  // Slim the on-demand entries TTL upward — dev was throwing chunks
  // away too eagerly on slow filesystems.
  onDemandEntries: {
    maxInactiveAge:    600 * 1000,  // 10 min
    pagesBufferLength: 8,
  },
};

module.exports = nextConfig;
