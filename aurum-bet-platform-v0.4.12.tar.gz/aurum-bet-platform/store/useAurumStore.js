'use client';

import { create } from 'zustand';

/**
 * UI / shell state only. Routing is handled by Next.js App Router.
 * (Old `scene` field was removed — App Router is now the source of truth.)
 */
export const useAurumStore = create((set) => ({
  atmosphere:    'noir',
  audioEnabled:  false,
  isLoading:     true,
  hoveredPortal: null,
  kioskMode:     false,
  reducedMotion: false,
  locale:        'en',
  revealPhase:   0,

  setAtmosphere:    (atmosphere)    => set({ atmosphere }),
  toggleAudio:      ()              => set((s) => ({ audioEnabled: !s.audioEnabled })),
  setLoading:       (isLoading)     => set({ isLoading }),
  setHoveredPortal: (id)            => set({ hoveredPortal: id }),
  setKioskMode:     (kioskMode)     => set({ kioskMode }),
  setReducedMotion: (reducedMotion) => set({ reducedMotion }),
  setLocale:        (locale)        => set({ locale }),
  setRevealPhase:   (revealPhase)   => set({ revealPhase }),
}));
