'use client';

import { create } from 'zustand';
import { replay, deposit, withdraw, lockBet, settleBet } from '@/services/wallet';
import { newKey } from '@/services/idempotency';
import { D, gte, formatCurrency, toString as moneyStr } from '@/services/money';
import { useAurumStore } from '@/store/useAurumStore';

/**
 * Wallet store
 *  - keeps `available` / `locked` / `lifetime` in sync with ledger replay
 *  - exposes intent-shaped operations to UI (no math in components)
 */
export const useWalletStore = create((set, get) => ({
  // balances mirror the ledger replay
  available: '0',
  locked:    '0',
  lifetime:  '0',
  currency:  'EUR',
  lastError: null,

  /** Replay ledger and refresh balances. */
  refresh: (accountId) => {
    if (!accountId) return;
    try {
      const b = replay(accountId);
      set({ ...b, lastError: null });
    } catch (e) {
      set({ lastError: e.message });
    }
  },

  /** Seed wallet for a brand-new session (V0.1 demo). 2500 $ welcome credits. */
  seedDemo: async (accountId) => {
    const { available } = get();
    if (D(available).gt(0)) return; // already seeded
    await deposit({
      accountId,
      amount: '2500',
      idempotencyKey: `seed_${accountId}`,
      meta: { simulated: true, kind: 'welcome_bonus' },
    });
    get().refresh(accountId);
  },

  deposit: async (accountId, amount) => {
    try {
      await deposit({
        accountId,
        amount: moneyStr(amount),
        idempotencyKey: newKey('dep'),
        meta: { simulated: true },
      });
      get().refresh(accountId);
      return { ok: true };
    } catch (e) {
      set({ lastError: e.message });
      return { ok: false, reason: e.message };
    }
  },

  withdraw: async (accountId, amount) => {
    const balances = { available: get().available, locked: get().locked, lifetime: get().lifetime };
    try {
      await withdraw({
        accountId,
        amount: moneyStr(amount),
        balances,
        idempotencyKey: newKey('wd'),
        meta: { simulated: true },
      });
      get().refresh(accountId);
      return { ok: true };
    } catch (e) {
      set({ lastError: e.message });
      return { ok: false, reason: e.message };
    }
  },

  /** Lock a bet stake. Returns the roundId you must pass back to settle. */
  lock: async (accountId, amount, gameId) => {
    const balances = { available: get().available, locked: get().locked, lifetime: get().lifetime };
    if (!gte(balances.available, amount)) {
      return { ok: false, reason: 'INSUFFICIENT_FUNDS' };
    }
    const roundId = newKey(`round_${gameId}`);
    try {
      await lockBet({
        accountId,
        amount: moneyStr(amount),
        idempotencyKey: roundId,           // ← idempotent
        balances,
        meta: { gameId, roundId },
      });
      get().refresh(accountId);
      return { ok: true, roundId };
    } catch (e) {
      set({ lastError: e.message });
      return { ok: false, reason: e.message };
    }
  },

  /** Settle the bet locked under `roundId`. */
  settle: async (accountId, { roundId, stake, payout, outcome, meta = {} }) => {
    try {
      await settleBet({
        accountId,
        stake: moneyStr(stake),
        payout: moneyStr(payout || 0),
        outcome,
        idempotencyKey: `settle_${roundId}`,
        meta: { ...meta, roundId },
      });
      get().refresh(accountId);
      return { ok: true };
    } catch (e) {
      set({ lastError: e.message });
      return { ok: false, reason: e.message };
    }
  },

  // ----- selectors -----
  formatted: () => {
    const locale = useAurumStore.getState().locale;
    const tag = { en: 'en-US', pt: 'pt-BR', fr: 'fr-FR' }[locale] || 'en-US';
    return {
      available: formatCurrency(get().available, tag),
      locked:    formatCurrency(get().locked, tag),
      lifetime:  formatCurrency(get().lifetime, tag),
    };
  },
}));
