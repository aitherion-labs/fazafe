'use client';

import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { nanoid } from 'nanoid';

/**
 * Account / session store.
 * V0.1: localStorage-backed pseudo-auth (no real password hashing, no JWT).
 * V0.2 will replace this with a backend session + refresh-token flow.
 *
 * IMPORTANT: nothing in this store is security-grade. It is a simulation
 * to flesh out flow + UX, NOT real authentication.
 */
export const useAccountStore = create(
  persist(
    (set, get) => ({
      // session
      accountId:   null,
      handle:      null,
      email:       null,
      avatarSeed:  null,
      sessionStart: null,

      isAuthenticated: () => Boolean(get().accountId),

      signup: ({ email, handle }) => {
        const accountId  = nanoid(12);
        const avatarSeed = nanoid(8);
        set({
          accountId, handle, email, avatarSeed,
          sessionStart: new Date().toISOString(),
        });
        return { ok: true, accountId };
      },

      login: ({ email }) => {
        // V0.1: any email logs in — pseudo-auth.
        const handle = email.split('@')[0];
        const accountId = `dev_${handle}`;
        const avatarSeed = handle;
        set({
          accountId, handle, email, avatarSeed,
          sessionStart: new Date().toISOString(),
        });
        return { ok: true, accountId };
      },

      logout: () => {
        set({
          accountId: null, handle: null, email: null,
          avatarSeed: null, sessionStart: null,
        });
      },
    }),
    { name: 'aurum.account.v1' }
  )
);
