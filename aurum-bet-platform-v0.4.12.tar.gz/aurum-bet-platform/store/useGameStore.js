'use client';

import { create } from 'zustand';

/**
 * Active game session (game-agnostic shape).
 * Each game module reads/writes its own slice under `state`.
 */
export const useGameStore = create((set, get) => ({
  activeGameId: null,        // 'roulette' | 'blackjack' | 'slots' | 'poker' | null
  roundId:      null,        // current locked-bet idempotency token
  stake:        null,        // string-decimal
  state:        {},          // game-specific blob

  enter: (gameId) => set({ activeGameId: gameId, state: {}, roundId: null, stake: null }),
  leave: ()       => set({ activeGameId: null,  state: {}, roundId: null, stake: null }),

  setRound: ({ roundId, stake }) => set({ roundId, stake }),
  setState: (patch) => set((s) => ({ state: { ...s.state, ...patch } })),
  reset:    ()      => set({ roundId: null, stake: null, state: {} }),
}));
