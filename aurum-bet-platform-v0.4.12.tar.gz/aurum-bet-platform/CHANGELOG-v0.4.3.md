# CHANGELOG — V0.4.3

Focus: **clarity, integrity, audit**. No new games. No refactor of payments
(which would risk reintroducing the circular dep). Surgical additions to
make the existing flows trustworthy.

## Fixed

- **Roulette could land in an ambiguous state** where `spinning=false` but
  no result was rendered. Replaced the ad-hoc state with an explicit
  4-state phase machine (`IDLE → SPINNING → RESOLVING → RESULT`) and a
  `lastResult` record that *persists* on screen until the player starts
  a new round.
- **Slots had no visible winning line** — when a payline won, the player
  could only tell from the gold halo on individual symbols. Now an
  animated SVG polyline overlays the winning combination, with a `×N`
  multiplier label at the end of the line.
- **Double-submit risk** in roulette spin, blackjack deal, and quick
  deposit. Each now has a token-based or ref-based in-flight guard so
  rapid clicks can't fire the action twice.
- **Slots autoplay could race the resolve step**. Wrapped in the same
  phase machine; autoplay only fires the next spin after the current
  one is fully `RESULT`.
- **Chip component fell back to `100`-style colors for any unknown
  denomination.** Expanded the palette to cover $1–$10K and added an
  explicit `FALLBACK` gold scheme. The selected chip now has an
  unmistakable gold halo (not just `y:-10`).
- **Patrimoine** label in the HUD was hardcoded French. Now flows
  through `t('hud.wealth')`.

## Added

- `lib/config.js` — `APP_MODE` (sandbox / demo / licensed) with hard-locked
  defaults. `licensed` mode is rejected at startup until the post-audit
  RC release. Feature flags follow the same shape (`isFeatureEnabled`).
- `components/ui/EnvBanner.jsx` — persistent corner badge (`SANDBOX · NO
  REAL FUNDS`) visible in non-licensed modes.
- `services/audit.js` — `auditRound()` wrapper around the existing hash-
  chain ledger. Every round in roulette, slots, and blackjack now writes
  an entry with gameId, roundId, accountId, bets, result, payout,
  outcome, balance-before, balance-after, and a compact summary hash.
- `components/ui/ChipSelector.jsx` — shared denomination row used by all
  games. Replaces three near-identical inline implementations.
- `components/ui/BetSummary.jsx` — shared bet/balance/return/last-result
  panel. Pure presentational, reads from the wallet store.
- `lib/winningLine.js` — helpers for mapping slot paylines to SVG points.
- Roulette `ResultPanel` — top-right, persistent. Number, color, parity,
  range, stake, balance before, balance after, outcome, net, winners/losers
  count, and a "New Round" affordance.
- Roulette `HistoryStrip` — top-left, last 10 spins as colored pills.
- Slots `SlotsResultPanel` — top-right, persistent. Outcome, net, list
  of winning lines with their multipliers, stake, balance before/after.
- Sanity-check script (`npm run sanity` / `node __sanity__/sanity-check.cjs`).
  Verifies: circular dep stays broken, 4 adapters bootstrap, RTP in
  range, decimal precision, APP_MODE defaults safe.

## Touched files

```
app/lounge/roulette/page.jsx      — rewrite: phase machine, ResultPanel, history, audit
app/lounge/slots/page.jsx         — rewrite: phase machine, WinningLineOverlay, SlotsResultPanel, audit
app/lounge/blackjack/page.jsx     — double-submit guard, audit, balanceBefore in finalize
components/ui/Chip.jsx            — expanded palette, prominent selected state
components/ui/ChipSelector.jsx    — NEW
components/ui/BetSummary.jsx      — NEW
components/ui/EnvBanner.jsx       — NEW
components/ui/QuickDeposit.jsx    — inFlightRef double-submit guard
components/Providers.jsx          — mount EnvBanner
lib/config.js                     — NEW
lib/i18n.js                       — +15 keys (game state, balance, winning line)
lib/winningLine.js                — NEW
services/audit.js                 — NEW
services/payments/adapter.js      — clarifying comment about not importing children
services/payments/index.js        — clarifying comment about bootstrap order
__sanity__/sanity-check.cjs       — NEW
package.json                      — bump 0.4.3, add `sanity` script
```

## Risks still on the table

- **Multiple tabs** could double-spend the same idempotency key window in
  the in-memory wallet. Real risk only at RC; for sandbox it's a non-issue
  because each tab gets its own React tree.
- **Service worker** isn't shipped yet. PWA installable but not offline.
  Service worker is V0.5.
- **Poker** is still a stub. Implementation deferred to V0.5/V0.6 when the
  WebSocket backend lands.
- **Compliance providers** are stubs only. Real KYC/geo/age verification
  needs vendor selection and contracts.
- **Mobile breakpoints**: result panels assume desktop width. They stay
  legible on tablet but get cramped on phones (< 480px). V0.5 sweep.

## How to test

```bash
# 1. clean any stale build
rm -rf .next

# 2. install (only re-resolves new deps if any)
npm install

# 3. run sanity checks — fast, no browser needed
npm run sanity

# 4. run dev server
npm run dev
```

Then in the browser:

1. **Sandbox badge** — bottom-left, red dot, `SANDBOX · NO REAL FUNDS`.
2. **+ Chips** button in the top-right HUD. Click → modal → pick $500.
3. **Roulette** — place a $25 chip on red. SPIN. After ~4s, top-right
   ResultPanel shows the winning number, color, balance before/after,
   net. The winning number is highlighted on the felt and stays
   highlighted. The history strip top-left adds the new number.
4. **Slots** — spin 5 lines. On a win, a gold SVG line draws over the
   winning row, with a `×N` label at the right end. Symbols on the line
   pulse. Right panel shows which line(s) won and the multiplier.
5. **Blackjack** — try clicking "Deal" twice rapidly. Only one round
   starts.
6. **Quick Deposit** — try clicking the same denomination twice rapidly.
   Only one credit posts.

## Acceptance criteria (from spec)

- [x] ReferenceError 'Cannot access register before initialization' does NOT come back
- [x] Roulette winning number is unambiguous (big colored circle in result panel + felt highlight + history strip)
- [x] All chips show their value (Chip component updated, $-prefix, denomination always centered)
- [x] Slots shows winning line when there's a win (animated SVG polyline)
- [x] QuickDeposit + /wallet/deposit continue working (sanity check confirms; manual test)
- [x] Project remains safe-by-default in `sandbox` (config.js hard-locks real money off)
