# AURUM — Immersive Casino Platform · **V0.4 · Payments Edition**

> *"Where chance becomes silk."*
>
> A single, modular, scalable, cinematic platform. Each game is a room
> within the same casino — not a separate page.

> 💳 **V0.4 · Payments unlocked**
>
> - **One-tap "+ Chips" button** in the HUD (top-right, next to balance).
>   Opens an instant-credit modal — $100/$500/$1k/$5k/$10k denominations.
>   Works from anywhere in the app.
> - **Polished card payment form** at `/wallet/deposit` with realistic
>   Stripe-style fields (formatted card number, expiry, CVV, brand badge
>   detection by BIN prefix, simulated 1.6s authorization). Live card
>   preview as you type.
> - **Inline low-balance prompt** in Slots / Roulette / Blackjack — when
>   the player's balance falls below the smallest chip, a banner offers
>   one-tap top-up without leaving the table.
> - All payment paths still **simulated** (`meta.simulated: true` in the
>   ledger). The adapter interface is unchanged — real PCI integration
>   in RC slots in without touching the UI.

---

## ⚠️ Quick Start (WSL users — read this)

If you run Windows + WSL: **don't put the project under `/mnt/c/`**.
Move it to your WSL home (`~/`). On the Windows filesystem, Node.js
is 10–100× slower and webpack will eventually time out chunk loads.

```bash
# From within WSL
cd ~
tar -xzf aurum-bet-platform-v0.3.tar.gz
cd aurum-bet-platform
npm install
npm run dev      # → http://localhost:3000
```

Native macOS/Linux: same commands, no caveat.

First session is granted **$2,500 demonstration credit** automatically.

---

## 💰 How to add more chips (for testing)

You have **three** ways. Pick the one that fits the moment:

### 1. **+ Chips button in the HUD** (fastest)

Top-right of the screen, right next to your balance. Click → modal pops
up → pick a denomination → instant credit. ~1 second total.

```
Balance  $1,234.56   [ + Chips ]   EN   ◐ audio   👤 handle
```

Built for the Vegas demo: you never leave the table to top up.

### 2. **The Vault → Make a Deposit** (full flow)

For demonstrating the payment experience to an audience. Navigate to
`/wallet/deposit` (or click your balance pill in the HUD → Make a
Deposit). Pick amount, pick method (default: **International Card**),
fill the card form, click Pay. A realistic 1.6s authorization animation
runs, then success.

The card form accepts any 16-digit number — it's a simulator. BIN
prefix is detected for the brand badge (Visa/MC/Amex/Discover).

### 3. **Low-balance inline prompt** (automatic)

When your balance falls below the smallest chip value while at a game
table, a small **+ Top up to keep playing** banner appears near the
top of the screen. One tap → same Quick Deposit modal as path 1.

All three paths route through the same ledger code and write `meta.simulated: true`
entries. No real funds move. The architecture is RC-ready: swap the
`card.js` adapter body for Stripe/Adyen API calls and the UI is done.

---

## ✦ What's new V0.2 → V0.3

| Area | V0.2 | V0.3 |
|---|---|---|
| Default locale | `fr` | `en` (US) |
| Currency display | `₳ 1 234,56` (FR) | `$1,234.56` (en-US) |
| Date format | `fr-FR` style | `en-US` (May 11, 2026, 3:42 PM) |
| Roulette bets | 6 outside only | **10 types**: straight, split, street, corner, six-line, dozen, column, red/black, even/odd, low/high |
| Roulette UI | 6 buttons | Full interactive SVG felt with chip stacks at every bet position |
| Slots animation | Single-speed spin | Anticipation suspense, animated balance, recent history, button microinteractions |
| Slots HUD | Bet + spin + autoplay | + balance counter, + recent panel, + pulsing CTA |
| i18n coverage | Entry only | Lobby + Blackjack + Roulette + Slots + Wallet + Auth + Demo |

---

## ✦ The Roulette Felt

A real-table layout, drawn as SVG:

```
       ┌─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┐
       │3│6│9│12│15│18│21│24│27│30│33│36│  2:1
   ┌─┐ ├─┼─┼─┼─┼──┼──┼──┼──┼──┼──┼──┼──┤
   │0│ │2│5│8│11│14│17│20│23│26│29│32│35│  2:1
   └─┘ ├─┼─┼─┼─┼──┼──┼──┼──┼──┼──┼──┼──┤
       │1│4│7│10│13│16│19│22│25│28│31│34│  2:1
       ├─┴─┴─┴─┼──┴──┴──┴─┼──┴──┴──┴──┤
       │ 1st 12│  2nd 12  │   3rd 12  │
       ├───┬───┼───┬───┬──┼───────────┤
       │1-18│EVN│♦  │♠  │ODD│  19-36   │
       └────┴───┴───┴───┴───┴──────────┘
```

Every click target is positioned exactly where a chip lands at a real
table:

- **Straight bet** — chip in the center of a number cell (35:1)
- **Split** — chip on the border between two adjacent numbers (17:1)
- **Street** — chip at the outer edge of a row of 3 (11:1)
- **Corner** — chip at the intersection of 4 cells (8:1)
- **Six-line** — chip at the edge between two streets (5:1)
- **Dozen** — chip on `1st 12 / 2nd 12 / 3rd 12` (2:1)
- **Column** — chip on the `2 to 1` cells (2:1)
- **Red / Black** — chip on `♦ RED` or `♠ BLACK` (1:1)
- **Even / Odd** — outside cells (1:1)
- **1-18 / 19-36** — outside cells (1:1)
- **Zero** — green cell on the left (35:1 straight only)

Multiple bets stack on the same spot. Total displayed in the HUD. Single
`SPIN` button locks the sum, the wheel resolves, all bets settle in one
ledger entry.

---

## ✦ The Slots Polish

Same vintage cabinet (mahogany + gold + ivory reels). What changed:

**Anticipation.** When reels 1 and 2 land showing the same high-pay
symbol on the center line, reel 3 *doesn't immediately stop*. Instead
it goes into an "anticipating" state — micro-jitter with a pulsing gold
halo — for an extra 1.6 seconds before settling. Standard slot-floor
suspense pattern.

**Recent history panel.** Bottom-left shows the last 8 spins as
3-symbol mini-strips with the payout next to each. Players can see
their streak at a glance.

**Animated balance counter.** Bottom-left, large display. On a win the
balance ticks up smoothly toward the new value over ~0.6s, not a jarring
jump.

**Spin CTA.** Pulses gently when idle to invite the next spin. Dim and
non-interactive during busy state.

**Micro-interactions.** Every chip and button responds to hover with a
small lift, to click with a small press-down. Tactile, not flashy.

**RTP unchanged.** Still calibrated at **93.62%** via exhaustive
enumeration of 9,261 outcomes. See `games/slots/engine.js`.

---

## ✦ Localization

`lib/i18n.js` ships with three locales, each ~200 keys covering every
visible string in the app:

- **`en`** — American English (default)
- **`pt`** — Brazilian Portuguese
- **`fr`** — French (original brand language)

Switcher is the **EN / PT / FR** button in the HUD top-right (cycles).

```jsx
import { useT } from '@/lib/i18n';

function MyComponent() {
  const t = useT();
  return <h1>{t('lobby.title')}</h1>;
}
```

Missing key → fall back to `en` → fall back to the key itself
(visible in dev).

---

## ✦ Currency

`services/money.js` exports:

```js
formatCurrency(value, locale)
  // en-US → "$1,234.56"
  // pt-BR → "R$ 1.234,56"
  // fr-FR → "1 234,56 €"
```

The Wallet store reads the user's current locale and picks the right
BCP-47 tag, so balance / stake / payout displays match the active UI
language. The locale-currency mapping in `LOCALE_CURRENCY`.

---

## ✦ Roulette — European single-zero

37 pockets (0–36). House edge ~2.7%. We did NOT switch to American
double-zero for V0.3 because:

1. The European wheel mesh + engine are already calibrated
2. High-end Vegas tables (Bellagio, Wynn, Aria Hi-Limit) offer European
3. Better odds for the player → better demo feel

If V0.4 needs American (which it might for casual-floor visual
authenticity), the change is: add `00` pocket to `POCKETS`, increase
`spin()` range to 38, and update the wheel mesh `RouletteWheel.jsx`
to render 38 pockets. Engine bet types remain unchanged.

---

## ✦ Tech Stack

| Layer | Library |
|---|---|
| Framework | Next.js 14 (App Router) |
| 3D | three.js + @react-three/fiber + drei + postprocessing |
| State | Zustand (4 specialized stores) |
| Animation | framer-motion (UI) + GSAP (3D timelines) |
| Audio | Howler.js (HEAD-probed init — silent if assets missing) |
| Money | decimal.js (28-digit precision) |
| IDs | nanoid |
| Hashing | WebCrypto SHA-256 |
| Styling | Tailwind CSS + CSS variables |
| Typography | Cormorant Garamond · Inter Tight · JetBrains Mono |

---

## ✦ Map

```
/                       Cinematic entry
/lounge                 The Floor (4 portals)
  ├── /roulette         The Wheel       — full betting felt (V0.3)
  ├── /blackjack        Twenty-One      — i18n (V0.3)
  ├── /slots            The Reels       — polished (V0.3)
  └── /poker            The Initiated   — V0.4 placeholder
/account
  ├── /login
  ├── /signup
  └── /profile
/wallet                 The Vault (balance + ledger)
  ├── /deposit          — simulated payments
  └── /withdraw         — KYC-gated
/compliance
  ├── /kyc              — 4-step verification (simulated)
  └── /responsible      — limits + self-exclusion
/demo                   Kiosk mode (auto-cycling scenes)
```

---

## ✦ Project Layout

```
aurum-bet-platform/
├── app/                    Next.js App Router pages
├── design-system/          AURUM DS (tokens, components, scenes…)
├── games/
│   ├── roulette/
│   │   ├── engine.js          ← V0.3: 10 bet types, full settle()
│   │   └── BettingFelt.jsx    ← V0.3 NEW: interactive SVG felt
│   ├── slots/engine.js        93.6% RTP, calibrated
│   ├── blackjack/             engine + Table + Card3D
│   └── poker/                 stub
├── services/
│   ├── money.js               ← V0.3: USD/en-US default
│   ├── ledger.js              SHA-256 hash chain
│   ├── wallet.js              ACID-style ops
│   ├── idempotency.js
│   ├── compliance.js
│   └── payments/              Adapter pattern (NOT ACTIVE)
├── store/
│   ├── useAurumStore.js       ← locale='en' default
│   ├── useWalletStore.js      ← locale-aware formatting
│   ├── useAccountStore.js
│   └── useGameStore.js
├── components/
│   ├── Providers.jsx
│   ├── ErrorBoundary.jsx
│   ├── AmbientAudioBridge.jsx
│   ├── ReducedMotionGate.jsx
│   ├── three/                 Procedural 3D scenes
│   ├── effects/               PostFX, dust, beams
│   └── ui/                    HUD, Cursor, AuthShell, etc.
├── lib/
│   ├── i18n.js                ← V0.3: EN/PT/FR with ~200 keys each
│   ├── audio.js               HEAD-probed Howler
│   └── animations.js
└── public/
    ├── manifest.json          PWA
    ├── icons/                 SVG icons
    └── audio/                 (optional .mp3 — gracefully absent)
```

---

## ✦ Troubleshooting

### `ChunkLoadError: Loading chunk app/layout failed`

Corrupted `.next/` from a prior failed build. Clean and rebuild:

```bash
rm -rf .next
npm run dev
```

### "Compiled in 45 seconds"

Project is on Windows filesystem via WSL. Move to `~/`.

### `npm audit` reports 9 vulnerabilities

All in dev-deps (eslint 8, glob, rimraf). None reach runtime. Run
`npm audit fix` if you want them silenced. **Do NOT run `--force`** —
breaks peer deps.

### Audio 404s

Expected. No `.mp3` files are shipped. The audio engine probes each
file with HEAD before registering — no console noise. Drop `.mp3` files
into `public/audio/` to enable: `ambient.mp3`, `roulette.mp3`,
`hover.mp3`, `click.mp3`, `chip.mp3`, `reveal.mp3`.

---

## ✦ Roadmap V0.3 → RC

| Version | Focus |
|---|---|
| **V0.4** | Poker Hold'em multiplayer (WebSocket); service worker offline; replay of rounds |
| **V0.5** | Real backend (Postgres + Prisma + JWT); Redis idempotency cache; server-side ledger |
| **V0.6** | Real KYC (Onfido/Sumsub); behavioral responsible-gaming model |
| **RC** | Certified payment gateway (Stripe/Adyen); PSD2/3DS2; segregated funds; external audit |
| **V1.0** | After public bug bounty + independent RTP cert |

---

## ✦ Commands

```bash
npm run dev            # dev server
npm run build          # production build
npm run start          # serve build
npm run lint           # eslint

# Reset ledger + idempotency (browser console)
import('/services/ledger').then(m => m.__resetForDev());

# Audit slots RTP
node -e "import('./games/slots/engine.js').then(m => console.log(m.computeRTP()))"
```

---

## ✦ V0.3 Acceptance Checklist

- [x] Default locale is `en` (American English)
- [x] All chrome strings route through `useT()`
- [x] Currency in USD with en-US formatting throughout
- [x] Roulette has **all 10 bet types** with click zones at correct felt positions
- [x] Chips stack visually with running amount on each bet position
- [x] Total bet sum + clear + repeat-last controls
- [x] Single ledger entry per spin (combined lock/settle)
- [x] Slots: anticipation state when 2/3 reels match
- [x] Slots: animated balance counter
- [x] Slots: recent results panel (last 8)
- [x] Slots: button microinteractions (hover lift, click press)
- [x] Slots: pulsing spin CTA when ready
- [x] Vintage premium aesthetic preserved
- [x] All 90+ JSX files parse cleanly via @babel/parser
- [x] Version `0.3.0` in `package.json`

---

> **AURUM is not casino software. It's a place.**
