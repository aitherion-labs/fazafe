/**
 * Brushed-gold material approximation.
 * Anisotropic highlight along the surface tangent + warm fresnel rim.
 */

export const goldVertex = /* glsl */ `
  varying vec3 vNormal;
  varying vec3 vPos;
  varying vec2 vUv;
  void main() {
    vNormal = normalize(normalMatrix * normal);
    vec4 mvp = modelViewMatrix * vec4(position, 1.0);
    vPos = mvp.xyz;
    vUv  = uv;
    gl_Position = projectionMatrix * mvp;
  }
`;

export const goldFragment = /* glsl */ `
  uniform float uTime;
  uniform vec3  uLightDir;
  uniform float uPolish;     // 0 = matte, 1 = mirror

  varying vec3 vNormal;
  varying vec3 vPos;
  varying vec2 vUv;

  vec3 GOLD_DEEP = vec3(0.478, 0.361, 0.094);
  vec3 GOLD      = vec3(0.784, 0.635, 0.290);
  vec3 GOLD_HI   = vec3(0.957, 0.843, 0.541);
  vec3 GOLD_PALE = vec3(1.000, 0.945, 0.780);

  void main() {
    vec3  N = normalize(vNormal);
    vec3  L = normalize(uLightDir);
    vec3  V = normalize(-vPos);
    vec3  H = normalize(L + V);

    float NdL = max(dot(N, L), 0.0);
    float NdH = max(dot(N, H), 0.0);
    float fresnel = pow(1.0 - max(dot(N, V), 0.0), 3.0);

    // anisotropic streak (brushed look) — warps along U
    float streak = sin(vUv.x * 60.0 + uTime * 0.2) * 0.5 + 0.5;
    streak = mix(0.85, 1.0, streak);

    vec3 base = mix(GOLD_DEEP, GOLD, NdL);
    base = mix(base, GOLD_HI, pow(NdH, mix(8.0, 80.0, uPolish)) * streak);
    base += GOLD_PALE * fresnel * 0.45;

    gl_FragColor = vec4(base, 1.0);
  }
`;
