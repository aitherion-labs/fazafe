/**
 * Volumetric light cone shader.
 * Renders a soft, dust-lit beam from a virtual ceiling spotlight.
 * Used in: CinematicEntry, Lobby, RouletteTable.
 */

export const volumetricVertex = /* glsl */ `
  varying vec2 vUv;
  varying vec3 vWorldPos;
  void main() {
    vUv = uv;
    vec4 wp = modelMatrix * vec4(position, 1.0);
    vWorldPos = wp.xyz;
    gl_Position = projectionMatrix * viewMatrix * wp;
  }
`;

export const volumetricFragment = /* glsl */ `
  uniform vec3  uColor;
  uniform float uTime;
  uniform float uIntensity;
  varying vec2  vUv;
  varying vec3  vWorldPos;

  // hash + noise for dust shimmer
  float hash(vec2 p)  { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
  float noise(vec2 p) {
    vec2 i = floor(p), f = fract(p);
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
  }

  void main() {
    // radial falloff from center axis of the cone
    float r = length(vUv - vec2(0.5, 0.5)) * 2.0;
    float radial = smoothstep(1.0, 0.0, r);

    // vertical falloff (top bright, bottom faded)
    float vert = smoothstep(0.0, 1.0, 1.0 - vUv.y);

    // dust shimmer
    float dust = noise(vUv * 8.0 + uTime * 0.15) * 0.35
               + noise(vUv * 24.0 - uTime * 0.4) * 0.15;

    float beam = radial * vert * (0.65 + dust);
    vec3 col = uColor * beam * uIntensity;

    gl_FragColor = vec4(col, beam * 0.55);
  }
`;
