import { nanoid } from 'nanoid';

/**
 * Idempotency keys protect financial operations from double-execution
 * (network retries, double-clicks, race conditions).
 *
 * Pattern: caller derives a key from a *stable* attribute of the intent
 *  (e.g. `bet:${roundId}:${userId}` or a freshly-generated nanoid for an
 *   ad-hoc deposit). The ledger refuses to write the same key twice.
 */

export const newKey = (prefix = 'op') => `${prefix}_${nanoid(16)}`;

export const betKey      = (roundId)            => `bet_${roundId}`;
export const settleKey   = (roundId)            => `settle_${roundId}`;
export const depositKey  = (sessionId, ts = Date.now()) => `deposit_${sessionId}_${ts}`;
export const withdrawKey = (sessionId, ts = Date.now()) => `withdraw_${sessionId}_${ts}`;
