import Decimal from 'decimal.js';

// 28-digit precision is more than enough for any imaginable casino balance.
Decimal.set({ precision: 28, rounding: Decimal.ROUND_HALF_EVEN });

/**
 * Money — thin façade over decimal.js to enforce conventions:
 *   - Internal representation: Decimal in MAJOR units (e.g. $12.50 = Decimal("12.50"))
 *   - All arithmetic: dec.add / sub / mul / div
 *   - All serialization: toString() (never toNumber, never JSON.stringify Decimal)
 *   - All comparisons: cmp / eq / gte / lte
 *
 * V0.3: switched to USD / en-US formatting for the Vegas launch.
 *       Brand currency mark `$` retired in favor of standard `$`.
 *       Use `formatCurrency(v, 'en-US')` for explicit locale formatting.
 */

export const ZERO = new Decimal(0);

export const D = (v) => {
  if (v instanceof Decimal) return v;
  if (v === null || v === undefined || v === '') return new Decimal(0);
  return new Decimal(typeof v === 'number' ? v.toString() : v);
};

export const add = (a, b) => D(a).plus(D(b));
export const sub = (a, b) => D(a).minus(D(b));
export const mul = (a, b) => D(a).times(D(b));
export const div = (a, b) => D(a).dividedBy(D(b));

export const eq  = (a, b) => D(a).eq(D(b));
export const gte = (a, b) => D(a).gte(D(b));
export const lte = (a, b) => D(a).lte(D(b));
export const gt  = (a, b) => D(a).gt(D(b));
export const lt  = (a, b) => D(a).lt(D(b));

/**
 * Format a decimal value for the given locale.
 * Defaults to en-US (Vegas): 12345.678 → "12,345.68"
 */
export const format = (v, locale = 'en-US') => {
  const num = parseFloat(D(v).toFixed(2));
  return new Intl.NumberFormat(locale, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(num);
};

/**
 * Format as currency.
 * Defaults to USD/en-US: 12345.678 → "$12,345.68"
 *
 * Each locale gets its native pairing:
 *   en → USD ($)     pt → BRL (R$)     fr → EUR (€)
 *
 * Pass an explicit (value, locale) to override.
 */
const LOCALE_CURRENCY = {
  'en-US': 'USD',
  'en':    'USD',
  'pt-BR': 'BRL',
  'pt':    'BRL',
  'fr-FR': 'EUR',
  'fr':    'EUR',
};

export const formatCurrency = (v, locale = 'en-US') => {
  const num = parseFloat(D(v).toFixed(2));
  const currency = LOCALE_CURRENCY[locale] || 'USD';
  try {
    return new Intl.NumberFormat(locale, {
      style: 'currency',
      currency,
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(num);
  } catch (_) {
    // last-resort fallback
    return `$${format(v, 'en-US')}`;
  }
};

/** Stable string for hashing / persistence */
export const toString = (v) => D(v).toFixed();

/**
 * Format a Date in the user's locale.
 * en-US gets "May 11, 2026, 3:42 PM" style; others get their native format.
 */
export const formatDate = (date, locale = 'en-US') => {
  const d = date instanceof Date ? date : new Date(date);
  try {
    return new Intl.DateTimeFormat(locale, {
      year: 'numeric', month: 'short', day: 'numeric',
      hour: 'numeric', minute: '2-digit',
    }).format(d);
  } catch (_) {
    return d.toLocaleString('en-US');
  }
};
