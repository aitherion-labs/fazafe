import { nanoid } from 'nanoid';
import { toString as moneyStr } from './money';

/**
 * AURUM LEDGER — append-only, hash-chained, deterministic.
 *
 * Every entry includes:
 *   - id              unique entry id
 *   - prevHash        SHA-256 hex of previous entry (or "GENESIS")
 *   - hash            SHA-256 of (prevHash + canonical(entry-without-hash))
 *   - timestamp       ISO 8601 UTC
 *   - accountId       opaque session id
 *   - type            'DEPOSIT' | 'WITHDRAW' | 'BET_LOCK' | 'BET_SETTLE' | 'BONUS' | 'ADJUSTMENT'
 *   - amount          string-encoded decimal (NEVER number)
 *   - currency        ISO code, default 'EUR'
 *   - idempotencyKey  client-supplied — duplicate keys ⇒ duplicate write rejected
 *   - meta            free-form (game, round, etc.)
 *
 * Persistence: V0.1 uses localStorage under key "aurum.ledger.v1".
 * V0.2 will plug in a server-side append-only datastore.
 */

const LS_KEY = 'aurum.ledger.v1';
const IDEM_KEY = 'aurum.idempotency.v1';

/* ------------------------------------------------------------------ */
/*  Crypto — SHA-256 via WebCrypto (browser)                           */
/* ------------------------------------------------------------------ */

async function sha256(text) {
  if (typeof window === 'undefined' || !window.crypto?.subtle) {
    // SSR / fallback — deterministic but not cryptographic
    let h = 0;
    for (let i = 0; i < text.length; i++) h = (h * 31 + text.charCodeAt(i)) | 0;
    return `noncrypto:${(h >>> 0).toString(16)}`;
  }
  const buf = new TextEncoder().encode(text);
  const out = await window.crypto.subtle.digest('SHA-256', buf);
  return Array.from(new Uint8Array(out))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

/* ------------------------------------------------------------------ */
/*  Canonicalization — deterministic JSON for hashing                  */
/* ------------------------------------------------------------------ */

function canonical(obj) {
  if (obj === null || typeof obj !== 'object') return JSON.stringify(obj);
  if (Array.isArray(obj)) return `[${obj.map(canonical).join(',')}]`;
  const keys = Object.keys(obj).sort();
  return `{${keys.map((k) => `${JSON.stringify(k)}:${canonical(obj[k])}`).join(',')}}`;
}

/* ------------------------------------------------------------------ */
/*  Persistence helpers                                                */
/* ------------------------------------------------------------------ */

function readEntries() {
  if (typeof window === 'undefined') return [];
  try { return JSON.parse(localStorage.getItem(LS_KEY) || '[]'); }
  catch { return []; }
}

function writeEntries(entries) {
  if (typeof window === 'undefined') return;
  localStorage.setItem(LS_KEY, JSON.stringify(entries));
}

function readIdem() {
  if (typeof window === 'undefined') return {};
  try { return JSON.parse(localStorage.getItem(IDEM_KEY) || '{}'); }
  catch { return {}; }
}

function writeIdem(map) {
  if (typeof window === 'undefined') return;
  localStorage.setItem(IDEM_KEY, JSON.stringify(map));
}

/* ------------------------------------------------------------------ */
/*  Public API                                                         */
/* ------------------------------------------------------------------ */

export async function appendEntry({
  accountId,
  type,
  amount,
  currency = 'EUR',
  idempotencyKey,
  meta = {},
}) {
  if (!accountId)        throw new Error('LEDGER: missing accountId');
  if (!type)             throw new Error('LEDGER: missing type');
  if (amount === undefined) throw new Error('LEDGER: missing amount');
  if (!idempotencyKey)   throw new Error('LEDGER: missing idempotencyKey');

  // Idempotency check
  const idem = readIdem();
  if (idem[idempotencyKey]) {
    return { duplicate: true, entry: idem[idempotencyKey] };
  }

  const entries = readEntries();
  const prev = entries[entries.length - 1];
  const prevHash = prev ? prev.hash : 'GENESIS';

  const draft = {
    id:             nanoid(),
    prevHash,
    timestamp:      new Date().toISOString(),
    accountId,
    type,
    amount:         moneyStr(amount),
    currency,
    idempotencyKey,
    meta,
  };

  const hash = await sha256(prevHash + canonical(draft));
  const entry = { ...draft, hash };

  entries.push(entry);
  writeEntries(entries);

  idem[idempotencyKey] = entry;
  writeIdem(idem);

  return { duplicate: false, entry };
}

export function listEntries(accountId) {
  return readEntries().filter((e) => !accountId || e.accountId === accountId);
}

/** Verify the chain. Returns { ok, breakAt, total } */
export async function verify() {
  const entries = readEntries();
  let prevHash = 'GENESIS';
  for (let i = 0; i < entries.length; i++) {
    const e = entries[i];
    const { hash, ...rest } = e;
    const recomputed = await sha256(prevHash + canonical(rest));
    if (recomputed !== hash || rest.prevHash !== prevHash) {
      return { ok: false, breakAt: i, total: entries.length };
    }
    prevHash = hash;
  }
  return { ok: true, breakAt: -1, total: entries.length };
}

/** Reset — DEV ONLY. Logs a warning. */
export function __resetForDev() {
  if (typeof window === 'undefined') return;
  console.warn('[AURUM LEDGER] dev reset called — all entries cleared');
  localStorage.removeItem(LS_KEY);
  localStorage.removeItem(IDEM_KEY);
}
