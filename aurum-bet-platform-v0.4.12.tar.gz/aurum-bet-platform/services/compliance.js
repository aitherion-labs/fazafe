/**
 * AURUM COMPLIANCE
 *
 * V0.1 implements the *gates* (rules) that wrap betting operations.
 * V0.2 will plug them into a real KYC provider (Onfido / Sumsub / Veriff)
 * and a responsible-gaming behavioral model.
 *
 * KYC Levels:
 *   0 - Anonymous  (demo mode only — no deposit, no withdraw, no real bet)
 *   1 - Email      (email verified)
 *   2 - Identity   (gov ID + selfie verified)
 *   3 - Enhanced   (proof of funds — for high stakes)
 *
 * Self-exclusion / time-out: user-set limits stored locally in V0.1.
 */

const KEY = 'aurum.compliance.v1';

const defaults = {
  kycLevel:           0,
  email:              null,
  emailVerified:      false,
  identityVerified:   false,
  selfExcluded:       false,
  selfExclusionUntil: null,
  dailyLimit:         null, // string-decimal or null
  weeklyLimit:        null,
  sessionLimitMin:    null,
  acceptedTerms:      false,
};

function load() {
  if (typeof window === 'undefined') return { ...defaults };
  try { return { ...defaults, ...JSON.parse(localStorage.getItem(KEY) || '{}') }; }
  catch { return { ...defaults }; }
}

function save(state) {
  if (typeof window === 'undefined') return;
  localStorage.setItem(KEY, JSON.stringify(state));
}

export function getStatus() {
  return load();
}

export function setStatus(patch) {
  const next = { ...load(), ...patch };
  save(next);
  return next;
}

export function reset() {
  save({ ...defaults });
}

/* ------------------------------------------------------------- */
/*  Gates — call these before performing an action                */
/* ------------------------------------------------------------- */

export function canDeposit() {
  const s = load();
  if (s.selfExcluded) return { ok: false, reason: 'SELF_EXCLUDED' };
  if (s.kycLevel < 1) return { ok: false, reason: 'KYC_REQUIRED' };
  return { ok: true };
}

export function canWithdraw() {
  const s = load();
  if (s.selfExcluded) return { ok: false, reason: 'SELF_EXCLUDED' };
  if (s.kycLevel < 2) return { ok: false, reason: 'KYC_LEVEL_2_REQUIRED' };
  return { ok: true };
}

export function canBet({ amount } = {}) {
  const s = load();
  if (s.selfExcluded) return { ok: false, reason: 'SELF_EXCLUDED' };
  if (!s.acceptedTerms) return { ok: false, reason: 'TERMS_NOT_ACCEPTED' };
  // V0.2 will check dailyLimit / sessionLimitMin against ledger replay
  return { ok: true };
}

export function canPlay() {
  const s = load();
  if (s.selfExcluded) return { ok: false, reason: 'SELF_EXCLUDED' };
  return { ok: true };
}

/* Responsible gaming presets (RG) */
export const RG_PRESETS = {
  COOLDOWN_24H: 24 * 60 * 60 * 1000,
  COOLDOWN_7D:   7 * 24 * 60 * 60 * 1000,
  COOLDOWN_30D: 30 * 24 * 60 * 60 * 1000,
};

export function applyTimeout(ms) {
  setStatus({
    selfExcluded: true,
    selfExclusionUntil: new Date(Date.now() + ms).toISOString(),
  });
}
