import { appendEntry } from './ledger';
import { isFeatureEnabled } from '@/lib/config';

/**
 * AURUM AUDIT LAYER
 *
 * Sits on top of the existing hash-chain ledger to capture full round
 * context: which game, who played, what they bet, what came out, what
 * was paid, and what the balance looked like immediately before and
 * after. The point is *traceability*: any auditor (internal QA today,
 * regulator tomorrow) can replay the history from these entries alone.
 *
 * The underlying `services/ledger.js` is already append-only with a
 * SHA-256 chain. This module adds a typed wrapper so all rounds write
 * consistently shaped records.
 *
 * Idempotency: each round is identified by `roundId`. Calling
 * `auditRound` twice with the same roundId is a programming error —
 * the round is meant to settle exactly once. We don't deduplicate here;
 * the wallet-level idempotency key is the gate.
 */

/**
 * Write a single round-resolution audit event.
 *
 *   gameId        'roulette' | 'blackjack' | 'slots'
 *   roundId       stable round identifier (string)
 *   accountId     player id
 *   bets          { type, amount, label, numbers? }[]   — what was wagered
 *   stake         total amount staked across all bets (string)
 *   result        game-specific (e.g. roulette number, slots view)
 *   payout        gross amount returned to player (string)
 *   outcome       'WIN' | 'LOSS' | 'PUSH'
 *   balanceBefore decimal-string snapshot
 *   balanceAfter  decimal-string snapshot
 *
 * The function never throws on a disabled audit flag — it just returns
 * a no-op record. Audit can be force-disabled via the feature flag.
 */
export async function auditRound({
  gameId, roundId, accountId,
  bets, stake, result, payout, outcome,
  balanceBefore, balanceAfter,
  extra = {},
}) {
  if (!isFeatureEnabled('auditLedger')) {
    return { ok: false, reason: 'AUDIT_DISABLED' };
  }
  const ts = new Date().toISOString();
  const summary = JSON.stringify({
    g: gameId, r: roundId, o: outcome,
    s: stake, p: payout, res: serializeResult(result),
  });
  // We piggy-back on the existing ledger chain so the audit entry is
  // hash-linked to all wallet movements. Replay from the same source.
  try {
    const entry = await appendEntry({
      accountId,
      type: 'ROUND_AUDIT',
      amount: '0',
      meta: {
        gameId, roundId, ts,
        bets: serializeBets(bets),
        result: serializeResult(result),
        stake, payout, outcome,
        balanceBefore, balanceAfter,
        summary,
        ...extra,
      },
    });
    return { ok: true, entry };
  } catch (e) {
    if (typeof console !== 'undefined') {
      console.warn('[AURUM audit] failed to write round audit:', e?.message);
    }
    return { ok: false, reason: e?.message || 'AUDIT_WRITE_FAILED' };
  }
}

/* Result serializers — keep audit entries compact and consistent. */
function serializeResult(result) {
  if (result === null || result === undefined) return null;
  if (typeof result === 'number' || typeof result === 'string') return result;
  if (Array.isArray(result)) return result;
  // Object — strip functions, keep primitives + arrays
  try { return JSON.parse(JSON.stringify(result)); } catch { return String(result); }
}

function serializeBets(bets) {
  if (!Array.isArray(bets)) return [];
  return bets.map((b) => ({
    type: b.type || b.id,
    amount: b.amount,
    label: b.label,
    numbers: Array.isArray(b.numbers) ? b.numbers : undefined,
  }));
}
