import { D, ZERO, add, sub, gte } from './money';
import { appendEntry, listEntries } from './ledger';

/**
 * AURUM WALLET SERVICE
 *
 * Three balances per account (all Decimal strings):
 *   - available    funds the user can spend
 *   - locked       funds reserved by an open bet (cannot be withdrawn)
 *   - lifetime     cumulative deposits ever made (informational)
 *
 * Operations are async because each writes to the ledger (SHA-256 = WebCrypto).
 * Each op:
 *   1. Validates pre-conditions
 *   2. Writes a ledger entry (idempotent)
 *   3. Mutates the balances passed in via a callback (transactional)
 *
 * The store is the source of truth for current balances; the ledger is the
 * source of truth for history. They must always agree (verifiable via replay).
 */

const initial = () => ({
  available: '0',
  locked:    '0',
  lifetime:  '0',
});

export const initialBalances = initial();

/* ----------------------------------------------------------------- */
/*  Replay — rebuild balances from ledger (auditable)                 */
/* ----------------------------------------------------------------- */

export function replay(accountId) {
  const entries = listEntries(accountId);
  let available = ZERO, locked = ZERO, lifetime = ZERO;
  for (const e of entries) {
    const a = D(e.amount);
    switch (e.type) {
      case 'DEPOSIT':
        available = add(available, a);
        lifetime  = add(lifetime, a);
        break;
      case 'WITHDRAW':
        available = sub(available, a);
        break;
      case 'BET_LOCK':
        available = sub(available, a);
        locked    = add(locked, a);
        break;
      case 'BET_SETTLE': {
        // meta.outcome: 'WIN' | 'LOSS' | 'PUSH'
        // amount is the original stake; meta.payout is the resolved gross payout.
        const outcome = e.meta?.outcome;
        const payout  = D(e.meta?.payout || 0);
        locked = sub(locked, a);
        if (outcome === 'WIN' || outcome === 'PUSH') {
          available = add(available, payout);
        }
        break;
      }
      case 'BONUS':
        available = add(available, a);
        break;
      case 'ADJUSTMENT':
        available = add(available, a); // signed amount in meta if needed
        break;
    }
  }
  return {
    available: available.toFixed(),
    locked:    locked.toFixed(),
    lifetime:  lifetime.toFixed(),
  };
}

/* ----------------------------------------------------------------- */
/*  Operations                                                        */
/* ----------------------------------------------------------------- */

export async function deposit({ accountId, amount, idempotencyKey, meta = {} }) {
  if (!gte(amount, '0.01')) throw new Error('WALLET: deposit must be ≥ 0.01');
  return appendEntry({ accountId, type: 'DEPOSIT', amount, idempotencyKey, meta });
}

export async function withdraw({ accountId, amount, idempotencyKey, balances, meta = {} }) {
  if (!gte(amount, '0.01'))                throw new Error('WALLET: withdraw must be ≥ 0.01');
  if (!gte(balances.available, amount))    throw new Error('WALLET: insufficient available funds');
  return appendEntry({ accountId, type: 'WITHDRAW', amount, idempotencyKey, meta });
}

export async function lockBet({ accountId, amount, idempotencyKey, balances, meta = {} }) {
  if (!gte(amount, '0.01'))                throw new Error('WALLET: bet must be ≥ 0.01');
  if (!gte(balances.available, amount))    throw new Error('WALLET: insufficient funds for bet');
  return appendEntry({ accountId, type: 'BET_LOCK', amount, idempotencyKey, meta });
}

export async function settleBet({ accountId, stake, payout, outcome, idempotencyKey, meta = {} }) {
  if (!['WIN', 'LOSS', 'PUSH'].includes(outcome)) throw new Error('WALLET: outcome invalid');
  return appendEntry({
    accountId,
    type: 'BET_SETTLE',
    amount: stake,
    idempotencyKey,
    meta: { ...meta, outcome, payout: payout?.toString?.() ?? String(payout ?? 0) },
  });
}

export async function bonus({ accountId, amount, idempotencyKey, meta = {} }) {
  return appendEntry({ accountId, type: 'BONUS', amount, idempotencyKey, meta });
}
