/**
 * AURUM PAYMENTS — Public entrypoint
 *
 * Import the registry definitions, then side-effect-import every built-in
 * adapter so the registry is populated by the time any consumer reads it.
 * Re-export the public API from `./adapter`.
 *
 * Consumers should ALWAYS import from this file:
 *
 *   import { list, get, register, PaymentNotActivated } from '@/services/payments';
 *
 * Importing directly from `./adapter` will NOT trigger the bootstrap and
 * the registry will be empty. The deposit/withdraw pages, the wallet,
 * and any future code that needs the registry MUST go through this index.
 *
 * Why this exists: ES module side-effect imports inside `adapter.js`
 * created a circular dependency that broke `register` at load time.
 * Splitting the bootstrap out of the registry module gives us a single
 * deterministic order: registry first, adapters second.
 */

// 1. Define the registry (must run before any child calls register())
export * from './adapter';

// 2. Bootstrap built-in adapters. Order doesn't matter — each one calls
//    register() with a unique id.
import './simulated';
import './card';
import './paypal';
import './sepa';
