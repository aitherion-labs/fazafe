import { register } from './adapter';
import { newKey } from '../idempotency';
import { deposit as walletDeposit, withdraw as walletWithdraw } from '../wallet';

/**
 * Card adapter (V0.4 — SIMULATED).
 *
 * This adapter behaves like a real payment processor would: it takes a
 * card payload, simulates an authorization round-trip, and on success
 * writes a ledger entry with `meta.method = 'card'` and `meta.simulated`.
 *
 * Real PCI integration (Stripe/Adyen/etc.) will replace the body of
 * `deposit()` and `withdraw()` in the RC release. The contract stays.
 *
 * The deposit page calls this adapter with no card payload because the
 * UI form already simulated the auth delay before calling us.
 */
register({
  id: 'card',
  label: 'International Card',
  regions: ['*'],
  isActive: true,
  deposit: async ({ accountId, amount }) => {
    const key = newKey('card_dep');
    await walletDeposit({
      accountId,
      amount,
      idempotencyKey: key,
      meta: { simulated: true, method: 'card' },
    });
    return { ok: true, ref: key };
  },
  withdraw: async ({ accountId, amount, balances }) => {
    const key = newKey('card_wd');
    await walletWithdraw({
      accountId,
      amount,
      balances,
      idempotencyKey: key,
      meta: { simulated: true, method: 'card' },
    });
    return { ok: true, ref: key };
  },
});
