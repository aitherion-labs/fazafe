import { register, PaymentNotActivated } from './adapter';

register({
  id: 'sepa',
  label: 'Virement SEPA',
  regions: ['EU'],
  isActive: false,
  deposit:  async () => { throw new PaymentNotActivated('sepa'); },
  withdraw: async () => { throw new PaymentNotActivated('sepa'); },
});
