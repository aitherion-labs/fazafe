# services/payments — ARCHITECTED, NOT ACTIVE

> 🚨 **Real money does NOT move through this code in V0.1.** 🚨

This folder defines the **shape** of the payment integration layer that
will go live at RC. Until then:

- All non-simulated adapters throw `PaymentNotActivated`
- The `simulated` adapter is the only one that mutates the ledger
- Every simulated entry is tagged `meta.simulated = true`

## Activation checklist (before flipping `isActive: true`)

- [ ] Legal review (jurisdiction-by-jurisdiction)
- [ ] PCI-DSS scope assessment (for card)
- [ ] Gateway homologation (Stripe / Adyen / Worldpay / etc.)
- [ ] KYC integration (Onfido / Sumsub / Veriff) wired to compliance.canDeposit / canWithdraw
- [ ] AML transaction monitoring (rules + suspicious-activity reporting)
- [ ] PSD2 SCA / 3DS2 flows for EU
- [ ] Webhook endpoint + signature verification
- [ ] Idempotency keys round-trip end-to-end
- [ ] Reconciliation job (gateway ↔ ledger)
- [ ] Disaster-recovery + chargeback handling
- [ ] Insurance + segregated client-funds account
- [ ] Independent security audit
- [ ] Bug-bounty program live

Until **every** box is checked, do not change `isActive` on any adapter
other than `simulated`.
