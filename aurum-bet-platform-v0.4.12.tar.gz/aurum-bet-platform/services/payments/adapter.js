/* eslint-disable no-unused-vars */

/**
 * AURUM PAYMENTS — Adapter Pattern
 * ============================================================
 * 🚨  THIS LAYER IS ARCHITECTED, NOT ACTIVE.  🚨
 * ============================================================
 *
 * No real money moves through this code in V0.1.
 * Every adapter throws `PaymentNotActivated` until the RC release,
 * after legal review, gateway homologation, KYC integration and
 * security audit are complete.
 *
 * To activate:
 *   1. Replace each adapter stub with the gateway SDK call
 *   2. Wrap every call with idempotency + ledger writes
 *   3. Ensure compliance gates pass (see services/compliance.js)
 *   4. Add server-side webhook verification
 *   5. Add 3DS / SCA flows where required (PSD2)
 *
 * Until then, the WALLET screens use the SimulatedAdapter, which
 * writes a 'DEPOSIT' / 'WITHDRAW' ledger entry tagged with
 * `meta.simulated = true` so it can never be confused with a real
 * payment in audit.
 */

export class PaymentNotActivated extends Error {
  constructor(method) { super(`Payment method "${method}" is not activated in V0.1`); this.method = method; }
}

/**
 * Interface every adapter implements.
 *
 *   adapter.id       string
 *   adapter.label    display name
 *   adapter.regions  ISO-3166 country codes supported
 *   adapter.deposit({ amount, currency, account })   → Promise<{ ok, ref }>
 *   adapter.withdraw({ amount, currency, account })  → Promise<{ ok, ref }>
 *   adapter.isActive boolean
 */

const _registry = new Map();
export const register = (adapter) => _registry.set(adapter.id, adapter);
export const get = (id) => _registry.get(id);
export const list = () => Array.from(_registry.values());

/*
 * NOTE — the four built-in adapters (card / paypal / sepa / simulated)
 * are bootstrapped in `services/payments/index.js`. Do NOT side-effect-
 * import them here: doing so creates a circular dependency at module
 * load time (each child does `import { register } from './adapter'`
 * before the body of this module has run, hitting the temporal dead
 * zone for `register`).
 *
 * Code that needs the registry populated should import from
 * `@/services/payments` (the index re-exports the public API).
 */
