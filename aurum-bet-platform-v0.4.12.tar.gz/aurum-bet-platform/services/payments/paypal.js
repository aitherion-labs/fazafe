import { register, PaymentNotActivated } from './adapter';

register({
  id: 'paypal',
  label: 'PayPal',
  regions: ['*'],
  isActive: false,
  deposit:  async () => { throw new PaymentNotActivated('paypal'); },
  withdraw: async () => { throw new PaymentNotActivated('paypal'); },
});
