import { register } from './adapter';
import { newKey } from '../idempotency';
import { deposit as walletDeposit, withdraw as walletWithdraw } from '../wallet';

/**
 * Simulated adapter — for V0.1 only.
 * Every entry it writes carries `meta.simulated = true`,
 * making it impossible to confuse with real funds in audit replay.
 */
register({
  id: 'simulated',
  label: 'Instant Demo Credit',
  regions: ['*'],
  isActive: true,
  deposit: async ({ accountId, amount }) => {
    const key = newKey('sim_dep');
    await walletDeposit({ accountId, amount, idempotencyKey: key, meta: { simulated: true } });
    return { ok: true, ref: key };
  },
  withdraw: async ({ accountId, amount, balances }) => {
    const key = newKey('sim_wd');
    await walletWithdraw({ accountId, amount, balances, idempotencyKey: key, meta: { simulated: true } });
    return { ok: true, ref: key };
  },
});
