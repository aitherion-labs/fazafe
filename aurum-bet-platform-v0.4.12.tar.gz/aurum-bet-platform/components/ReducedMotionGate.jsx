'use client';

import { useEffect, useState } from 'react';
import { useAurumStore } from '@/store/useAurumStore';

/**
 * AURUM REDUCED-MOTION GATE
 *
 * Reads the OS-level `prefers-reduced-motion` media query and writes
 * the result into the store. Components can subscribe to
 * `useAurumStore(s => s.reducedMotion)` and either:
 *   - swap framer animations for instant transitions, or
 *   - replace canvas-heavy scenes with a static image / minimal SVG
 *
 * Also adds the `data-reduced-motion="true"` attribute on <body>
 * so CSS can disable expensive animations globally:
 *
 *   body[data-reduced-motion="true"] * {
 *     animation-duration: 0.01ms !important;
 *     transition-duration: 0.01ms !important;
 *   }
 */
export default function ReducedMotionGate() {
  const setRM = useAurumStore((s) => s.setReducedMotion);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    const apply = (matches) => {
      setRM(matches);
      document.body.setAttribute('data-reduced-motion', String(matches));
    };
    apply(mq.matches);
    const handler = (e) => apply(e.matches);
    mq.addEventListener?.('change', handler);
    return () => mq.removeEventListener?.('change', handler);
  }, [setRM]);

  return null;
}
