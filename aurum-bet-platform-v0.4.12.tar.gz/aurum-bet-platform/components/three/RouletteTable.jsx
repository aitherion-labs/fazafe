'use client';

import { useMemo } from 'react';
import * as THREE from 'three';

/**
 * Procedural roulette table.
 * - Mahogany/oak base with brass corner caps
 * - Green felt with subtle texture (procedural noise via canvas)
 * - Brass divider rails
 * - Subtle inset bevel
 */
export default function RouletteTable({ position = [0, 0, 0] }) {
  // Procedural felt texture (canvas → DataTexture)
  const feltMap = useMemo(() => {
    if (typeof document === 'undefined') return null;
    const c = document.createElement('canvas');
    c.width = 512; c.height = 512;
    const ctx = c.getContext('2d');
    // base green
    ctx.fillStyle = '#1A3A2A';
    ctx.fillRect(0, 0, 512, 512);
    // weave noise
    for (let i = 0; i < 18000; i++) {
      ctx.fillStyle = `rgba(${20 + Math.random() * 25},${50 + Math.random() * 30},${30 + Math.random() * 25},0.5)`;
      ctx.fillRect(Math.random() * 512, Math.random() * 512, 1, 1);
    }
    // soft vignette
    const grd = ctx.createRadialGradient(256, 256, 80, 256, 256, 360);
    grd.addColorStop(0, 'rgba(0,0,0,0)');
    grd.addColorStop(1, 'rgba(0,0,0,0.45)');
    ctx.fillStyle = grd;
    ctx.fillRect(0, 0, 512, 512);
    const tex = new THREE.CanvasTexture(c);
    tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
    tex.anisotropy = 8;
    return tex;
  }, []);

  // Mahogany texture (procedural)
  const woodMap = useMemo(() => {
    if (typeof document === 'undefined') return null;
    const c = document.createElement('canvas');
    c.width = 512; c.height = 128;
    const ctx = c.getContext('2d');
    const grad = ctx.createLinearGradient(0, 0, 0, 128);
    grad.addColorStop(0,    '#3A1810');
    grad.addColorStop(0.5,  '#2A0E08');
    grad.addColorStop(1,    '#1A0604');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 512, 128);
    // grain lines
    for (let i = 0; i < 60; i++) {
      ctx.strokeStyle = `rgba(${40 + Math.random() * 30},${15 + Math.random() * 15},${5 + Math.random() * 10},0.5)`;
      ctx.lineWidth = 0.4 + Math.random() * 0.6;
      ctx.beginPath();
      const y = Math.random() * 128;
      ctx.moveTo(0, y);
      ctx.bezierCurveTo(170, y + (Math.random() - 0.5) * 10, 340, y + (Math.random() - 0.5) * 10, 512, y + (Math.random() - 0.5) * 10);
      ctx.stroke();
    }
    const tex = new THREE.CanvasTexture(c);
    tex.wrapS = THREE.RepeatWrapping;
    tex.repeat.set(2, 1);
    return tex;
  }, []);

  return (
    <group position={position}>
      {/* TABLE TOP (oval) */}
      <mesh receiveShadow position={[0, 0, 0]}>
        <cylinderGeometry args={[3.4, 3.4, 0.18, 96]} />
        <meshStandardMaterial map={woodMap} color="#2A0E08" metalness={0.15} roughness={0.55} />
      </mesh>

      {/* FELT INSET */}
      <mesh receiveShadow position={[0, 0.095, 0]}>
        <cylinderGeometry args={[3.05, 3.05, 0.02, 96]} />
        <meshStandardMaterial map={feltMap} color="#2A5A40" roughness={1.0} metalness={0.0} />
      </mesh>

      {/* BRASS RIM */}
      <mesh position={[0, 0.1, 0]}>
        <torusGeometry args={[3.18, 0.04, 16, 96]} />
        <meshStandardMaterial color="#C8A24A" metalness={1} roughness={0.2} envMapIntensity={1.2} />
      </mesh>
      <mesh position={[0, 0.1, 0]}>
        <torusGeometry args={[3.4, 0.05, 16, 96]} />
        <meshStandardMaterial color="#7A5C18" metalness={1} roughness={0.35} />
      </mesh>

      {/* LEATHER ARMREST */}
      <mesh position={[0, 0.05, 0]} receiveShadow>
        <torusGeometry args={[3.32, 0.1, 24, 96]} />
        <meshStandardMaterial color="#1A0E0A" metalness={0.0} roughness={0.85} />
      </mesh>

      {/* PROCEDURAL BETTING LAYOUT (numbers grid) — flattened plane */}
      <BetGrid position={[0, 0.105, 1.2]} />

      {/* TABLE LEGS */}
      {[0, Math.PI / 2, Math.PI, 3 * Math.PI / 2].map((a, i) => (
        <mesh
          key={i}
          position={[Math.cos(a) * 2.6, -1.15, Math.sin(a) * 2.6]}
          castShadow
        >
          <cylinderGeometry args={[0.12, 0.18, 2.4, 16]} />
          <meshStandardMaterial color="#1A0604" metalness={0.2} roughness={0.6} />
        </mesh>
      ))}
    </group>
  );
}

/* Procedural betting grid plane */
function BetGrid({ position }) {
  const map = useMemo(() => {
    if (typeof document === 'undefined') return null;
    const c = document.createElement('canvas');
    c.width = 1024; c.height = 384;
    const ctx = c.getContext('2d');
    // base felt
    ctx.fillStyle = '#1F4A3A';
    ctx.fillRect(0, 0, 1024, 384);
    // 3 rows × 12 cols
    const cellW = 80, cellH = 88;
    const startX = 80, startY = 32;
    const REDS = new Set([1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36]);

    // 0 column
    ctx.fillStyle = '#0E4A2A';
    ctx.fillRect(0, startY, startX, cellH * 3);
    ctx.strokeStyle = '#C8A24A';
    ctx.lineWidth = 2;
    ctx.strokeRect(0, startY, startX, cellH * 3);
    ctx.font = 'italic 56px "Cormorant Garamond", serif';
    ctx.fillStyle = '#F4D78A';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('0', startX / 2, startY + (cellH * 3) / 2);

    // numbers 1-36
    for (let n = 1; n <= 36; n++) {
      const col = Math.floor((n - 1) / 3);
      const row = 2 - ((n - 1) % 3);
      const x = startX + col * cellW;
      const y = startY + row * cellH;
      ctx.fillStyle = REDS.has(n) ? '#7A0E14' : '#0A0608';
      ctx.fillRect(x, y, cellW, cellH);
      ctx.strokeStyle = '#C8A24A';
      ctx.lineWidth = 1;
      ctx.strokeRect(x, y, cellW, cellH);
      ctx.fillStyle = '#F4D78A';
      ctx.font = '600 32px "Inter Tight", sans-serif';
      ctx.fillText(String(n), x + cellW / 2, y + cellH / 2);
    }

    // outer bets row
    const outerY = startY + cellH * 3;
    ['1-18', 'PAIR', 'ROUGE', 'NOIR', 'IMPAIR', '19-36'].forEach((label, i) => {
      const x = startX + i * (cellW * 2);
      ctx.fillStyle = i === 2 ? '#7A0E14' : i === 3 ? '#0A0608' : '#1F4A3A';
      ctx.fillRect(x, outerY, cellW * 2, 70);
      ctx.strokeStyle = '#C8A24A';
      ctx.strokeRect(x, outerY, cellW * 2, 70);
      ctx.fillStyle = '#F4D78A';
      ctx.font = '500 22px "Inter Tight", sans-serif';
      ctx.fillText(label, x + cellW, outerY + 38);
    });

    // grain
    for (let i = 0; i < 6000; i++) {
      ctx.fillStyle = `rgba(0,0,0,${Math.random() * 0.3})`;
      ctx.fillRect(Math.random() * 1024, Math.random() * 384, 1, 1);
    }

    const tex = new THREE.CanvasTexture(c);
    tex.anisotropy = 8;
    return tex;
  }, []);

  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={position} receiveShadow>
      <planeGeometry args={[3.2, 1.2]} />
      <meshStandardMaterial map={map} roughness={0.95} metalness={0.0} />
    </mesh>
  );
}
