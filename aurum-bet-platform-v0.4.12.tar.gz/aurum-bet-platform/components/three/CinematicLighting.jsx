'use client';

import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

/**
 * Three-point cinematic lighting.
 *
 * - KEY:   warm tungsten directional from top-front
 * - FILL:  cool soft directional from opposite side, low intensity
 * - RIM:   amber back-light to separate subject from background
 * - AMBIENT: very low to keep shadows alive
 *
 * Optional flicker: subtly modulates KEY intensity to feel alive.
 */
export default function CinematicLighting({
  keyColor   = '#FFC68A',
  fillColor  = '#5A7A9A',
  rimColor   = '#F4D78A',
  intensity  = 1.0,
  flicker    = true,
}) {
  const keyRef = useRef();

  useFrame(({ clock }) => {
    if (!flicker || !keyRef.current) return;
    const t = clock.elapsedTime;
    // organic flicker via summed sines
    const f = 1.0
      + Math.sin(t * 2.3) * 0.015
      + Math.sin(t * 7.1) * 0.008
      + Math.sin(t * 13.7) * 0.004;
    keyRef.current.intensity = 2.4 * intensity * f;
  });

  return (
    <>
      {/* Ambient — barely there, just to keep shadows from going pure black */}
      <ambientLight color="#1A1426" intensity={0.18} />

      {/* Hemisphere — natural sky/ground bounce */}
      <hemisphereLight
        color="#3A2E22"
        groundColor="#08060C"
        intensity={0.25}
      />

      {/* KEY light — warm tungsten from above */}
      <directionalLight
        ref={keyRef}
        color={keyColor}
        intensity={2.4 * intensity}
        position={[4, 8, 5]}
        castShadow
        shadow-mapSize={[2048, 2048]}
        shadow-bias={-0.0005}
        shadow-camera-far={30}
        shadow-camera-left={-10}
        shadow-camera-right={10}
        shadow-camera-top={10}
        shadow-camera-bottom={-10}
      />

      {/* FILL light — cool, opposite side, soft */}
      <directionalLight
        color={fillColor}
        intensity={0.45 * intensity}
        position={[-6, 4, 3]}
      />

      {/* RIM light — amber back-light for separation */}
      <directionalLight
        color={rimColor}
        intensity={1.8 * intensity}
        position={[0, 3, -6]}
      />

      {/* SPOT — concentrated cone from above the focal point */}
      <spotLight
        color={keyColor}
        intensity={3.0 * intensity}
        position={[0, 7, 0.5]}
        angle={0.55}
        penumbra={0.85}
        distance={20}
        decay={1.5}
        castShadow
      />
    </>
  );
}
