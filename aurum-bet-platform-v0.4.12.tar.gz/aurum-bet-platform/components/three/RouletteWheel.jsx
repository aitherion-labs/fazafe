'use client';

import { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

/**
 * Procedural roulette wheel.
 * - Outer rim: brushed gold
 * - Track: deep mahogany with chrome ridges
 * - Bowl: 37 alternating black/red pockets + green zero
 * - Spinning hub with cross-bar
 * - Ball orbiting in track
 *
 * No external models required.
 *
 * Props:
 *   isSpinning: boolean — when true the wheel & ball spin fast; otherwise
 *                         a slow idle rotation. Defaults to false so the
 *                         wheel works as a passive background prop too.
 */
export default function RouletteWheel({
  position   = [0, 0.5, 0],
  scale      = 1,
  isSpinning = false,
}) {
  const wheelRef     = useRef();
  const ballRef      = useRef();
  const ballAngleRef = useRef(0);

  // ---- materials ----
  const goldMat = useMemo(() => new THREE.MeshStandardMaterial({
    color: '#C8A24A',
    metalness: 0.95,
    roughness: 0.18,
    envMapIntensity: 1.4,
  }), []);

  const goldHiMat = useMemo(() => new THREE.MeshStandardMaterial({
    color: '#F4D78A',
    metalness: 1.0,
    roughness: 0.12,
    envMapIntensity: 1.6,
    emissive: '#3A2A0A',
    emissiveIntensity: 0.15,
  }), []);

  const woodMat = useMemo(() => new THREE.MeshStandardMaterial({
    color: '#2A0E08',
    metalness: 0.1,
    roughness: 0.45,
  }), []);

  const blackPocketMat = useMemo(() => new THREE.MeshStandardMaterial({
    color: '#0A0608',
    metalness: 0.3,
    roughness: 0.55,
  }), []);

  const redPocketMat = useMemo(() => new THREE.MeshStandardMaterial({
    color: '#7A0E14',
    metalness: 0.25,
    roughness: 0.55,
  }), []);

  const greenPocketMat = useMemo(() => new THREE.MeshStandardMaterial({
    color: '#0E4A2A',
    metalness: 0.25,
    roughness: 0.55,
  }), []);

  // standard european wheel order
  const POCKETS = useMemo(() => [
    0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 10,
    5, 24, 16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26,
  ], []);
  const REDS = useMemo(() => new Set(
    [1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36]
  ), []);

  useFrame((_, dt) => {
    if (!wheelRef.current) return;
    const speed = isSpinning ? 4.0 : 0.18;
    wheelRef.current.rotation.y -= speed * dt;

    if (ballRef.current) {
      ballAngleRef.current += (isSpinning ? 6.0 : 0.4) * dt;
      const r = 1.55 * scale;
      ballRef.current.position.x = Math.cos(ballAngleRef.current) * r;
      ballRef.current.position.z = Math.sin(ballAngleRef.current) * r;
      ballRef.current.position.y = 0.18 * scale;
    }
  });

  return (
    <group position={position} scale={scale}>
      {/* OUTER STATIC RIM (brushed gold) */}
      <mesh material={goldMat} castShadow receiveShadow>
        <torusGeometry args={[1.95, 0.18, 32, 96]} />
      </mesh>
      <mesh material={goldHiMat} position={[0, 0.07, 0]}>
        <torusGeometry args={[1.95, 0.06, 24, 96]} />
      </mesh>

      {/* TRACK — wooden bowl where ball spins */}
      <mesh material={woodMat} position={[0, -0.05, 0]} receiveShadow>
        <cylinderGeometry args={[1.78, 1.85, 0.12, 96]} />
      </mesh>
      {/* chrome ridges on track */}
      {Array.from({ length: 8 }).map((_, i) => {
        const a = (i * Math.PI * 2) / 8;
        return (
          <mesh
            key={i}
            material={goldHiMat}
            position={[Math.cos(a) * 1.78, 0.02, Math.sin(a) * 1.78]}
            rotation={[0, -a, 0]}
            castShadow
          >
            <boxGeometry args={[0.08, 0.06, 0.12]} />
          </mesh>
        );
      })}

      {/* SPINNING WHEEL */}
      <group ref={wheelRef}>
        {/* base disc */}
        <mesh material={woodMat} position={[0, -0.08, 0]} receiveShadow>
          <cylinderGeometry args={[1.55, 1.55, 0.16, 96]} />
        </mesh>
        {/* gold rim of inner disc */}
        <mesh material={goldMat} position={[0, 0, 0]}>
          <torusGeometry args={[1.55, 0.04, 24, 96]} />
        </mesh>

        {/* 37 pockets */}
        {POCKETS.map((num, i) => {
          const a = (i * Math.PI * 2) / 37;
          const isRed   = REDS.has(num);
          const isZero  = num === 0;
          const mat = isZero ? greenPocketMat : isRed ? redPocketMat : blackPocketMat;
          return (
            <group key={i} rotation={[0, a, 0]}>
              {/* pocket wedge */}
              <mesh material={mat} position={[1.32, 0.02, 0]} castShadow>
                <boxGeometry args={[0.4, 0.12, 0.22]} />
              </mesh>
              {/* gold separator fin */}
              <mesh material={goldHiMat} position={[1.32, 0.06, 0.12]}>
                <boxGeometry args={[0.4, 0.04, 0.012]} />
              </mesh>
              {/* number plate (subtle) */}
              <mesh position={[1.42, 0.085, 0]} rotation={[-Math.PI / 2, 0, 0]}>
                <planeGeometry args={[0.12, 0.18]} />
                <meshBasicMaterial color={isZero ? '#E8DCB0' : '#F4D78A'} transparent opacity={0.85} />
              </mesh>
            </group>
          );
        })}

        {/* HUB */}
        <mesh material={goldMat} position={[0, 0.18, 0]} castShadow>
          <cylinderGeometry args={[0.55, 0.65, 0.32, 32]} />
        </mesh>
        <mesh material={goldHiMat} position={[0, 0.36, 0]}>
          <cylinderGeometry args={[0.42, 0.55, 0.04, 32]} />
        </mesh>
        <mesh material={goldMat} position={[0, 0.6, 0]} castShadow>
          <cylinderGeometry args={[0.06, 0.08, 0.5, 16]} />
        </mesh>
        <mesh material={goldHiMat} position={[0, 0.86, 0]}>
          <sphereGeometry args={[0.12, 24, 24]} />
        </mesh>

        {/* Cross arms (spider) */}
        {Array.from({ length: 4 }).map((_, i) => (
          <mesh
            key={i}
            material={goldMat}
            rotation={[0, (i * Math.PI) / 2, 0]}
            position={[0, 0.5, 0]}
            castShadow
          >
            <boxGeometry args={[1.0, 0.04, 0.06]} />
          </mesh>
        ))}
      </group>

      {/* BALL */}
      <mesh ref={ballRef} castShadow>
        <sphereGeometry args={[0.06, 16, 16]} />
        <meshStandardMaterial
          color="#FFF8E0"
          metalness={0.1}
          roughness={0.25}
          emissive="#FFE9B0"
          emissiveIntensity={0.25}
        />
      </mesh>
    </group>
  );
}
