'use client';

import { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

/**
 * Procedural lobby room — architectural shell.
 * - Marble floor (procedural texture, polished)
 * - Velvet walls (deep purple-black with subtle column relief)
 * - Coffered ceiling with hanging chandelier hint
 * - Three plinths in a semi-circle for the portals
 */
export default function LobbyRoom() {
  // ---- Procedural marble floor ----
  const marbleMap = useMemo(() => {
    if (typeof document === 'undefined') return null;
    const c = document.createElement('canvas');
    c.width = 1024; c.height = 1024;
    const ctx = c.getContext('2d');
    // base
    ctx.fillStyle = '#0E0A14';
    ctx.fillRect(0, 0, 1024, 1024);
    // deep purple veining
    for (let i = 0; i < 25; i++) {
      ctx.strokeStyle = `rgba(${30 + Math.random() * 40}, ${20 + Math.random() * 30}, ${50 + Math.random() * 40}, ${0.15 + Math.random() * 0.25})`;
      ctx.lineWidth = 0.5 + Math.random() * 1.5;
      ctx.beginPath();
      const sx = Math.random() * 1024;
      const sy = Math.random() * 1024;
      ctx.moveTo(sx, sy);
      for (let j = 0; j < 6; j++) {
        ctx.lineTo(sx + (Math.random() - 0.5) * 600, sy + (Math.random() - 0.5) * 600);
      }
      ctx.stroke();
    }
    // gold flecks
    for (let i = 0; i < 200; i++) {
      ctx.fillStyle = `rgba(244, 215, 138, ${0.1 + Math.random() * 0.3})`;
      ctx.beginPath();
      ctx.arc(Math.random() * 1024, Math.random() * 1024, 0.4 + Math.random() * 1.2, 0, Math.PI * 2);
      ctx.fill();
    }
    const tex = new THREE.CanvasTexture(c);
    tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(4, 4);
    tex.anisotropy = 8;
    return tex;
  }, []);

  // ---- Velvet wall texture ----
  const velvetMap = useMemo(() => {
    if (typeof document === 'undefined') return null;
    const c = document.createElement('canvas');
    c.width = 512; c.height = 512;
    const ctx = c.getContext('2d');
    const grd = ctx.createLinearGradient(0, 0, 0, 512);
    grd.addColorStop(0,    '#1A0E18');
    grd.addColorStop(0.5,  '#0E0814');
    grd.addColorStop(1,    '#05040A');
    ctx.fillStyle = grd;
    ctx.fillRect(0, 0, 512, 512);
    // velvet pile noise
    for (let i = 0; i < 12000; i++) {
      ctx.fillStyle = `rgba(${20 + Math.random() * 30}, ${10 + Math.random() * 15}, ${25 + Math.random() * 30}, 0.4)`;
      ctx.fillRect(Math.random() * 512, Math.random() * 512, 1, 1);
    }
    const tex = new THREE.CanvasTexture(c);
    tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(2, 2);
    return tex;
  }, []);

  return (
    <group>
      {/* FLOOR */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]} receiveShadow>
        <planeGeometry args={[40, 40]} />
        <meshStandardMaterial
          map={marbleMap}
          color="#1A1428"
          roughness={0.18}
          metalness={0.45}
          envMapIntensity={1.0}
        />
      </mesh>

      {/* SUBTLE FLOOR REFLECTION GLINT (a soft additive layer) */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.001, -2]}>
        <circleGeometry args={[6, 64]} />
        <meshBasicMaterial
          color="#F4D78A"
          transparent
          opacity={0.05}
          blending={THREE.AdditiveBlending}
        />
      </mesh>

      {/* BACK WALL */}
      <mesh position={[0, 4, -10]} receiveShadow>
        <planeGeometry args={[40, 12]} />
        <meshStandardMaterial map={velvetMap} color="#15101C" roughness={0.95} metalness={0.0} />
      </mesh>

      {/* SIDE WALLS */}
      <mesh position={[-12, 4, 0]} rotation={[0, Math.PI / 2, 0]} receiveShadow>
        <planeGeometry args={[40, 12]} />
        <meshStandardMaterial map={velvetMap} color="#15101C" roughness={0.95} />
      </mesh>
      <mesh position={[12, 4, 0]} rotation={[0, -Math.PI / 2, 0]} receiveShadow>
        <planeGeometry args={[40, 12]} />
        <meshStandardMaterial map={velvetMap} color="#15101C" roughness={0.95} />
      </mesh>

      {/* CEILING */}
      <mesh rotation={[Math.PI / 2, 0, 0]} position={[0, 9, 0]}>
        <planeGeometry args={[40, 40]} />
        <meshStandardMaterial color="#0A0810" roughness={0.9} />
      </mesh>

      {/* COLUMNS — back wall ornamentation */}
      {[-7, -3.5, 0, 3.5, 7].map((x, i) => (
        <Column key={i} position={[x, 0, -9.5]} />
      ))}

      {/* PLINTHS for portals (semi-circle) */}
      <Plinth position={[-4.5, 0, -2]} />
      <Plinth position={[ 0,   0, -3]} />
      <Plinth position={[ 4.5, 0, -2]} />

      {/* CHANDELIER */}
      <Chandelier position={[0, 8.5, 0]} />
    </group>
  );
}

function Column({ position }) {
  return (
    <group position={position}>
      <mesh receiveShadow castShadow>
        <cylinderGeometry args={[0.28, 0.35, 8, 16]} />
        <meshStandardMaterial color="#1A1018" roughness={0.6} metalness={0.2} />
      </mesh>
      <mesh position={[0, 4, 0]} castShadow>
        <boxGeometry args={[0.85, 0.4, 0.85]} />
        <meshStandardMaterial color="#C8A24A" metalness={0.95} roughness={0.25} />
      </mesh>
      <mesh position={[0, -4, 0]} castShadow>
        <boxGeometry args={[0.85, 0.4, 0.85]} />
        <meshStandardMaterial color="#7A5C18" metalness={0.95} roughness={0.35} />
      </mesh>
    </group>
  );
}

function Plinth({ position }) {
  return (
    <group position={position}>
      <mesh receiveShadow castShadow position={[0, 0.1, 0]}>
        <boxGeometry args={[1.6, 0.2, 1.6]} />
        <meshStandardMaterial color="#15101C" roughness={0.5} metalness={0.3} />
      </mesh>
      <mesh receiveShadow castShadow position={[0, 0.6, 0]}>
        <cylinderGeometry args={[0.55, 0.7, 1.0, 16]} />
        <meshStandardMaterial color="#0E0A14" roughness={0.55} metalness={0.4} />
      </mesh>
      <mesh position={[0, 1.12, 0]}>
        <torusGeometry args={[0.55, 0.04, 12, 32]} />
        <meshStandardMaterial color="#F4D78A" metalness={1} roughness={0.18} />
      </mesh>
    </group>
  );
}

function Chandelier({ position }) {
  const ref = useRef();
  useFrame(({ clock }) => {
    if (ref.current) {
      ref.current.rotation.y = clock.elapsedTime * 0.05;
      ref.current.position.y = position[1] + Math.sin(clock.elapsedTime * 0.4) * 0.02;
    }
  });
  return (
    <group ref={ref} position={position}>
      {/* central hub */}
      <mesh>
        <sphereGeometry args={[0.18, 16, 16]} />
        <meshStandardMaterial color="#C8A24A" metalness={1} roughness={0.2} />
      </mesh>
      {/* hanging crystals (12 around) */}
      {Array.from({ length: 12 }).map((_, i) => {
        const a = (i * Math.PI * 2) / 12;
        const r = 0.7;
        return (
          <group key={i} position={[Math.cos(a) * r, -0.3, Math.sin(a) * r]}>
            <mesh>
              <octahedronGeometry args={[0.08, 0]} />
              <meshStandardMaterial
                color="#FFF1C7"
                metalness={0.4}
                roughness={0.05}
                emissive="#F4D78A"
                emissiveIntensity={0.6}
              />
            </mesh>
            <pointLight color="#FFC68A" intensity={0.4} distance={3} decay={2} />
          </group>
        );
      })}
    </group>
  );
}
