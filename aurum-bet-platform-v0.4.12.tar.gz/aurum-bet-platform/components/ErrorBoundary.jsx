'use client';

import { Component } from 'react';
import Link from 'next/link';

/**
 * AURUM ERROR BOUNDARY
 *
 * Wrap any heavy 3D Canvas or game UI with this. When something inside
 * throws, we render a velvet "salon en réparation" plate instead of a
 * white screen of death.
 *
 * Usage:
 *   <ErrorBoundary fallback={<MyFallback/>}>
 *     <Canvas>...</Canvas>
 *   </ErrorBoundary>
 */
export default class ErrorBoundary extends Component {
  state = { hasError: false, error: null };

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, info) {
    if (typeof window !== 'undefined') {
      console.error('[AURUM] ErrorBoundary caught:', error, info);
    }
  }

  reset = () => this.setState({ hasError: false, error: null });

  render() {
    if (!this.state.hasError) return this.props.children;
    if (this.props.fallback) return this.props.fallback(this.state.error, this.reset);
    return <DefaultFallback error={this.state.error} reset={this.reset} />;
  }
}

function DefaultFallback({ error, reset }) {
  return (
    <div className="relative w-full min-h-screen flex items-center justify-center grain vignette p-8"
         style={{ background: 'var(--grad-velvet-vignette)' }}>
      <div className="relative max-w-md text-center velvet rounded-md p-10 gold-frame">
        <div className="flex items-center justify-center gap-3 mb-3">
          <span className="hairline-gold w-10" />
          <span className="engraved text-[8px] text-aurum-gold/70">Salon en réparation</span>
          <span className="hairline-gold w-10" />
        </div>
        <h2 className="font-display text-3xl gold-leaf mb-3">
          Une fenêtre s'est fermée
        </h2>
        <p className="text-aurum-ivory/55 text-sm italic mb-6 leading-relaxed">
          Un tableau s'est décroché du mur. La maison est intacte —
          seule la salle s'est éteinte un instant.
        </p>
        {error?.message && (
          <pre className="text-[9px] font-mono text-aurum-smoke text-left
                          bg-black/30 p-3 rounded-sm mb-6 overflow-auto max-h-32">
            {error.message}
          </pre>
        )}
        <div className="flex items-center justify-center gap-3">
          <button
            onClick={reset}
            className="px-6 py-2.5 rounded-sm text-[10px] tracking-[0.32em] uppercase
                       text-aurum-goldHi hover:text-aurum-gold-pale
                       border border-aurum-gold/30 hover:border-aurum-gold/60 transition-colors"
          >
            Recharger
          </button>
          <Link
            href="/lounge"
            className="px-6 py-2.5 rounded-sm text-[10px] tracking-[0.32em] uppercase
                       text-aurum-ivory/55 hover:text-aurum-goldHi
                       border border-aurum-ivory/15 hover:border-aurum-goldHi/40 transition-colors"
          >
            Retour au Hall
          </Link>
        </div>
      </div>
    </div>
  );
}
