'use client';

import { useEffect } from 'react';
import { useAurumStore }   from '@/store/useAurumStore';
import { useAccountStore } from '@/store/useAccountStore';
import { useWalletStore }  from '@/store/useWalletStore';
import { audio } from '@/lib/audio';

import Cursor              from '@/components/ui/Cursor';
import HUD                 from '@/components/ui/HUD';
import EnvBanner           from '@/components/ui/EnvBanner';
import QuickDepositModal   from '@/components/ui/QuickDeposit';
import ErrorBoundary       from '@/components/ErrorBoundary';
import AmbientAudioBridge  from '@/components/AmbientAudioBridge';
import ReducedMotionGate   from '@/components/ReducedMotionGate';

/**
 * Mounted once on the root layout. Handles:
 *  - applying [data-atmosphere] on <body>
 *  - initializing audio engine
 *  - hydrating wallet from ledger on session change
 *  - boot loader gate
 *  - V0.2: ambient audio cross-route bridge
 *  - V0.2: prefers-reduced-motion gate
 *  - V0.2: error boundary around the whole tree
 */
export default function Providers({ children }) {
  const atmosphere    = useAurumStore((s) => s.atmosphere);
  const setLoading    = useAurumStore((s) => s.setLoading);
  const accountId     = useAccountStore((s) => s.accountId);
  const refreshWallet = useWalletStore((s) => s.refresh);
  const seedDemo      = useWalletStore((s) => s.seedDemo);

  // atmosphere → CSS attribute
  useEffect(() => {
    if (typeof document === 'undefined') return;
    document.body.setAttribute('data-atmosphere', atmosphere);
  }, [atmosphere]);

  // audio init
  useEffect(() => { audio.init(); }, []);

  // wallet hydration on account change
  useEffect(() => {
    if (!accountId) return;
    refreshWallet(accountId);
    seedDemo(accountId);
  }, [accountId, refreshWallet, seedDemo]);

  // boot loader
  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 1100);
    return () => clearTimeout(t);
  }, [setLoading]);

  return (
    <ErrorBoundary>
      <ReducedMotionGate />
      <AmbientAudioBridge />
      <Cursor />
      <HUD />
      <EnvBanner />
      <QuickDepositModal />
      {children}
    </ErrorBoundary>
  );
}
