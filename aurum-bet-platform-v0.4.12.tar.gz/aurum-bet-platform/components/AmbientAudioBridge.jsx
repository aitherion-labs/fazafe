'use client';

import { useEffect, useRef } from 'react';
import { usePathname } from 'next/navigation';
import { useAurumStore } from '@/store/useAurumStore';
import { audio } from '@/lib/audio';

/**
 * AURUM AMBIENT AUDIO BRIDGE
 *
 * The Howler engine is global, so the ambient track survives route
 * changes by default. What this component adds:
 *
 *  - subtle volume DUCKING when entering a game room (so sfx breathe)
 *  - lift back to full volume in the lobby / wallet / etc.
 *  - quiet on the entry page (only swells when audio is enabled)
 *
 * Mounted by Providers; reacts to pathname changes.
 */

const AMBIENT_KEY = 'ambient';

const VOLUMES_BY_PREFIX = [
  { prefix: '/lounge/roulette',  vol: 0.18 },
  { prefix: '/lounge/blackjack', vol: 0.18 },
  { prefix: '/lounge/slots',     vol: 0.14 },
  { prefix: '/lounge/poker',     vol: 0.20 },
  { prefix: '/lounge',           vol: 0.34 },
  { prefix: '/wallet',           vol: 0.22 },
  { prefix: '/account',          vol: 0.20 },
  { prefix: '/compliance',       vol: 0.20 },
  { prefix: '/demo',             vol: 0.30 },
  { prefix: '/',                 vol: 0.28 },
];

function targetVolume(pathname) {
  for (const { prefix, vol } of VOLUMES_BY_PREFIX) {
    if (pathname === prefix || pathname.startsWith(prefix + '/')) return vol;
    if (prefix === '/' && pathname === '/') return vol;
  }
  return 0.25;
}

export default function AmbientAudioBridge() {
  const pathname     = usePathname();
  const audioEnabled = useAurumStore((s) => s.audioEnabled);
  const lastVol      = useRef(null);

  useEffect(() => {
    if (!audioEnabled) return;
    const sound = audio.sounds?.[AMBIENT_KEY];
    if (!sound || typeof sound.fade !== 'function') return;

    const target = targetVolume(pathname);
    const current = lastVol.current ?? sound.volume?.() ?? 0.35;
    try {
      sound.fade(current, target, 1200);
    } catch (_) { /* graceful */ }
    lastVol.current = target;
  }, [pathname, audioEnabled]);

  return null;
}
