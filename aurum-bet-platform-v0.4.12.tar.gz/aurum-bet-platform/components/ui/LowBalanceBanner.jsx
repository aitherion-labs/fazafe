'use client';

import { motion, AnimatePresence } from 'framer-motion';
import { useT } from '@/lib/i18n';
import { playClick } from '@/lib/audio';
import { openQuickDeposit } from './QuickDeposit';

/**
 * LowBalanceBanner
 *
 * Shows when the player's available balance is below the minimum chip
 * value for the current game. Offers a one-tap top-up via the Quick
 * Deposit modal — keeps the player at the table.
 *
 * Props:
 *   visible:  boolean      — render only when true
 */
export default function LowBalanceBanner({ visible }) {
  const t = useT();

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ opacity: 0, y: -10, scale: 0.94 }}
          animate={{ opacity: 1, y:  0, scale: 1    }}
          exit   ={{ opacity: 0, y: -10, scale: 0.94 }}
          transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
          className="absolute top-44 left-1/2 -translate-x-1/2 z-40"
        >
          <div
            className="flex items-center gap-3 px-5 py-2.5 rounded-full"
            style={{
              background: 'linear-gradient(180deg, rgba(20,12,8,0.92), rgba(8,4,2,0.96))',
              border: '1px solid rgba(244,215,138,0.45)',
              boxShadow: '0 6px 20px rgba(0,0,0,0.6), 0 0 24px rgba(244,215,138,0.18)',
            }}
          >
            <span className="engraved text-[9px] text-aurum-goldHi tracking-[0.18em]">
              {t('quickDeposit.lowBalance')}
            </span>
            <motion.button
              whileHover={{ scale: 1.04 }}
              whileTap={{ scale: 0.94 }}
              onClick={() => { playClick(); openQuickDeposit(); }}
              className="px-3.5 py-1.5 rounded-full text-[10px] font-medium tracking-[0.18em] uppercase
                         text-aurum-black"
              style={{
                background: 'linear-gradient(180deg, #FFF1C7 0%, #C8A24A 60%, #7A5C18 100%)',
                boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.4)',
              }}
            >
              + {t('quickDeposit.lowBalanceCta')}
            </motion.button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
