'use client';

import { motion } from 'framer-motion';
import { playChip } from '@/lib/audio';

/**
 * A physical-looking casino chip. CSS+SVG, no images.
 *
 * Every chip ALWAYS shows its denomination in the center. The value
 * formatter folds 1000+ into "1K", "10K" so the digit doesn't overflow
 * the rim at small sizes. The selected chip is unambiguous: lifted,
 * scaled up, and ringed in gold.
 *
 * Denomination palette covers everything the games use today
 * ($1 through $10K). Unknown values fall back to a neutral gold scheme.
 */
const CHIP_STYLES = {
  1:     { rim: '#FAF3E0', face: '#3A2E22', accent: '#C8A24A' }, // ivory
  5:     { rim: '#9CC8FF', face: '#0E2238', accent: '#FFF1C7' }, // sky
  10:    { rim: '#EDE3CE', face: '#3A2E22', accent: '#C8A24A' }, // ivory deep
  25:    { rim: '#22C55E', face: '#062614', accent: '#A6F4C5' }, // emerald
  50:    { rim: '#E0573B', face: '#2A0E0A', accent: '#FFB48A' }, // ember
  100:   { rim: '#1A0E18', face: '#05040A', accent: '#C8A24A' }, // obsidian
  250:   { rim: '#9B6FE0', face: '#1A0E28', accent: '#D8B6FF' }, // violet
  500:   { rim: '#4A2E5A', face: '#1A0E28', accent: '#F4D78A' }, // royal
  1000:  { rim: '#F4D78A', face: '#1A0E04', accent: '#FFF1C7' }, // bullion
  5000:  { rim: '#7A0E14', face: '#0A0608', accent: '#F4D78A' }, // crimson
  10000: { rim: '#0A0608', face: '#7A5C18', accent: '#FFF1C7' }, // platinum
};
const FALLBACK = { rim: '#C8A24A', face: '#1A0E04', accent: '#F4D78A' };

/** Short display of denomination. 5000 → "5K", 10000 → "10K". */
function formatChipValue(v) {
  if (v >= 1000 && v % 1000 === 0) return `${v / 1000}K`;
  if (v >= 1000) return (v / 1000).toFixed(1).replace('.0', '') + 'K';
  return String(v);
}

export default function Chip({ value = 100, size = 64, onClick, selected = false, disabled = false }) {
  const s = CHIP_STYLES[value] || FALLBACK;
  const px = size;
  const label = formatChipValue(value);

  return (
    <motion.button
      onClick={() => { if (disabled) return; playChip(); onClick?.(value); }}
      whileHover={!disabled ? { y: -6, rotateX: 12 } : {}}
      whileTap={!disabled ? { y: 2, rotateX: 0, scale: 0.95 } : {}}
      animate={selected ? { y: -10, scale: 1.12 } : { y: 0, scale: 1 }}
      transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
      disabled={disabled}
      aria-label={`Chip value $${value}`}
      aria-pressed={selected}
      style={{
        width: px, height: px,
        transformStyle: 'preserve-3d',
        perspective: 600,
        opacity: disabled ? 0.45 : 1,
        cursor: disabled ? 'not-allowed' : 'pointer',
      }}
      className="relative outline-none focus-visible:ring-2 focus-visible:ring-aurum-goldHi rounded-full"
    >
      {/* shadow on table */}
      <span
        aria-hidden
        className="absolute left-1/2 -bottom-2 -translate-x-1/2 rounded-full blur-md pointer-events-none"
        style={{
          width: px * 0.85, height: px * 0.18,
          background: 'rgba(0,0,0,0.55)',
        }}
      />
      {/* selected: gold halo behind */}
      {selected && (
        <span
          aria-hidden
          className="absolute inset-0 rounded-full pointer-events-none"
          style={{
            boxShadow: `0 0 0 2px #F4D78A, 0 0 16px 2px rgba(244,215,138,0.6)`,
          }}
        />
      )}
      <svg viewBox="0 0 100 100" width={px} height={px} className="relative block">
        <defs>
          <radialGradient id={`chip-face-${value}`} cx="50%" cy="40%" r="60%">
            <stop offset="0%"  stopColor={s.face} stopOpacity="1" />
            <stop offset="80%" stopColor={s.face} stopOpacity="1" />
            <stop offset="100%" stopColor="#000"  stopOpacity="1" />
          </radialGradient>
          <linearGradient id={`chip-rim-${value}`} x1="0" y1="0" x2="0" y2="100">
            <stop offset="0%"   stopColor={s.rim} />
            <stop offset="50%"  stopColor={s.rim} stopOpacity="1" />
            <stop offset="100%" stopColor="#000"  stopOpacity="0.6" />
          </linearGradient>
          <linearGradient id={`chip-shine-${value}`} x1="20" y1="20" x2="80" y2="80">
            <stop offset="0%"   stopColor="#fff" stopOpacity="0.55" />
            <stop offset="55%"  stopColor="#fff" stopOpacity="0" />
          </linearGradient>
        </defs>

        {/* outer rim */}
        <circle cx="50" cy="50" r="48" fill={`url(#chip-rim-${value})`} />
        {/* notches around rim */}
        {Array.from({ length: 8 }).map((_, i) => {
          const a = (i * Math.PI * 2) / 8;
          const x1 = 50 + Math.cos(a) * 44;
          const y1 = 50 + Math.sin(a) * 44;
          const x2 = 50 + Math.cos(a) * 50;
          const y2 = 50 + Math.sin(a) * 50;
          return (
            <line key={i} x1={x1} y1={y1} x2={x2} y2={y2}
                  stroke={s.face} strokeWidth="6" strokeLinecap="butt" />
          );
        })}

        {/* face */}
        <circle cx="50" cy="50" r="36" fill={`url(#chip-face-${value})`} />

        {/* gold inner ring */}
        <circle cx="50" cy="50" r="34" fill="none" stroke={s.accent} strokeWidth="0.5" opacity="0.6" />
        <circle cx="50" cy="50" r="28" fill="none" stroke={s.accent} strokeWidth="0.4" opacity="0.4" />

        {/* $-prefix above the number (sits at ~y=42) */}
        <text
          x="50" y="42"
          textAnchor="middle"
          fontFamily="Inter Tight, sans-serif"
          fontSize="9"
          fontWeight="500"
          fill={s.accent}
          opacity="0.85"
        >
          $
        </text>

        {/* DENOMINATION — always visible, the focal element */}
        <text
          x="50" y="62"
          textAnchor="middle"
          fontFamily="Cormorant Garamond, serif"
          fontSize={label.length >= 3 ? 18 : 24}
          fontWeight="600"
          fill={s.accent}
          style={{ filter: 'drop-shadow(0 1px 0 rgba(0,0,0,0.7))' }}
        >
          {label}
        </text>
        <text
          x="50" y="74"
          textAnchor="middle"
          fontFamily="Inter Tight, sans-serif"
          fontSize="4"
          letterSpacing="2"
          fill={s.accent}
          opacity="0.7"
        >
          AURUM
        </text>

        {/* specular highlight */}
        <circle cx="50" cy="50" r="48" fill={`url(#chip-shine-${value})`} />
      </svg>
    </motion.button>
  );
}
