'use client';

import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAccountStore } from '@/store/useAccountStore';
import { useWalletStore }  from '@/store/useWalletStore';
import { formatCurrency }  from '@/services/money';
import { playClick, playChip, playReveal } from '@/lib/audio';
import { useT } from '@/lib/i18n';
import { CinematicButton, GlassPanel } from '@/ds/components';

/**
 * Quick Deposit Modal
 *
 * One-click chip top-up from anywhere in the app. Wraps the simulated
 * payment adapter so the experience is instant — denomination → credit
 * → balance updates in under a second.
 *
 * Mounted globally by Providers; opens via the `quickDeposit:open` custom
 * event, dispatched by:
 *   - The "+ CHIPS" button in the HUD
 *   - Inline low-balance prompts in game pages
 *
 * Same code path as /wallet/deposit (writes through the simulated
 * adapter → ledger), but skipped the multi-step wizard.
 */

const PRESET_AMOUNTS = [100, 500, 1000, 5000, 10000];

export default function QuickDepositModal() {
  const accountId = useAccountStore((s) => s.accountId);
  const wallet    = useWalletStore();
  const formatted = useWalletStore((s) => s.formatted());
  const t         = useT();

  const [open,    setOpen]    = useState(false);
  const [busy,    setBusy]    = useState(false);
  const [done,    setDone]    = useState(false);
  const [error,   setError]   = useState(null);
  const [credited,setCredited]= useState(null);
  const inFlightRef           = useRef(false);   // guard double-submit

  // Open via custom event (so any component can trigger it)
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const onOpen = () => {
      setError(null);
      setDone(false);
      setCredited(null);
      setOpen(true);
    };
    window.addEventListener('quickDeposit:open', onOpen);
    return () => window.removeEventListener('quickDeposit:open', onOpen);
  }, []);

  // ESC to close
  useEffect(() => {
    if (!open) return;
    const onKey = (e) => { if (e.key === 'Escape') setOpen(false); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open]);

  const close = () => {
    playClick();
    setOpen(false);
  };

  const credit = async (amount) => {
    if (busy || inFlightRef.current || !accountId) return;
    inFlightRef.current = true;
    setError(null);
    setBusy(true);
    playChip();

    try {
      const res = await wallet.deposit(accountId, amount);
      if (!res.ok) {
        setError(res.reason || 'TRANSACTION_FAILED');
        setBusy(false);
        return;
      }

      setCredited(amount);
      setDone(true);
      playReveal();

      // Auto-close after a beat
      setTimeout(() => {
        setOpen(false);
        setBusy(false);
      }, 1400);
    } finally {
      // Allow another attempt after a small cooldown
      setTimeout(() => { inFlightRef.current = false; }, 1500);
    }
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit   ={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="fixed inset-0 z-[9990] flex items-center justify-center"
          style={{ background: 'rgba(5, 4, 10, 0.78)', backdropFilter: 'blur(6px)' }}
          onClick={close}
        >
          <motion.div
            initial={{ y: 30, opacity: 0, filter: 'blur(12px)' }}
            animate={{ y:  0, opacity: 1, filter: 'blur(0px)'  }}
            exit   ={{ y: 30, opacity: 0, filter: 'blur(12px)' }}
            transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
            className="relative w-[440px] max-w-[92vw]"
            onClick={(e) => e.stopPropagation()}
          >
            <GlassPanel tint="noir" frame corners className="rounded-md overflow-hidden">
              {/* header */}
              <div className="px-7 pt-6 pb-4 text-center">
                <div className="flex items-center justify-center gap-3 mb-2">
                  <span className="hairline-gold w-10" />
                  <span className="engraved text-[8px] text-aurum-gold/80 tracking-[0.32em]">
                    {t('quickDeposit.eyebrow')}
                  </span>
                  <span className="hairline-gold w-10" />
                </div>
                <h2 className="font-display text-3xl gold-leaf">
                  {t('quickDeposit.title')}
                </h2>
                <p className="mt-2 text-[11px] text-aurum-ivory/55 italic">
                  {t('quickDeposit.subtitle')}
                </p>
                <div className="mt-3 flex items-center justify-center gap-3 text-[10px] tracking-[0.18em]">
                  <span className="engraved text-aurum-smoke">{t('wallet.available').toUpperCase()}</span>
                  <span className="font-display text-aurum-goldHi tabular-nums">
                    {formatted.available}
                  </span>
                </div>
              </div>

              <div className="hairline-gold mx-7" />

              {/* body */}
              <div className="px-7 py-6">
                {done ? (
                  <motion.div
                    initial={{ scale: 0.6, opacity: 0 }}
                    animate={{ scale: 1,   opacity: 1 }}
                    transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
                    className="text-center"
                  >
                    <div
                      className="font-display text-6xl gold-leaf mb-2"
                      style={{ filter: 'drop-shadow(0 0 16px rgba(244,215,138,0.6))' }}
                    >
                      +{formatCurrency(credited)}
                    </div>
                    <div className="engraved text-[9px] text-aurum-goldHi">
                      {t('quickDeposit.credited')}
                    </div>
                  </motion.div>
                ) : busy ? (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="text-center py-6"
                  >
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1.2, repeat: Infinity, ease: 'linear' }}
                      className="w-10 h-10 mx-auto mb-3 rounded-full border-2"
                      style={{
                        borderColor: 'rgba(244,215,138,0.18)',
                        borderTopColor: '#F4D78A',
                      }}
                    />
                    <div className="engraved text-[9px] text-aurum-goldHi tracking-[0.32em]">
                      {t('quickDeposit.processing')}
                    </div>
                  </motion.div>
                ) : (
                  <>
                    <div className="engraved text-[8px] text-aurum-gold/70 mb-3 text-center tracking-[0.18em]">
                      {t('quickDeposit.pickAmount')}
                    </div>
                    <div className="grid grid-cols-5 gap-2 mb-4">
                      {PRESET_AMOUNTS.map((amount) => (
                        <motion.button
                          key={amount}
                          whileHover={{ y: -2 }}
                          whileTap={{ scale: 0.94 }}
                          onClick={() => credit(amount)}
                          className="px-1 py-3 rounded-sm
                                     text-aurum-goldHi hover:text-aurum-gold-pale
                                     border border-aurum-gold/25 hover:border-aurum-gold/60
                                     transition-colors"
                          style={{
                            background: 'linear-gradient(180deg, rgba(244,215,138,0.05), rgba(0,0,0,0.4))',
                          }}
                        >
                          <div className="font-display text-[13px] tabular-nums">
                            ${amount.toLocaleString('en-US')}
                          </div>
                        </motion.button>
                      ))}
                    </div>

                    {error && (
                      <div className="text-center text-[10px] tracking-[0.18em] text-red-400/80 mb-3">
                        {error.replace(/_/g, ' ')}
                      </div>
                    )}

                    <p className="text-center engraved text-[7px] text-aurum-smoke leading-relaxed tracking-[0.22em]">
                      {t('quickDeposit.simNote')}
                    </p>

                    <div className="mt-4 text-center">
                      <button
                        onClick={close}
                        className="text-[9px] tracking-[0.32em] uppercase
                                   text-aurum-smoke hover:text-aurum-gold transition-colors"
                      >
                        {t('common.close')}
                      </button>
                    </div>
                  </>
                )}
              </div>
            </GlassPanel>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

/** Dispatch helper — call from anywhere */
export function openQuickDeposit() {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('quickDeposit:open'));
  }
}
