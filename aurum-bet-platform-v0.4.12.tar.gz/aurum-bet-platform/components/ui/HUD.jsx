'use client';

import { motion, AnimatePresence } from 'framer-motion';
import { usePathname, useRouter } from 'next/navigation';
import Link from 'next/link';

import { useAurumStore }   from '@/store/useAurumStore';
import { useWalletStore }  from '@/store/useWalletStore';
import { useAccountStore } from '@/store/useAccountStore';
import { audio, playHover, playClick } from '@/lib/audio';
import { SUPPORTED_LOCALES, LOCALE_LABELS, useT } from '@/lib/i18n';
import GlassPanel from './GlassPanel';

const ATMOSPHERES = [
  { id: 'noir',    label: 'NOIR',    dot: '#C8A24A' },
  { id: 'quantum', label: 'QUANTUM', dot: '#6FA8DC' },
  { id: 'royal',   label: 'ROYAL',   dot: '#E0573B' },
];

export default function HUD() {
  const pathname     = usePathname();
  const router       = useRouter();
  const atmosphere   = useAurumStore((s) => s.atmosphere);
  const setAtm       = useAurumStore((s) => s.setAtmosphere);
  const audioEnabled = useAurumStore((s) => s.audioEnabled);
  const toggleAudio  = useAurumStore((s) => s.toggleAudio);
  const locale       = useAurumStore((s) => s.locale);
  const setLocale    = useAurumStore((s) => s.setLocale);
  const isAuth       = useAccountStore((s) => s.isAuthenticated());
  const handle       = useAccountStore((s) => s.handle);
  const formatted    = useWalletStore((s) => s.formatted());
  const t            = useT();

  // Hide HUD on root entry page only
  if (pathname === '/') return null;

  const handleAudio = () => {
    if (!audioEnabled) audio.enable(); else audio.disable();
    toggleAudio();
  };

  return (
    <AnimatePresence>
      <motion.header
        initial={{ y: -40, opacity: 0 }}
        animate={{ y:   0, opacity: 1 }}
        exit   ={{ y: -40, opacity: 0 }}
        transition={{ duration: 1.0, ease: [0.22, 1, 0.36, 1] }}
        className="fixed top-0 left-0 right-0 z-50 px-6 py-4
                   flex items-center justify-between pointer-events-none"
      >
        {/* LEFT — Logo + breadcrumb */}
        <div className="pointer-events-auto flex items-center gap-6">
          <Link
            href="/lounge"
            onMouseEnter={playHover}
            onClick={playClick}
            className="group flex items-center gap-3"
          >
            <Sigil />
            <div className="flex flex-col leading-none">
              <span className="font-display text-[20px] tracking-[0.18em] gold-leaf">
                AURUM
              </span>
              <span className="engraved text-[8px] text-aurum-smoke mt-0.5">
                Maison de Jeu · Est. MMXXV
              </span>
            </div>
          </Link>

          <Breadcrumb pathname={pathname} />
        </div>

        {/* CENTER — Atmosphere selector */}
        <GlassPanel
          tint="noir"
          className="pointer-events-auto px-2 py-1.5 rounded-full hidden lg:flex items-center gap-1"
          animate={false}
        >
          {ATMOSPHERES.map((a) => {
            const active = atmosphere === a.id;
            return (
              <button
                key={a.id}
                onMouseEnter={playHover}
                onClick={() => { playClick(); setAtm(a.id); }}
                className={`
                  relative px-4 py-1.5 rounded-full
                  font-body text-[9px] font-medium tracking-[0.32em]
                  transition-colors duration-500
                  ${active ? 'text-aurum-black' : 'text-aurum-ivory/60 hover:text-aurum-goldHi'}
                `}
              >
                {active && (
                  <motion.span
                    layoutId="atm-pill"
                    className="absolute inset-0 rounded-full"
                    style={{
                      background: 'var(--grad-gold-leaf)',
                      backgroundSize: '200% 200%',
                      boxShadow: '0 0 20px rgba(244,215,138,0.35)',
                    }}
                    transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
                  />
                )}
                <span className="relative flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full"
                    style={{ background: a.dot, boxShadow: `0 0 8px ${a.dot}` }} />
                  {a.label}
                </span>
              </button>
            );
          })}
        </GlassPanel>

        {/* RIGHT — Wallet + Account + Audio */}
        <div className="pointer-events-auto flex items-center gap-3">
          {isAuth && (
            <Link
              href="/wallet"
              onMouseEnter={playHover}
              onClick={playClick}
              className="block"
            >
              <GlassPanel
                tint="warm"
                className="px-5 py-2.5 rounded-full flex items-center gap-3 hover:scale-[1.02] transition-transform"
                animate={false}
              >
                <span className="engraved text-[8px] text-aurum-smoke">{t('hud.wealth')}</span>
                <div className="w-px h-3 bg-aurum-gold/30" />
                <motion.span
                  key={formatted.available}
                  initial={{ opacity: 0, y: -4 }}
                  animate={{ opacity: 1, y: 0  }}
                  className="font-display text-base gold-leaf tracking-wider"
                >
                  {formatted.available}
                </motion.span>
              </GlassPanel>
            </Link>
          )}

          {/* + CHIPS quick-deposit (always visible when authenticated) */}
          {isAuth && (
            <motion.button
              onMouseEnter={playHover}
              onClick={(e) => {
                e.preventDefault();
                playClick();
                window.dispatchEvent(new CustomEvent('quickDeposit:open'));
              }}
              whileHover={{ y: -1, scale: 1.03 }}
              whileTap={{ scale: 0.95 }}
              className="relative px-4 py-2.5 rounded-full flex items-center gap-1.5
                         text-[10px] tracking-[0.22em] uppercase
                         text-aurum-black font-medium
                         transition-shadow"
              style={{
                background: 'linear-gradient(180deg, #FFF1C7 0%, #C8A24A 60%, #7A5C18 100%)',
                boxShadow: '0 4px 14px rgba(244,215,138,0.25), inset 0 1px 0 rgba(255,255,255,0.4)',
                border: '1px solid rgba(244,215,138,0.6)',
              }}
              title={t('quickDeposit.title')}
            >
              <span className="font-display text-base leading-none">+</span>
              <span>{t('hud.addChips')}</span>
            </motion.button>
          )}

          {isAuth ? (
            <Link href="/account/profile" onMouseEnter={playHover} onClick={playClick}>
              <GlassPanel tint="noir" className="px-4 py-2 rounded-full flex items-center gap-2"
                animate={false}>
                <Avatar seed={handle || '?'} />
                <span className="text-[10px] tracking-[0.18em] text-aurum-ivory/80">
                  {handle}
                </span>
              </GlassPanel>
            </Link>
          ) : (
            <Link href="/account/login" onMouseEnter={playHover} onClick={playClick}>
              <GlassPanel tint="noir"
                className="px-5 py-2.5 rounded-full text-[10px] tracking-[0.32em] text-aurum-goldHi hover:text-aurum-gold-pale"
                animate={false}>
                ENTRER
              </GlassPanel>
            </Link>
          )}

          <button
            onMouseEnter={playHover}
            onClick={handleAudio}
            className="relative w-11 h-11 rounded-full glass-panel flex items-center justify-center
                       text-aurum-goldHi hover:text-aurum-gold-pale transition-colors"
            aria-label="Toggle audio"
          >
            {audioEnabled ? <SpeakerOn /> : <SpeakerOff />}
          </button>

          {/* Locale switcher — discreet, click-cycles */}
          <button
            onMouseEnter={playHover}
            onClick={() => {
              playClick();
              const i = SUPPORTED_LOCALES.indexOf(locale);
              const next = SUPPORTED_LOCALES[(i + 1) % SUPPORTED_LOCALES.length];
              setLocale(next);
            }}
            className="relative w-11 h-11 rounded-full glass-panel flex items-center justify-center
                       text-aurum-goldHi hover:text-aurum-gold-pale transition-colors
                       text-[9px] font-mono tracking-widest"
            aria-label={`Change language (current: ${LOCALE_LABELS[locale]})`}
            title={LOCALE_LABELS[locale]}
          >
            {locale.toUpperCase()}
          </button>
        </div>
      </motion.header>
    </AnimatePresence>
  );
}

/* ---------- breadcrumb ---------- */

function Breadcrumb({ pathname }) {
  const labels = {
    '/lounge': 'Le Grand Hall',
    '/lounge/roulette':  'Le Tourbillon',
    '/lounge/blackjack': 'Le Vingt-et-Un',
    '/lounge/slots':     'Les Bobines',
    '/lounge/poker':     'Les Initiés',
    '/wallet':           'La Voûte',
    '/wallet/deposit':   'La Voûte · Dépôt',
    '/wallet/withdraw':  'La Voûte · Retrait',
    '/account/profile':  'Mon Dossier',
    '/account/login':    'Identification',
    '/account/signup':   'Adhésion',
    '/compliance':       'Conformité',
    '/compliance/kyc':   'Vérification',
    '/compliance/responsible': 'Jeu Responsable',
    '/demo':             'Démonstration',
  };
  const label = labels[pathname];
  if (!label) return null;
  return (
    <div className="hidden md:flex items-center gap-3 ml-2">
      <span className="hairline-gold w-6" />
      <span className="engraved text-[8px] text-aurum-gold/80">{label}</span>
    </div>
  );
}

/* ---------- atoms ---------- */

function Sigil() {
  return (
    <svg width="30" height="30" viewBox="0 0 32 32" className="drop-shadow-[0_0_12px_rgba(244,215,138,0.3)]">
      <defs>
        <linearGradient id="sg-hud" x1="0" y1="0" x2="32" y2="32">
          <stop offset="0%"   stopColor="#FFF1C7" />
          <stop offset="50%"  stopColor="#C8A24A" />
          <stop offset="100%" stopColor="#7A5C18" />
        </linearGradient>
      </defs>
      <circle cx="16" cy="16" r="14" fill="none" stroke="url(#sg-hud)" strokeWidth="0.8" />
      <path d="M 16 4 L 18 14 L 28 16 L 18 18 L 16 28 L 14 18 L 4 16 L 14 14 Z" fill="url(#sg-hud)" />
      <circle cx="16" cy="16" r="2" fill="#05040A" />
    </svg>
  );
}

function Avatar({ seed }) {
  // hash seed to a hue for deterministic avatar tint
  let h = 0;
  for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) | 0;
  const hue = Math.abs(h) % 360;
  return (
    <div
      className="w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-display"
      style={{
        background: `linear-gradient(135deg, hsl(${hue} 60% 40%), hsl(${(hue + 40) % 360} 60% 25%))`,
        color: '#F4D78A',
        boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.2), 0 0 8px rgba(244,215,138,0.25)',
      }}
    >
      {(seed[0] || '?').toUpperCase()}
    </div>
  );
}

function SpeakerOn() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4">
      <path d="M2 6v4h2.5L8 13V3L4.5 6H2z" fill="currentColor" />
      <path d="M11 5.5a3 3 0 0 1 0 5" />
      <path d="M13 3.5a6 6 0 0 1 0 9" />
    </svg>
  );
}

function SpeakerOff() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4">
      <path d="M2 6v4h2.5L8 13V3L4.5 6H2z" fill="currentColor" />
      <path d="M11 6l4 4M15 6l-4 4" />
    </svg>
  );
}
