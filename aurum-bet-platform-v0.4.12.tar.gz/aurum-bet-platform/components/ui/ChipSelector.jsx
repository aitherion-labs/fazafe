'use client';

import Chip from './Chip';
import { useT } from '@/lib/i18n';

/**
 * AURUM ChipSelector
 *
 * Shared denomination picker used by every game with a stake. Renders
 * a row of chips, highlights the currently selected denomination, and
 * fires `onChange(value)` on click. Stays disabled while a round is
 * running so the player can't change stake mid-spin.
 *
 * Props:
 *   denominations  number[]   chip values (defaults to a sane mix)
 *   value          number     currently selected denomination
 *   onChange       (n)=>void
 *   disabled       boolean
 *   size           number     chip diameter in px (default 44)
 *   label          string     small label above the row (i18n.bet by default)
 *   labelKey       string     i18n key for the label (overrides label)
 */
const DEFAULTS = [1, 5, 25, 100, 500];

export default function ChipSelector({
  denominations = DEFAULTS,
  value,
  onChange,
  disabled = false,
  size = 44,
  label,
  labelKey,
}) {
  const t = useT();
  const heading = labelKey ? t(labelKey) : (label ?? t('slots.bet'));
  return (
    <div className="text-center">
      <div className="engraved text-[8px] text-aurum-gold/70 mb-2 tracking-[0.18em]">
        {heading}
      </div>
      <div className="flex items-center gap-2" style={{ perspective: 600 }}>
        {denominations.map((v) => (
          <Chip
            key={v}
            value={v}
            size={size}
            selected={value === v}
            disabled={disabled}
            onClick={() => onChange?.(v)}
          />
        ))}
      </div>
    </div>
  );
}
