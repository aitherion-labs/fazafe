'use client';

import { useEffect, useRef, useState } from 'react';

/**
 * Decorative gold ring that trails the native cursor.
 *
 * Important: this NEVER hides the native cursor. The user's OS cursor is
 * always visible. This component just renders a soft gold halo on top
 * with `mix-blend-mode: screen` so it harmonizes with whatever is below.
 *
 * Hidden until the first mouse movement to avoid the awkward "stuck in
 * the top-left corner" state during React hydration.
 */
export default function Cursor() {
  const ringRef = useRef(null);
  const dotRef  = useRef(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    if (window.matchMedia('(pointer: coarse)').matches) return; // hide on touch

    let mouseX = window.innerWidth / 2;
    let mouseY = window.innerHeight / 2;
    let ringX  = mouseX, ringY = mouseY;
    let raf;
    let didMove = false;

    const onMove = (e) => {
      mouseX = e.clientX;
      mouseY = e.clientY;
      if (!didMove) {
        didMove = true;
        ringX = mouseX; ringY = mouseY;
        setVisible(true);
      }
      if (dotRef.current) {
        dotRef.current.style.transform = `translate(${mouseX}px, ${mouseY}px) translate(-50%, -50%)`;
      }
    };

    const onDown = () => ringRef.current?.classList.add('cursor-down');
    const onUp   = () => ringRef.current?.classList.remove('cursor-down');

    const tick = () => {
      ringX += (mouseX - ringX) * 0.18;
      ringY += (mouseY - ringY) * 0.18;
      if (ringRef.current) {
        ringRef.current.style.transform = `translate(${ringX}px, ${ringY}px) translate(-50%, -50%)`;
      }
      raf = requestAnimationFrame(tick);
    };

    window.addEventListener('mousemove', onMove);
    window.addEventListener('mousedown', onDown);
    window.addEventListener('mouseup',   onUp);
    raf = requestAnimationFrame(tick);

    return () => {
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mousedown', onDown);
      window.removeEventListener('mouseup',   onUp);
      cancelAnimationFrame(raf);
    };
  }, []);

  return (
    <>
      <div
        ref={ringRef}
        className="fixed top-0 left-0 w-7 h-7 rounded-full pointer-events-none z-[9999]
                   transition-[width,height,opacity] duration-300"
        style={{
          opacity: visible ? 1 : 0,
          border: '1px solid rgba(244, 215, 138, 0.55)',
          boxShadow: '0 0 10px rgba(244, 215, 138, 0.30)',
          mixBlendMode: 'screen',
        }}
      />
      <div
        ref={dotRef}
        className="fixed top-0 left-0 w-[3px] h-[3px] rounded-full pointer-events-none z-[9999]"
        style={{
          opacity: visible ? 0.85 : 0,
          background: '#F4D78A',
          boxShadow: '0 0 6px rgba(244,215,138,0.75)',
          mixBlendMode: 'screen',
          transition: 'opacity 200ms',
        }}
      />
      <style jsx global>{`
        .cursor-down { width: 16px !important; height: 16px !important; }
      `}</style>
    </>
  );
}
