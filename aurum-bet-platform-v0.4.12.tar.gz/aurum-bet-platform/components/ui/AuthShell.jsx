'use client';

import { Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { motion } from 'framer-motion';
import dynamic from 'next/dynamic';

import CinematicLighting from '@/components/three/CinematicLighting';
import VolumetricBeam    from '@/components/effects/VolumetricBeam';
import DustParticles     from '@/components/effects/DustParticles';
import { rigFor } from '@/ds/lighting';
import { useAurumStore } from '@/store/useAurumStore';

const PostFX = dynamic(() => import('@/components/effects/PostFX'), { ssr: false });

/**
 * AuthShell — cinematic backdrop used by login/signup/profile pages.
 * Centered glass card holds the form, the rest is atmosphere.
 */
export default function AuthShell({ title, subtitle, children, footer }) {
  const atmosphere = useAurumStore((s) => s.atmosphere);
  const rig = rigFor(atmosphere);

  return (
    <section className="relative w-full h-screen overflow-hidden grain vignette">
      {/* atmospheric backdrop */}
      <div className="absolute inset-0">
        <Canvas
          camera={{ position: [0, 1.6, 5], fov: 42 }}
          dpr={[1, 1.6]}
          gl={{ antialias: true, toneMapping: 2, toneMappingExposure: 0.85 }}
        >
          <Suspense fallback={null}>
            <fog attach="fog" args={['#05040A', 4, 14]} />
            <CinematicLighting {...rig} intensity={0.7} />
            <VolumetricBeam position={[0, 5, -2]} height={5} radius={1.8} intensity={0.65} />
            <DustParticles count={300} area={10} color="#F4D78A" />
            {/* Decorative slowly-rotating sigil */}
            <mesh position={[0, 1.3, -2]} rotation={[0, 0, 0]}>
              <torusGeometry args={[0.85, 0.02, 16, 96]} />
              <meshStandardMaterial color="#C8A24A" metalness={1} roughness={0.2} />
            </mesh>
            <mesh position={[0, 1.3, -2]}>
              <torusGeometry args={[1.1, 0.012, 16, 96]} />
              <meshStandardMaterial color="#7A5C18" metalness={1} roughness={0.35} />
            </mesh>
            <PostFX intensity={0.95} />
          </Suspense>
        </Canvas>
      </div>

      {/* foreground */}
      <div className="absolute inset-0 z-30 flex items-center justify-center px-6">
        <motion.div
          initial={{ opacity: 0, y: 30, filter: 'blur(20px)' }}
          animate={{ opacity: 1, y:  0, filter: 'blur(0px)'  }}
          transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
          className="relative w-full max-w-md"
        >
          <div
            className="relative gold-frame rounded-md velvet p-10 spotlight"
            style={{ boxShadow: 'var(--shadow-cinematic)' }}
          >
            <div className="text-center mb-8">
              <div className="flex items-center justify-center gap-3 mb-3">
                <span className="hairline-gold w-10" />
                <span className="engraved text-[8px] text-aurum-gold/70">AURUM</span>
                <span className="hairline-gold w-10" />
              </div>
              <h1 className="font-display text-4xl gold-leaf tracking-[0.04em] mb-2">
                {title}
              </h1>
              {subtitle && (
                <p className="font-display italic text-aurum-ivory/55 text-sm">
                  {subtitle}
                </p>
              )}
            </div>

            <div className="hairline-gold mb-8" />

            {children}

            {footer && (
              <>
                <div className="hairline-gold mt-8 mb-5 opacity-60" />
                <div className="text-center text-[10px] tracking-[0.18em] text-aurum-ivory/55">
                  {footer}
                </div>
              </>
            )}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
