'use client';

import { MODE_LABEL, MODE_COLOR, APP_MODE, IS_LICENSED } from '@/lib/config';

/**
 * Persistent environment label. Renders nothing in licensed mode so
 * production users never see a dev badge. In sandbox/demo it sits in
 * a corner with a distinctive color so the operator can tell which
 * mode they are in at a glance — and so demo audiences understand
 * no real funds are moving.
 */
export default function EnvBanner() {
  if (IS_LICENSED || !MODE_LABEL) return null;
  return (
    <div
      className="fixed bottom-3 left-3 z-[8000] pointer-events-none
                 select-none flex items-center gap-2 px-2.5 py-1 rounded-sm
                 text-[8px] tracking-[0.32em] uppercase font-mono"
      style={{
        background: 'rgba(0,0,0,0.7)',
        border: `1px solid ${MODE_COLOR}55`,
        color: MODE_COLOR,
        backdropFilter: 'blur(6px)',
      }}
      aria-label={`Application mode: ${APP_MODE}`}
    >
      <span
        className="w-1.5 h-1.5 rounded-full"
        style={{ background: MODE_COLOR, boxShadow: `0 0 6px ${MODE_COLOR}` }}
      />
      {MODE_LABEL} · NO REAL FUNDS
    </div>
  );
}
