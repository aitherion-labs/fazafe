'use client';

import { motion } from 'framer-motion';
import { playHover, playClick } from '@/lib/audio';
import { useAurumStore } from '@/store/useAurumStore';

/**
 * A portal card in the lobby — looks like a museum-grade plaque/diorama window.
 * Layers:
 *  1. Velvet back
 *  2. Diorama image (sceneArt — supplied as JSX or SVG)
 *  3. Gold frame with corners
 *  4. Engraved title plate at the bottom
 */
export default function PortalCard({
  id,
  title,
  subtitle,
  description,
  sceneArt,        // JSX node — drawn inside the frame
  accent = '#C8A24A',
  index = 0,
  onActivate,
}) {
  const setHovered = useAurumStore((s) => s.setHoveredPortal);
  const hovered    = useAurumStore((s) => s.hoveredPortal);
  const isHovered  = hovered === id;

  const handleClick = () => {
    playClick();
    onActivate?.(id);
  };

  return (
    <motion.button
      initial={{ opacity: 0, y: 60, filter: 'blur(12px)' }}
      animate={{ opacity: 1, y:  0, filter: 'blur(0px)'  }}
      transition={{
        duration: 1.2,
        delay: 0.3 + index * 0.15,
        ease: [0.22, 1, 0.36, 1],
      }}
      onMouseEnter={() => { playHover(); setHovered(id); }}
      onMouseLeave={() => setHovered(null)}
      onClick={handleClick}
      whileHover={{ y: -8, transition: { duration: 0.5, ease: [0.22, 1, 0.36, 1] } }}
      className="group relative isolate w-[300px] h-[440px] text-left"
    >
      {/* Spotlight pool on the floor — appears on hover */}
      <motion.div
        aria-hidden
        animate={{ opacity: isHovered ? 1 : 0.4, scale: isHovered ? 1.1 : 1 }}
        transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        className="absolute -bottom-12 left-1/2 -translate-x-1/2 w-[80%] h-16 pointer-events-none"
        style={{
          background: `radial-gradient(ellipse 50% 50% at 50% 50%, ${accent}55, transparent 70%)`,
          filter: 'blur(20px)',
        }}
      />

      {/* Outer velvet frame */}
      <div
        className="relative w-full h-full rounded-sm overflow-hidden velvet"
        style={{
          boxShadow: isHovered
            ? `var(--shadow-cinematic), 0 0 60px ${accent}33`
            : 'var(--shadow-cinematic)',
          transition: 'box-shadow 700ms cubic-bezier(0.22,1,0.36,1)',
        }}
      >
        {/* Top spotlight wash inside the frame */}
        <div
          aria-hidden
          className="absolute inset-x-0 top-0 h-[50%] pointer-events-none"
          style={{
            background: `radial-gradient(ellipse 60% 80% at 50% 0%, ${accent}28, transparent 60%)`,
            mixBlendMode: 'screen',
          }}
        />

        {/* DIORAMA — the scene art */}
        <div className="absolute inset-3 rounded-sm overflow-hidden gold-frame">
          <div
            className="absolute inset-0"
            style={{
              background: 'radial-gradient(ellipse 90% 60% at 50% 30%, #1F1A28 0%, #0B0A12 70%, #05040A 100%)',
            }}
          />
          {/* Animated content */}
          <motion.div
            className="absolute inset-0 flex items-center justify-center"
            animate={{ scale: isHovered ? 1.06 : 1 }}
            transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
          >
            {sceneArt}
          </motion.div>

          {/* light shaft sweep on hover */}
          <motion.div
            aria-hidden
            initial={{ x: '-100%', skewX: -20 }}
            animate={{ x: isHovered ? '120%' : '-100%' }}
            transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1] }}
            className="absolute inset-y-0 w-1/3 pointer-events-none"
            style={{
              background: 'linear-gradient(90deg, transparent, rgba(244,215,138,0.18), transparent)',
              mixBlendMode: 'screen',
            }}
          />

          {/* grain overlay */}
          <div
            aria-hidden
            className="absolute inset-0 opacity-30 mix-blend-overlay pointer-events-none"
            style={{ background: 'var(--noise-grain)' }}
          />
        </div>

        {/* PLATE — engraved metal nameplate */}
        <div className="absolute inset-x-3 bottom-3 px-5 py-4 rounded-sm overflow-hidden"
          style={{
            background: 'linear-gradient(180deg, rgba(20,16,28,0.92), rgba(8,6,14,0.96))',
            borderTop: '1px solid rgba(244,215,138,0.25)',
            boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.05), 0 -10px 24px rgba(0,0,0,0.5)',
          }}
        >
          <div className="hairline-gold mb-3 opacity-80" />
          <div className="flex items-baseline justify-between mb-1">
            <span className="engraved text-[8px] text-aurum-smoke">{subtitle}</span>
            <span className="font-mono text-[8px] text-aurum-gold/50">№ 0{index + 1}</span>
          </div>
          <h3 className="font-display text-[26px] tracking-[0.08em] gold-leaf leading-none">
            {title}
          </h3>
          <p className="mt-2 text-[11px] text-aurum-ivory/50 leading-relaxed">
            {description}
          </p>

          {/* enter prompt */}
          <motion.div
            animate={{ opacity: isHovered ? 1 : 0, x: isHovered ? 0 : -8 }}
            transition={{ duration: 0.4 }}
            className="absolute right-5 bottom-4 flex items-center gap-2 text-aurum-goldHi"
          >
            <span className="engraved text-[8px]">Entrer</span>
            <span className="text-[14px]">→</span>
          </motion.div>
        </div>
      </div>
    </motion.button>
  );
}
