'use client';

import { motion } from 'framer-motion';
import { playHover, playClick } from '@/lib/audio';

/**
 * The signature CTA of AURUM.
 * - Gold-leaf gradient with shimmer animation
 * - Embossed border
 * - Soft idle breathing
 * - Hover: brighten + lift + scale gold shimmer speed
 * - Click: depress with weighted physics
 */
export default function CinematicButton({
  children,
  onClick,
  variant = 'primary', // 'primary' | 'ghost'
  size    = 'lg',      // 'sm' | 'md' | 'lg'
  className = '',
}) {
  const sizes = {
    sm: 'px-6 py-2.5 text-[10px]',
    md: 'px-9 py-3.5 text-[11px]',
    lg: 'px-14 py-5 text-[12px]',
  };

  const handleClick = (e) => { playClick(); onClick?.(e); };

  if (variant === 'ghost') {
    return (
      <motion.button
        onClick={handleClick}
        onHoverStart={playHover}
        whileHover={{ y: -2, color: 'rgb(244,215,138)' }}
        whileTap={{ y: 0, scale: 0.98 }}
        transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
        className={`
          relative ${sizes[size]} ${className}
          font-body font-medium tracking-[0.32em] uppercase
          text-aurum-ivory/70 hover:text-aurum-goldHi
          transition-colors
        `}
      >
        <span className="relative z-10">{children}</span>
        <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 h-px w-0
                         bg-gradient-to-r from-transparent via-aurum-gold to-transparent
                         transition-all duration-700 group-hover:w-full" />
      </motion.button>
    );
  }

  return (
    <motion.button
      onClick={handleClick}
      onHoverStart={playHover}
      initial="rest"
      animate="rest"
      whileHover="hover"
      whileTap="tap"
      variants={{
        rest:  { scale: 1,    y: 0  },
        hover: { scale: 1.03, y: -3 },
        tap:   { scale: 0.97, y: 1  },
      }}
      transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
      className={`
        group relative ${sizes[size]} ${className}
        font-body font-semibold tracking-[0.32em] uppercase
        text-aurum-black isolate
        rounded-[2px]
      `}
      style={{
        background: 'var(--grad-gold-leaf)',
        backgroundSize: '300% 300%',
        boxShadow: 'var(--shadow-gold-glow), inset 0 1px 0 rgba(255,255,255,0.4), inset 0 -2px 4px rgba(0,0,0,0.25)',
        animation: 'shimmer 4s linear infinite',
      }}
    >
      {/* Inner sheen */}
      <span
        aria-hidden
        className="absolute inset-0 rounded-[2px] opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
        style={{
          background: 'linear-gradient(120deg, transparent 35%, rgba(255,255,255,0.55) 50%, transparent 65%)',
          mixBlendMode: 'overlay',
        }}
      />
      {/* Embossed bevel */}
      <span aria-hidden className="absolute inset-0 rounded-[2px] pointer-events-none"
        style={{
          boxShadow: 'inset 0 0 0 1px rgba(255,241,199,0.5), inset 0 0 0 2px rgba(122,92,24,0.55)',
        }}
      />
      <span className="relative z-10 drop-shadow-[0_1px_0_rgba(255,255,255,0.4)]">
        {children}
      </span>
    </motion.button>
  );
}
