'use client';

import { motion } from 'framer-motion';

export default function Loader({ progress = null }) {
  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, filter: 'blur(20px)' }}
      transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
      className="fixed inset-0 z-[200] flex flex-col items-center justify-center grain vignette"
      style={{ background: 'var(--grad-velvet-vignette)' }}
    >
      {/* spinning gold ring */}
      <div className="relative w-32 h-32">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 4, repeat: Infinity, ease: 'linear' }}
          className="absolute inset-0 rounded-full"
          style={{
            border: '1px solid transparent',
            background: 'conic-gradient(from 0deg, transparent, #C8A24A, #F4D78A, #C8A24A, transparent)',
            mask: 'radial-gradient(circle, transparent 60%, #000 62%)',
            WebkitMask: 'radial-gradient(circle, transparent 60%, #000 62%)',
          }}
        />
        <motion.div
          animate={{ rotate: -360 }}
          transition={{ duration: 8, repeat: Infinity, ease: 'linear' }}
          className="absolute inset-3 rounded-full opacity-50"
          style={{
            border: '1px solid transparent',
            background: 'conic-gradient(from 90deg, transparent, #F4D78A, transparent, #C8A24A, transparent)',
            mask: 'radial-gradient(circle, transparent 60%, #000 62%)',
            WebkitMask: 'radial-gradient(circle, transparent 60%, #000 62%)',
          }}
        />
        <motion.div
          animate={{ scale: [1, 1.1, 1], opacity: [0.7, 1, 0.7] }}
          transition={{ duration: 2.4, repeat: Infinity, ease: 'easeInOut' }}
          className="absolute inset-0 flex items-center justify-center"
        >
          <Sigil />
        </motion.div>
      </div>

      <div className="mt-12 text-center">
        <div className="hairline-gold w-32 mx-auto mb-4" />
        <div className="font-display italic text-aurum-ivory/60 text-sm">
          Préparation de la maison…
        </div>
        {progress !== null && (
          <div className="mt-2 font-mono text-[10px] text-aurum-gold/50 tracking-widest">
            {Math.round(progress)}%
          </div>
        )}
      </div>
    </motion.div>
  );
}

function Sigil() {
  return (
    <svg width="40" height="40" viewBox="0 0 40 40">
      <defs>
        <linearGradient id="ld-s" x1="0" y1="0" x2="40" y2="40">
          <stop offset="0%"  stopColor="#FFF1C7" />
          <stop offset="100%" stopColor="#7A5C18" />
        </linearGradient>
      </defs>
      <path d="M 20 4 L 23 17 L 36 20 L 23 23 L 20 36 L 17 23 L 4 20 L 17 17 Z" fill="url(#ld-s)" />
    </svg>
  );
}
