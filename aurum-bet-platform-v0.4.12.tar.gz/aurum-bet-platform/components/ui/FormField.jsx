'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';

/**
 * Engraved-style input with a glass field and animated underline.
 * Floating label, gold focus state.
 */
export default function FormField({
  label, type = 'text', value, onChange, placeholder, autoComplete, maxLength,
}) {
  const [focused, setFocused] = useState(false);
  return (
    <label className="block relative mb-5">
      <div className="engraved text-[8px] text-aurum-gold/70 mb-2">
        {label}
      </div>
      <div
        className="relative rounded-sm overflow-hidden"
        style={{
          background: 'linear-gradient(180deg, rgba(15,11,22,0.85), rgba(8,6,14,0.95))',
          border: focused
            ? '1px solid rgba(244, 215, 138, 0.5)'
            : '1px solid rgba(244, 215, 138, 0.18)',
          boxShadow: focused
            ? 'inset 0 1px 0 rgba(255,255,255,0.06), 0 0 16px rgba(244,215,138,0.15)'
            : 'inset 0 1px 0 rgba(255,255,255,0.04)',
          transition: 'all 320ms cubic-bezier(0.22,1,0.36,1)',
        }}
      >
        <input
          type={type}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onFocus={() => setFocused(true)}
          onBlur={()  => setFocused(false)}
          placeholder={placeholder}
          autoComplete={autoComplete}
          maxLength={maxLength}
          className="w-full bg-transparent outline-none px-4 py-3 font-body
                     text-aurum-ivory placeholder-aurum-smoke text-base"
        />
        <motion.div
          initial={{ scaleX: 0 }}
          animate={{ scaleX: focused ? 1 : 0 }}
          transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
          className="absolute bottom-0 left-0 right-0 h-px origin-left"
          style={{ background: 'var(--grad-gold-leaf)' }}
        />
      </div>
    </label>
  );
}
