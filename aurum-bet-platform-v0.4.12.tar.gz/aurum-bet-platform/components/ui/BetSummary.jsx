'use client';

import { motion, AnimatePresence } from 'framer-motion';
import { formatCurrency } from '@/services/money';
import { useWalletStore } from '@/store/useWalletStore';
import { useAurumStore } from '@/store/useAurumStore';
import { useT } from '@/lib/i18n';

/**
 * BetSummary
 *
 * A compact, always-visible panel that tells the player exactly where
 * they stand: live balance, current stake, the denomination they
 * picked, the potential payout if they win, and what happened on the
 * last round. Surfaces in every game so the relationship between bet
 * and balance is never hidden behind a modal.
 *
 * Pure presentational — no business logic; just reads the wallet store
 * for live balance and renders whatever the parent passes in.
 *
 * Props:
 *   stake               string|number   current total stake
 *   chipValue           number          selected chip denomination
 *   potentialReturn     string|number   gross return if the bet wins (optional)
 *   lastResult          {outcome,net,detail?}   last round summary (optional)
 *   compact             boolean         tighter vertical layout (default false)
 */
export default function BetSummary({
  stake,
  chipValue,
  potentialReturn,
  lastResult,
  compact = false,
  className = '',
}) {
  const t      = useT();
  const locale = useAurumStore((s) => s.locale);
  const tag    = { en: 'en-US', pt: 'pt-BR', fr: 'fr-FR' }[locale] || 'en-US';
  const live   = useWalletStore((s) => s.available);

  const pad = compact ? 'p-3' : 'p-4';

  return (
    <div
      className={`relative rounded-sm border border-aurum-gold/25 ${pad} ${className}`}
      style={{
        background: 'linear-gradient(180deg, rgba(15,11,22,0.86), rgba(8,6,14,0.94))',
        backdropFilter: 'blur(4px)',
      }}
      role="status"
      aria-live="polite"
    >
      <div className={`grid grid-cols-2 gap-x-4 ${compact ? 'gap-y-1' : 'gap-y-2'}`}>
        <SummaryRow
          label={t('slots.balance')}
          value={formatCurrency(live, tag)}
          accent
        />
        <SummaryRow
          label={t('slots.bet')}
          value={formatCurrency(stake ?? 0, tag)}
        />
        {chipValue !== undefined && (
          <SummaryRow
            label={t('hud.chipSelected') || 'CHIP'}
            value={`$${chipValue}`}
          />
        )}
        {potentialReturn !== undefined && potentialReturn !== null && (
          <SummaryRow
            label={t('game.potentialReturn') || 'POSSIBLE'}
            value={formatCurrency(potentialReturn, tag)}
          />
        )}
      </div>

      {lastResult && (
        <>
          <div className="hairline-gold opacity-50 my-3" />
          <AnimatePresence mode="wait">
            <motion.div
              key={JSON.stringify(lastResult)}
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0  }}
              transition={{ duration: 0.4 }}
              className="text-center"
            >
              <div className="engraved text-[7px] text-aurum-gold/60 mb-1 tracking-[0.22em]">
                {t('game.lastResult') || 'LAST ROUND'}
              </div>
              <div
                className="font-display text-base tabular-nums"
                style={{
                  color:
                    lastResult.outcome === 'WIN'  ? '#F4D78A' :
                    lastResult.outcome === 'PUSH' ? '#EDE3CE' : '#9C9C9C',
                  filter: lastResult.outcome === 'WIN' ? 'drop-shadow(0 0 6px #F4D78A)' : 'none',
                }}
              >
                {lastResult.outcome === 'WIN' && '+'}
                {formatCurrency(lastResult.net ?? '0', tag)}
              </div>
              {lastResult.detail && (
                <div className="text-[9px] text-aurum-smoke mt-0.5 truncate">
                  {lastResult.detail}
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </>
      )}
    </div>
  );
}

function SummaryRow({ label, value, accent }) {
  return (
    <>
      <div className="engraved text-[7px] text-aurum-gold/60 tracking-[0.22em] flex items-center">
        {label}
      </div>
      <div
        className={`text-right font-display tabular-nums text-[13px] ${accent ? 'gold-leaf' : 'text-aurum-ivory/85'}`}
      >
        {value}
      </div>
    </>
  );
}
