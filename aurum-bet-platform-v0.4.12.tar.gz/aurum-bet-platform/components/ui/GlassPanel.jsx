'use client';

import { motion } from 'framer-motion';

/**
 * Glass panel with real backdrop blur.
 * Variants:
 *  - tint: 'noir' | 'warm' | 'cool'
 *  - frame: true → embossed gold edge
 *  - corners: true → corner ornaments (luxury hotel signage feel)
 */
export default function GlassPanel({
  children,
  className   = '',
  tint        = 'noir',
  frame       = false,
  corners     = false,
  animate     = true,
  as: Tag     = 'div',
  ...rest
}) {
  const tintBg = {
    noir: 'var(--glass-tint-noir)',
    warm: 'var(--glass-tint-warm)',
    cool: 'var(--glass-tint-cool)',
  }[tint];

  const Component = animate ? motion[Tag] || motion.div : Tag;

  const motionProps = animate ? {
    initial: { opacity: 0, y: 12, filter: 'blur(8px)' },
    animate: { opacity: 1, y: 0,  filter: 'blur(0px)' },
    transition: { duration: 0.9, ease: [0.22, 1, 0.36, 1] },
  } : {};

  return (
    <Component
      {...motionProps}
      {...rest}
      className={`
        relative isolate overflow-hidden
        ${frame ? 'gold-frame' : ''}
        ${className}
      `}
      style={{
        background: tintBg,
        backdropFilter: 'blur(28px) saturate(140%)',
        WebkitBackdropFilter: 'blur(28px) saturate(140%)',
        border: '1px solid rgba(244, 215, 138, 0.10)',
        borderTop: '1px solid rgba(244, 215, 138, 0.20)',
        boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.04), 0 30px 80px -20px rgba(0,0,0,0.7)',
        ...rest.style,
      }}
    >
      {/* inner grain texture */}
      <span
        aria-hidden
        className="absolute inset-0 opacity-[0.18] mix-blend-overlay pointer-events-none"
        style={{ background: 'var(--noise-fine)' }}
      />

      {/* warm light wash from top */}
      <span
        aria-hidden
        className="absolute -top-1/2 left-1/2 -translate-x-1/2 w-[140%] h-[80%] pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse 60% 50% at 50% 100%, rgba(244,215,138,0.08), transparent 70%)',
          mixBlendMode: 'screen',
        }}
      />

      {/* Corner ornaments */}
      {corners && (
        <>
          <CornerOrnament className="top-2 left-2"  rotate="0"   />
          <CornerOrnament className="top-2 right-2" rotate="90"  />
          <CornerOrnament className="bottom-2 right-2" rotate="180" />
          <CornerOrnament className="bottom-2 left-2"  rotate="270" />
        </>
      )}

      <div className="relative z-10">{children}</div>
    </Component>
  );
}

function CornerOrnament({ className = '', rotate = '0' }) {
  return (
    <svg
      aria-hidden
      className={`absolute w-5 h-5 ${className}`}
      style={{ transform: `rotate(${rotate}deg)` }}
      viewBox="0 0 20 20"
      fill="none"
    >
      <path d="M0 0 H10 M0 0 V10" stroke="url(#g)" strokeWidth="1.2" />
      <circle cx="0" cy="0" r="1.4" fill="url(#g)" />
      <defs>
        <linearGradient id="g" x1="0" y1="0" x2="20" y2="20">
          <stop offset="0%"   stopColor="#F4D78A" />
          <stop offset="100%" stopColor="#7A5C18" />
        </linearGradient>
      </defs>
    </svg>
  );
}
