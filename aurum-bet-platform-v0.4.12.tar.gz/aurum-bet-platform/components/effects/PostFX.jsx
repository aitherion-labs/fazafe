'use client';

import { EffectComposer, Bloom, Vignette, Noise, ChromaticAberration } from '@react-three/postprocessing';
import { BlendFunction } from 'postprocessing';
import { Vector2 } from 'three';

/**
 * Cinematic post-processing chain. Subtle but transformative.
 * - Bloom on bright (gold) values
 * - Vignette to focus the eye
 * - Noise grain over everything
 * - Tiny chromatic aberration on edges
 */
export default function PostFX({ intensity = 1 }) {
  return (
    <EffectComposer multisampling={4}>
      <Bloom
        intensity={0.85 * intensity}
        luminanceThreshold={0.55}
        luminanceSmoothing={0.4}
        mipmapBlur
        radius={0.85}
      />
      <ChromaticAberration
        offset={new Vector2(0.0008, 0.0008)}
        blendFunction={BlendFunction.NORMAL}
      />
      <Vignette
        eskil={false}
        offset={0.18}
        darkness={0.85}
      />
      <Noise
        opacity={0.06}
        blendFunction={BlendFunction.OVERLAY}
        premultiply
      />
    </EffectComposer>
  );
}
