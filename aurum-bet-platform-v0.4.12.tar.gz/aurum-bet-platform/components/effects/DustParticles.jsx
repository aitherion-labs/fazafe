'use client';

import { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

/**
 * Floating dust motes — gives every scene living atmosphere.
 * Renders as additive points with custom shader; FPS-friendly.
 */
export default function DustParticles({ count = 800, area = 12, color = '#F4D78A' }) {
  const ref = useRef();

  const { positions, scales, speeds } = useMemo(() => {
    const positions = new Float32Array(count * 3);
    const scales    = new Float32Array(count);
    const speeds    = new Float32Array(count);
    for (let i = 0; i < count; i++) {
      positions[i * 3]     = (Math.random() - 0.5) * area;
      positions[i * 3 + 1] = Math.random() * area * 0.6;
      positions[i * 3 + 2] = (Math.random() - 0.5) * area;
      scales[i] = Math.random() * 0.6 + 0.2;
      speeds[i] = Math.random() * 0.05 + 0.01;
    }
    return { positions, scales, speeds };
  }, [count, area]);

  const uniforms = useMemo(() => ({
    uTime:  { value: 0 },
    uColor: { value: new THREE.Color(color) },
  }), [color]);

  useFrame(({ clock }) => {
    if (!ref.current) return;
    uniforms.uTime.value = clock.elapsedTime;

    // gently drift particles upward & loop
    const pos = ref.current.geometry.attributes.position;
    for (let i = 0; i < count; i++) {
      pos.array[i * 3 + 1] += speeds[i] * 0.012;
      if (pos.array[i * 3 + 1] > area * 0.6) pos.array[i * 3 + 1] = 0;
      pos.array[i * 3] += Math.sin(clock.elapsedTime * 0.4 + i) * 0.0015;
    }
    pos.needsUpdate = true;
  });

  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={count}
          array={positions}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-aScale"
          count={count}
          array={scales}
          itemSize={1}
        />
      </bufferGeometry>
      <shaderMaterial
        transparent
        depthWrite={false}
        blending={THREE.AdditiveBlending}
        uniforms={uniforms}
        vertexShader={`
          attribute float aScale;
          uniform float uTime;
          varying float vAlpha;
          void main() {
            vec3 p = position;
            vec4 mv = modelViewMatrix * vec4(p, 1.0);
            gl_Position = projectionMatrix * mv;
            gl_PointSize = aScale * 14.0 * (1.0 / -mv.z);
            vAlpha = aScale;
          }
        `}
        fragmentShader={`
          uniform vec3 uColor;
          varying float vAlpha;
          void main() {
            vec2 c = gl_PointCoord - 0.5;
            float d = length(c);
            float a = smoothstep(0.5, 0.0, d) * vAlpha;
            gl_FragColor = vec4(uColor, a * 0.6);
          }
        `}
      />
    </points>
  );
}
