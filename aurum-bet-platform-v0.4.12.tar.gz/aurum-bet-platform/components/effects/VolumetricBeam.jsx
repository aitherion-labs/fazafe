'use client';

import { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { volumetricVertex, volumetricFragment } from '@/shaders/volumetric';

/**
 * A cone-shaped volumetric beam. Place at light positions for visible god rays.
 */
export default function VolumetricBeam({
  position  = [0, 6, 0],
  height    = 7,
  radius    = 1.8,
  color     = '#FFC68A',
  intensity = 1.0,
  rotation  = [0, 0, 0],
}) {
  const matRef = useRef();

  const uniforms = useMemo(() => ({
    uTime:      { value: 0 },
    uColor:     { value: new THREE.Color(color) },
    uIntensity: { value: intensity },
  }), [color, intensity]);

  useFrame(({ clock }) => {
    if (matRef.current) matRef.current.uniforms.uTime.value = clock.elapsedTime;
  });

  return (
    <mesh position={position} rotation={rotation}>
      <coneGeometry args={[radius, height, 32, 1, true]} />
      <shaderMaterial
        ref={matRef}
        uniforms={uniforms}
        vertexShader={volumetricVertex}
        fragmentShader={volumetricFragment}
        transparent
        depthWrite={false}
        blending={THREE.AdditiveBlending}
        side={THREE.DoubleSide}
      />
    </mesh>
  );
}
