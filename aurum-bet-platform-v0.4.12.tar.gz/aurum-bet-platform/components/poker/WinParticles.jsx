'use client';

import { useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

/**
 * WinParticles
 *
 * Emits a burst of golden sparkles radiating from `origin` (in CSS %).
 * Triggered by `active`; particles auto-fade. Render once per win event.
 *
 * Props:
 *   active   boolean        when true, particles render and animate
 *   origin   { x, y }       CSS-percent point (e.g. { x:'50%', y:'78%' })
 *   count    number         particle count (default 36)
 */
export default function WinParticles({ active, origin, count = 36 }) {
  const particles = useMemo(() => {
    if (!active) return [];
    return Array.from({ length: count }, (_, i) => {
      const angle    = (Math.random() * Math.PI * 2);
      const distance = 80 + Math.random() * 200;     // px
      const dx       = Math.cos(angle) * distance;
      const dy       = Math.sin(angle) * distance;
      const dur      = 1.1 + Math.random() * 0.9;
      const delay    = Math.random() * 0.2;
      const size     = 6 + Math.random() * 10;
      const rotation = Math.random() * 360;
      const symbol   = pickSymbol();
      return { id: i, dx, dy, dur, delay, size, rotation, symbol };
    });
  }, [active, count]);

  if (!active || !origin) return null;

  return (
    <div
      className="absolute pointer-events-none z-[55]"
      style={{ left: origin.x, top: origin.y, transform: 'translate(-50%, -50%)' }}
    >
      <AnimatePresence>
        {particles.map((p) => (
          <motion.span
            key={p.id}
            initial={{ x: 0, y: 0, opacity: 0, scale: 0.3, rotate: 0 }}
            animate={{
              x: p.dx, y: p.dy,
              opacity: [0, 1, 1, 0],
              scale:   [0.3, 1.1, 1, 0.6],
              rotate:  p.rotation,
            }}
            transition={{
              duration: p.dur,
              delay: p.delay,
              ease: [0.22, 1, 0.36, 1],
              times: [0, 0.15, 0.6, 1],
            }}
            className="absolute"
            style={{
              fontSize: p.size,
              color: '#F4D78A',
              textShadow: '0 0 12px rgba(244,215,138,0.95)',
              filter: 'drop-shadow(0 0 6px rgba(244,215,138,0.7))',
              transformOrigin: 'center',
            }}
          >
            {p.symbol}
          </motion.span>
        ))}
      </AnimatePresence>
    </div>
  );
}

function pickSymbol() {
  const symbols = ['✦', '★', '✧', '✷', '◆'];
  return symbols[Math.floor(Math.random() * symbols.length)];
}
