# Audio Assets

Drop `.mp3` files here with the following names. The audio engine
(`lib/audio.js`) reads from this folder and gracefully no-ops on any
file it can't load — so the app still runs without audio.

Required files:

| Filename       | Purpose                          | Suggested length |
|----------------|----------------------------------|------------------|
| `ambient.mp3`  | Looping casino ambience (low)    | 60–120 s loop    |
| `roulette.mp3` | Wheel spin (ball + bearing)      | 5–7 s            |
| `hover.mp3`    | UI hover tick                    | < 200 ms         |
| `click.mp3`    | UI click thunk                   | < 300 ms         |
| `chip.mp3`     | Chip placement on felt           | < 400 ms         |
| `reveal.mp3`   | Reveal moment stinger            | 2–4 s            |

Recommended sources:
- freesound.org (CC0)
- zapsplat.com
- soundsnap.com (paid)

For best mood, use:
- a low-key piano or strings ambient track around -18 LUFS
- physical, mechanical SFX (no electronic synths)
