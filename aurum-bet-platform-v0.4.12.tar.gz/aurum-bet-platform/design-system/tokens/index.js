/**
 * AURUM DESIGN SYSTEM — Tokens
 *
 * The actual tokens live in /styles/tokens.css and are imported by
 * app/globals.css. This file exists as a JS handle for tokens that
 * need to be referenced in code (e.g. for Three.js color uniforms).
 */
export const colors = {
  black:    '#05040A',
  obsidian: '#0B0A12',
  velvet:   '#15101C',
  ash:      '#1F1A28',
  smoke:    '#2A2433',

  goldDeep: '#7A5C18',
  gold:     '#C8A24A',
  goldHi:   '#F4D78A',
  goldPale: '#FFF1C7',

  ember:  '#E0573B',
  jade:   '#1F4A3A',
  blood:  '#4A0E14',
  ivory:  '#EDE3CE',
};

export const ease = {
  cinematic:  [0.22, 1.00, 0.36, 1.00],
  physical:   [0.19, 1.00, 0.22, 1.00],
  anticipate: [0.68, -0.55, 0.27, 1.55],
  velvet:     [0.65, 0.05, 0.36, 1.00],
};

export const timing = {
  instant:   120,
  quick:     280,
  medium:    520,
  slow:     1100,
  cinematic: 2400,
};
