/**
 * AURUM DESIGN SYSTEM — Lighting
 * Cinematic three-point rigs. Same fixture, three moods.
 */
export { default as CinematicLighting } from '@/components/three/CinematicLighting';

/**
 * Helper: rigs by atmosphere.
 * Pass the result as props: <CinematicLighting {...rigFor('quantum')} />
 */
export const rigFor = (atmosphere) => {
  switch (atmosphere) {
    case 'quantum':
      return { keyColor: '#9CC8FF', fillColor: '#3A4A6A', rimColor: '#B8DAFF', intensity: 1.0 };
    case 'royal':
      return { keyColor: '#FFB48A', fillColor: '#5A2A30', rimColor: '#FFD4A8', intensity: 1.05 };
    case 'noir':
    default:
      return { keyColor: '#FFC68A', fillColor: '#5A7A9A', rimColor: '#F4D78A', intensity: 1.0 };
  }
};
