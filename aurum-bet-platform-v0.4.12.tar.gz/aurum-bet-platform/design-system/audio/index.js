/**
 * AURUM DESIGN SYSTEM — Audio
 * Single audio engine for the entire platform.
 */
export {
  audio, playHover, playClick, playChip, playSpin, playReveal,
} from '@/lib/audio';
