'use client';

import { useMemo } from 'react';
import * as THREE from 'three';

/**
 * AURUM DESIGN SYSTEM — Materials
 * Memoized MeshStandardMaterial presets shared across every 3D scene.
 * Importing these instead of declaring inline ensures every gold pillar,
 * every brass rim, every felt surface looks identical across the platform.
 */

export function useGoldMaterials() {
  return useMemo(() => ({
    gold: new THREE.MeshStandardMaterial({
      color: '#C8A24A', metalness: 0.95, roughness: 0.18, envMapIntensity: 1.4,
    }),
    goldHi: new THREE.MeshStandardMaterial({
      color: '#F4D78A', metalness: 1.0, roughness: 0.12, envMapIntensity: 1.6,
      emissive: '#3A2A0A', emissiveIntensity: 0.15,
    }),
    goldDeep: new THREE.MeshStandardMaterial({
      color: '#7A5C18', metalness: 1.0, roughness: 0.35,
    }),
  }), []);
}

export function useVelvetMaterial() {
  return useMemo(() => new THREE.MeshStandardMaterial({
    color: '#15101C', roughness: 0.95, metalness: 0.0,
  }), []);
}

export function useFeltMaterial(tint = 'green') {
  const colors = { green: '#1F4A3A', noir: '#1A0E18', royal: '#3A0E18', quantum: '#0E2A3A' };
  return useMemo(() => new THREE.MeshStandardMaterial({
    color: colors[tint] || colors.green,
    roughness: 1.0, metalness: 0.0,
  }), [tint]);
}

export function useMahoganyMaterial() {
  return useMemo(() => new THREE.MeshStandardMaterial({
    color: '#2A0E08', roughness: 0.55, metalness: 0.15,
  }), []);
}

/* Procedural texture factories — generate once, reuse everywhere. */

export function createFeltTexture(tint = '#1A3A2A') {
  if (typeof document === 'undefined') return null;
  const c = document.createElement('canvas');
  c.width = c.height = 512;
  const ctx = c.getContext('2d');
  ctx.fillStyle = tint;
  ctx.fillRect(0, 0, 512, 512);
  for (let i = 0; i < 18000; i++) {
    ctx.fillStyle = `rgba(${20 + Math.random() * 25},${50 + Math.random() * 30},${30 + Math.random() * 25},0.5)`;
    ctx.fillRect(Math.random() * 512, Math.random() * 512, 1, 1);
  }
  const grd = ctx.createRadialGradient(256, 256, 80, 256, 256, 360);
  grd.addColorStop(0, 'rgba(0,0,0,0)');
  grd.addColorStop(1, 'rgba(0,0,0,0.45)');
  ctx.fillStyle = grd;
  ctx.fillRect(0, 0, 512, 512);
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.anisotropy = 8;
  return tex;
}

export function createMarbleTexture() {
  if (typeof document === 'undefined') return null;
  const c = document.createElement('canvas');
  c.width = c.height = 1024;
  const ctx = c.getContext('2d');
  ctx.fillStyle = '#0E0A14';
  ctx.fillRect(0, 0, 1024, 1024);
  for (let i = 0; i < 25; i++) {
    ctx.strokeStyle = `rgba(${30 + Math.random() * 40}, ${20 + Math.random() * 30}, ${50 + Math.random() * 40}, ${0.15 + Math.random() * 0.25})`;
    ctx.lineWidth = 0.5 + Math.random() * 1.5;
    ctx.beginPath();
    const sx = Math.random() * 1024, sy = Math.random() * 1024;
    ctx.moveTo(sx, sy);
    for (let j = 0; j < 6; j++) ctx.lineTo(sx + (Math.random() - 0.5) * 600, sy + (Math.random() - 0.5) * 600);
    ctx.stroke();
  }
  for (let i = 0; i < 200; i++) {
    ctx.fillStyle = `rgba(244, 215, 138, ${0.1 + Math.random() * 0.3})`;
    ctx.beginPath();
    ctx.arc(Math.random() * 1024, Math.random() * 1024, 0.4 + Math.random() * 1.2, 0, Math.PI * 2);
    ctx.fill();
  }
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(4, 4);
  tex.anisotropy = 8;
  return tex;
}
