/**
 * AURUM DESIGN SYSTEM — Motion
 * Framer variants + GSAP timelines, single import surface.
 */
export {
  fadeUp, stagger, cinematicFade, idleBreathing, hoverLift,
  cameraDolly, revealSequence, ease,
} from '@/lib/animations';
