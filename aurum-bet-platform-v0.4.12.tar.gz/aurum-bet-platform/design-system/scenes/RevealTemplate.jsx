'use client';

import { Suspense, useEffect } from 'react';
import { Canvas, useThree, useFrame } from '@react-three/fiber';
import { motion, AnimatePresence } from 'framer-motion';
import dynamic from 'next/dynamic';
import gsap from 'gsap';

import { useAurumStore } from '@/store/useAurumStore';
import { playReveal } from '@/lib/audio';
import { revealSequence } from '@/lib/animations';
import { rigFor } from '@/ds/lighting';
import CinematicLighting from '@/components/three/CinematicLighting';
import VolumetricBeam    from '@/components/effects/VolumetricBeam';
import DustParticles     from '@/components/effects/DustParticles';

const PostFX = dynamic(() => import('@/components/effects/PostFX'), { ssr: false });

/**
 * AURUM REVEAL TEMPLATE
 *
 * Drop-in 5-phase cinematic GSAP camera ride. Pass in:
 *   - subject:  the centerpiece Three.js node (a wheel, a card, a chest, anything)
 *   - phases:   array of 5 { headline, sub } strings
 *   - onComplete: called after the last phase finishes
 *   - finalCrown: JSX shown on phase 4 (defaults to no crown)
 *
 * The template handles: 5-phase camera choreography, cinematic bars,
 * phase-text crossfade, progress dots, dust + beam atmosphere.
 *
 * Use it from any game's "win moment", or from `/lounge/<game>/reveal`.
 */
export default function RevealTemplate({
  subject,
  phases  = DEFAULT_PHASES,
  onComplete = () => {},
  finalCrown = null,
}) {
  const atmosphere = useAurumStore((s) => s.atmosphere);
  const reducedMotion = useAurumStore((s) => s.reducedMotion);
  const setRevealPhase = useAurumStore((s) => s.setRevealPhase || (() => {}));
  const rig = rigFor(atmosphere);

  // current phase is local — we use the store as a relay so 3D code can read it
  const phase = usePhase(phases.length, reducedMotion, onComplete);
  const current = phases[Math.min(phase, phases.length - 1)];

  return (
    <section className="relative w-full h-screen overflow-hidden grain vignette">
      <div className="absolute inset-0">
        <Canvas
          camera={{ position: [0, 2.4, 8], fov: 38 }}
          dpr={[1, 1.6]}
          shadows
          gl={{ antialias: true, toneMapping: 2, toneMappingExposure: 0.85 }}
        >
          <Suspense fallback={null}>
            <fog attach="fog" args={['#05040A', 4, 18]} />
            <CinematicLighting {...rig} intensity={1.2} />
            <VolumetricBeam position={[0, 6, 0]} height={6} radius={2.5} intensity={1.2} />
            <DustParticles count={1000} area={14} color="#F4D78A" />
            {subject}
            {!reducedMotion && <CameraChoreographer phases={phases.length} />}
          </Suspense>
          <PostFX intensity={1.2} />
        </Canvas>
      </div>

      {/* cinematic bars */}
      <motion.div
        initial={{ y: '-100%' }} animate={{ y: 0 }} transition={{ duration: 0.8 }}
        className="absolute top-0 left-0 right-0 h-[14vh] z-30 pointer-events-none"
        style={{ background: 'linear-gradient(180deg, #000 0%, transparent 100%)' }}
      />
      <motion.div
        initial={{ y: '100%' }} animate={{ y: 0 }} transition={{ duration: 0.8 }}
        className="absolute bottom-0 left-0 right-0 h-[18vh] z-30 pointer-events-none"
        style={{ background: 'linear-gradient(0deg, #000 0%, transparent 100%)' }}
      />

      {/* phase text */}
      <div className="absolute inset-0 z-40 flex flex-col items-center justify-end pb-32 pointer-events-none">
        <AnimatePresence mode="wait">
          <motion.div
            key={phase}
            initial={{ opacity: 0, y: 30, filter: 'blur(20px)' }}
            animate={{ opacity: 1, y:  0, filter: 'blur(0px)'  }}
            exit   ={{ opacity: 0, y:-30, filter: 'blur(20px)' }}
            transition={{ duration: 1.0, ease: [0.22, 1, 0.36, 1] }}
            className="text-center max-w-2xl px-8"
          >
            {phase === phases.length - 1 && finalCrown && (
              <motion.div
                initial={{ scale: 0.4, opacity: 0 }}
                animate={{ scale: 1,   opacity: 1 }}
                transition={{ duration: 1.5, ease: [0.22, 1, 0.36, 1] }}
                className="mb-6"
              >
                {finalCrown}
              </motion.div>
            )}
            <h2
              className={`
                font-display tracking-[0.18em] gold-leaf select-none leading-none
                ${phase === phases.length - 1
                  ? 'text-[clamp(80px,16vw,220px)]'
                  : 'text-4xl md:text-5xl'}
              `}
              style={{ filter: 'drop-shadow(0 0 50px rgba(244,215,138,0.3))' }}
            >
              {current.headline}
            </h2>
            <p className="mt-4 font-display italic text-aurum-ivory/70 text-lg md:text-xl">
              {current.sub}
            </p>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* progress dots */}
      <div className="absolute top-12 left-1/2 -translate-x-1/2 z-40 flex items-center gap-3">
        {phases.map((_, p) => (
          <motion.span
            key={p}
            animate={{
              scaleX: phase === p ? 1.6 : 1,
              opacity: phase >= p ? 1 : 0.25,
              backgroundColor: phase >= p ? '#F4D78A' : '#7A5C18',
            }}
            transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
            className="w-8 h-px origin-left"
          />
        ))}
      </div>
    </section>
  );
}

function CameraChoreographer({ phases }) {
  const { camera } = useThree();
  const setRevealPhase = useAurumStore((s) => s.setRevealPhase || (() => {}));

  useEffect(() => {
    playReveal();
    const tl = revealSequence({ camera, onPhase: setRevealPhase });
    const lookTL = gsap.timeline();
    lookTL.to({}, { duration: 9.0, onUpdate: () => camera.lookAt(0, 0.4, 0) });
    return () => { tl.kill(); lookTL.kill(); };
  }, [camera, setRevealPhase, phases]);

  return null;
}

/* Internal: use store-backed phase index, advance on a timer if reduced-motion is on */
function usePhase(count, reducedMotion, onComplete) {
  const phase = useAurumStore((s) => s.revealPhase ?? 0);
  const setPhase = useAurumStore((s) => s.setRevealPhase || (() => {}));

  useEffect(() => {
    if (!reducedMotion) return;
    // for reduced-motion, just step through phases on a 1.2s timer with no camera moves
    let p = 0;
    setPhase(0);
    const id = setInterval(() => {
      p++;
      if (p >= count) { clearInterval(id); onComplete(); return; }
      setPhase(p);
    }, 1200);
    return () => clearInterval(id);
  }, [count, reducedMotion, setPhase, onComplete]);

  // for full-motion mode, the GSAP timeline calls setPhase
  useEffect(() => {
    if (phase === count - 1) {
      const t = setTimeout(onComplete, 2400);
      return () => clearTimeout(t);
    }
  }, [phase, count, onComplete]);

  return phase;
}

const DEFAULT_PHASES = [
  { headline: 'Le silence avant',  sub: 'Tout retient son souffle.' },
  { headline: 'La descente',       sub: 'Le destin se rapproche.' },
  { headline: 'Le tourbillon',     sub: 'Mille possibilités. Une seule.' },
  { headline: "L'instant",          sub: '…' },
  { headline: 'AURUM',             sub: "Là où l'or se révèle." },
];
