'use client';

import { Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { motion } from 'framer-motion';
import dynamic from 'next/dynamic';

import CinematicLighting from '@/components/three/CinematicLighting';
import DustParticles     from '@/components/effects/DustParticles';
import VolumetricBeam    from '@/components/effects/VolumetricBeam';
import ErrorBoundary     from '@/components/ErrorBoundary';
import { rigFor }        from '@/ds/lighting';
import { useAurumStore } from '@/store/useAurumStore';

const PostFX = dynamic(() => import('@/components/effects/PostFX'), { ssr: false });

/**
 * AURUM GAME ROOM — the shell every game inherits.
 *
 * Guarantees:
 *  - Same cinematic lighting rig (atmosphere-aware)
 *  - Same volumetric beam over the focal point
 *  - Same dust particles
 *  - Same fog
 *  - Same post-FX chain
 *  - Same vignette + grain finishing layers
 *  - Same HUD overlay slot
 *
 * Children are rendered:
 *   - Inside the Canvas:  pass `world` (Three.js elements)
 *   - Outside the Canvas: pass `overlay` (HTML/JSX)
 *
 * Atmosphere is read from useAurumStore — switching atmosphere
 * re-tones lighting and color tokens across every room simultaneously.
 */
export default function GameRoom({
  world,
  overlay,
  cameraProps  = { position: [0, 4.5, 5.5], fov: 38 },
  beamProps    = { position: [0, 6, 0], height: 5.5, radius: 2.2, intensity: 0.85 },
  fogColor     = '#08060E',
  fogNear      = 8,
  fogFar       = 28,
  particleCount = 350,
  enterDirection = 'down',  // 'down' | 'in' | 'right'
}) {
  const atmosphere    = useAurumStore((s) => s.atmosphere);
  const reducedMotion = useAurumStore((s) => s.reducedMotion);
  const rig = rigFor(atmosphere);

  const enterTransform = {
    down:  { initial: { y: -40, opacity: 0, filter: 'blur(20px)' } },
    in:    { initial: { scale: 0.96, opacity: 0, filter: 'blur(20px)' } },
    right: { initial: { x: 60, opacity: 0, filter: 'blur(16px)' } },
  }[enterDirection];

  return (
    <motion.section
      {...(reducedMotion ? {} : enterTransform)}
      animate={{ y: 0, x: 0, scale: 1, opacity: 1, filter: 'blur(0px)' }}
      exit={{ opacity: 0, filter: 'blur(20px)' }}
      transition={{ duration: reducedMotion ? 0.01 : 1.1, ease: [0.22, 1, 0.36, 1] }}
      className="relative w-full h-screen overflow-hidden"
    >
      {/* ===== 3D STAGE ===== */}
      <ErrorBoundary fallback={() => <StaticBackdrop />}>
        {reducedMotion ? <StaticBackdrop /> : (
          <div className="absolute inset-0">
            <Canvas
              camera={cameraProps}
              gl={{ antialias: true, toneMapping: 2, toneMappingExposure: 1.0 }}
              dpr={[1, 1.6]}
              shadows
            >
              <Suspense fallback={null}>
                <fog attach="fog" args={[fogColor, fogNear, fogFar]} />
                <CinematicLighting {...rig} />
                <VolumetricBeam {...beamProps} />
                <DustParticles count={particleCount} area={12} color="#F4D78A" />
                {world}
                <PostFX intensity={1.0} />
              </Suspense>
            </Canvas>
          </div>
        )}
      </ErrorBoundary>

      {/* ===== HTML OVERLAY ===== */}
      <div className="absolute inset-0 pointer-events-none z-30">
        <div className="relative w-full h-full pointer-events-auto">
          {overlay}
        </div>
      </div>

      {/* ===== finishing layers ===== */}
      <div className="absolute inset-0 pointer-events-none z-20 vignette grain" />
    </motion.section>
  );
}

/**
 * StaticBackdrop — drawn instead of the Canvas when reduced-motion is on
 * or when the WebGL stage failed. CSS-only, materialized, AURUM-faithful.
 */
function StaticBackdrop() {
  return (
    <div
      className="absolute inset-0 spotlight"
      style={{
        background: 'var(--grad-velvet-vignette)',
      }}
    >
      <div
        aria-hidden
        className="absolute inset-0 opacity-30 mix-blend-overlay pointer-events-none"
        style={{ background: 'var(--noise-grain)' }}
      />
      <div
        aria-hidden
        className="absolute -top-1/4 left-1/2 -translate-x-1/2 w-[120%] h-[80%] pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse 50% 60% at 50% 0%, rgba(244,215,138,0.18), transparent 65%)',
          mixBlendMode: 'screen',
        }}
      />
    </div>
  );
}
